import test from "node:test";
import assert from "node:assert/strict";
import { decryptSecret, encryptSecret, hashPassword, last4, redactSecrets, sha256, verifyPassword } from "../src/lib/crypto.ts";
import { buildSystemInstruction, deriveTitle, speakableText, PERSONALITY_MODES } from "../src/lib/personality.ts";
import { safeCalculate } from "../src/lib/calc.ts";

test("credential vault encrypts and decrypts user API keys", () => {
  const key = "AIzaSyTESTKEY_0123456789abcdefghijklmnop";
  const sealed = encryptSecret(key);
  assert.notEqual(sealed, key);
  assert.ok(sealed.startsWith("v1."));
  assert.equal(decryptSecret(sealed), key);
  assert.equal(last4(key), key.slice(-4));
});

test("credential vault rejects tampered ciphertext (GCM authentication)", () => {
  const sealed = encryptSecret("AIzaSyTESTKEY_0123456789abcdefghijklmnop");
  const parts = sealed.split(".");
  const tampered = [parts[0], parts[1], parts[2], Buffer.from("evil").toString("base64url")].join(".");
  assert.throws(() => decryptSecret(tampered));
  assert.throws(() => decryptSecret("not-a-valid-payload"));
});

test("password hashing is salted and verifiable", () => {
  const first = hashPassword("jarvis-secret-1");
  const second = hashPassword("jarvis-secret-1");
  assert.notEqual(first, second, "identical passwords must not produce identical hashes");
  assert.equal(verifyPassword("jarvis-secret-1", first), true);
  assert.equal(verifyPassword("wrong-password", first), false);
  assert.equal(verifyPassword("jarvis-secret-1", "garbage"), false);
});

test("secret redaction masks Gemini keys in error text", () => {
  const message = "Request failed key=AIzaSyABCDEFGHIJKLMNOPQRSTUVWX with x-goog-api-key: AIzaSyABCDEFGHIJKLMNOPQRSTUVWX";
  const redacted = redactSecrets(message);
  assert.equal(redacted.includes("AIzaSyABCDEFGHIJKLMNOPQRSTUVWX"), false);
  assert.ok(redacted.includes("REDACTED"));
  assert.equal(sha256("jarvis"), sha256("jarvis"));
  assert.notEqual(sha256("jarvis"), sha256("jarvis "));
});

test("system instruction reflects personality, humour, length and memory settings", () => {
  const base = {
    personality: "jarvis",
    customPersonality: null,
    humor: 2,
    expressiveness: 2,
    responseLength: "balanced",
    memoryEnabled: true,
  };
  const prompt = buildSystemInstruction(base, [{ content: "Prefers bullet points", category: "preference" }], "2026-01-01T00:00:00.000Z");
  assert.match(prompt, /JARVIS/);
  assert.match(prompt, /Prefers bullet points/);
  assert.match(prompt, /balanced/);
  assert.match(prompt, /software/i);
  assert.match(prompt, /Never claim to be conscious/i);

  const noMemory = buildSystemInstruction({ ...base, memoryEnabled: false }, [{ content: "Secret preference", category: "general" }], "2026-01-01T00:00:00.000Z");
  assert.equal(noMemory.includes("Secret preference"), false);
  assert.match(noMemory, /No long-term memory/);

  const custom = buildSystemInstruction({ ...base, personality: "custom", customPersonality: "Speak like a mission controller." }, [], "2026-01-01T00:00:00.000Z");
  assert.match(custom, /mission controller/);

  const noHumor = buildSystemInstruction({ ...base, humor: 0 }, [], "2026-01-01T00:00:00.000Z");
  assert.match(noHumor, /absolutely no jokes/);

  const detailed = buildSystemInstruction({ ...base, responseLength: "detailed" }, [], "2026-01-01T00:00:00.000Z");
  assert.match(detailed, /thorough explanations/);

  assert.equal(PERSONALITY_MODES.length, 6);
});

test("conversation titles derive from the first message", () => {
  assert.equal(deriveTitle("   "), "New conversation");
  assert.equal(deriveTitle("Plan my week"), "Plan my week");
  const long = deriveTitle("a".repeat(120));
  assert.ok(long.length <= 53);
  assert.ok(long.endsWith("…"));
});

test("speakable text strips markdown and code fences", () => {
  const spoken = speakableText("# Heading\n\n**bold** `inline`\n\n```js\nconst x = 1;\n```\n[docs](https://example.com)");
  assert.equal(spoken.includes("```"), false);
  assert.equal(spoken.includes("**"), false);
  assert.equal(spoken.includes("const x = 1"), false);
  assert.ok(spoken.includes("docs"));
});

test("calculator evaluates arithmetic exactly and safely", () => {
  assert.equal(safeCalculate("2 + 3 * 4"), 14);
  assert.equal(safeCalculate("(1450*0.18)+32"), 293);
  assert.equal(safeCalculate("2^10"), 1024);
  assert.equal(safeCalculate("sqrt(144) + abs(-3)"), 15);
  assert.equal(safeCalculate("10 % 3"), 1);
  assert.equal(safeCalculate("1,5 * 2"), 3);
  assert.throws(() => safeCalculate("2 +"));
  assert.throws(() => safeCalculate("process.exit(1)"));
  assert.throws(() => safeCalculate("1/0"));
  assert.throws(() => safeCalculate("("));
});
