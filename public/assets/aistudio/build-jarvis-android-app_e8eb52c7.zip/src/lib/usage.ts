import { db } from "@/db";
import { usageEvents } from "@/db/schema";

/** Structured usage telemetry. Never contains prompts, responses or credentials. */
export async function logUsage(entry: {
  userId: string | null;
  route: string;
  model?: string;
  ok: boolean;
  statusCode?: number;
  latencyMs: number;
}): Promise<void> {
  try {
    await db.insert(usageEvents).values({
      userId: entry.userId,
      route: entry.route,
      model: entry.model ?? "",
      ok: entry.ok,
      statusCode: entry.statusCode,
      latencyMs: Math.round(entry.latencyMs),
    });
  } catch {
    // Telemetry must never break a user request.
  }
}
