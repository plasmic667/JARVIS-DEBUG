"use client";

import { useCallback, useEffect, useRef, useState } from "react";

type RecognitionAlternative = { transcript: string; confidence: number };
type RecognitionResult = { isFinal: boolean; length: number; 0: RecognitionAlternative };
type RecognitionEvent = { resultIndex: number; results: { length: number } & Record<number, RecognitionResult> };
type RecognitionErrorEvent = { error: string; message?: string };

type JarvisRecognition = {
  lang: string;
  continuous: boolean;
  interimResults: boolean;
  maxAlternatives: number;
  start: () => void;
  stop: () => void;
  abort: () => void;
  onresult: ((event: RecognitionEvent) => void) | null;
  onerror: ((event: RecognitionErrorEvent) => void) | null;
  onend: (() => void) | null;
  onstart: (() => void) | null;
};

type RecognitionConstructor = new () => JarvisRecognition;

function getRecognitionConstructor(): RecognitionConstructor | null {
  if (typeof window === "undefined") return null;
  const candidate = window as unknown as {
    SpeechRecognition?: RecognitionConstructor;
    webkitSpeechRecognition?: RecognitionConstructor;
  };
  return candidate.SpeechRecognition ?? candidate.webkitSpeechRecognition ?? null;
}

const ERROR_COPY: Record<string, string> = {
  "not-allowed": "Microphone blocked. Grant permission in your browser, then retry.",
  "service-not-allowed": "Speech recognition is blocked by the browser or OS.",
  "no-speech": "I did not catch any speech. Try again a little closer to the mic.",
  network: "The speech service could not be reached. Check your connection, or type instead.",
  "audio-capture": "No microphone was found. Connect an input device and retry.",
  aborted: "Listening stopped.",
};

export function useDictation(options: { lang?: string; onFinal: (text: string) => void }) {
  const { lang = "en-US" } = options;
  const onFinalRef = useRef(options.onFinal);
  onFinalRef.current = options.onFinal;

  const recognitionRef = useRef<JarvisRecognition | null>(null);
  const stoppingRef = useRef(false);
  const [supported, setSupported] = useState(false);
  const [listening, setListening] = useState(false);
  const [interim, setInterim] = useState("");
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    setSupported(Boolean(getRecognitionConstructor()));
  }, []);

  const stop = useCallback(() => {
    stoppingRef.current = true;
    recognitionRef.current?.stop();
    setListening(false);
  }, []);

  const start = useCallback(() => {
    setError(null);
    const Ctor = getRecognitionConstructor();
    if (!Ctor) {
      setError("This browser does not expose the Web Speech recognition API. Use text input instead.");
      return;
    }
    try {
      recognitionRef.current?.abort();
    } catch {
      /* noop */
    }
    const recognition = new Ctor();
    recognition.lang = lang;
    recognition.continuous = false;
    recognition.interimResults = true;
    recognition.maxAlternatives = 1;
    stoppingRef.current = false;

    recognition.onstart = () => {
      setListening(true);
      setError(null);
    };
    recognition.onresult = (event) => {
      let interimText = "";
      for (let i = event.resultIndex; i < event.results.length; i += 1) {
        const result = event.results[i];
        const transcript = result[0]?.transcript ?? "";
        if (result.isFinal) {
          const cleaned = transcript.trim();
          if (cleaned) onFinalRef.current(cleaned);
          setInterim("");
        } else {
          interimText += transcript;
        }
      }
      if (interimText) setInterim(interimText);
    };
    recognition.onerror = (event) => {
      if (event.error === "aborted" && stoppingRef.current) return;
      setError(ERROR_COPY[event.error] ?? `Speech recognition error: ${event.error}`);
      setListening(false);
    };
    recognition.onend = () => {
      setListening(false);
      setInterim("");
    };

    recognitionRef.current = recognition;
    try {
      recognition.start();
    } catch {
      setError("Could not start listening. Wait a moment and try again.");
      setListening(false);
    }
  }, [lang]);

  useEffect(() => {
    return () => {
      try {
        recognitionRef.current?.abort();
      } catch {
        /* noop */
      }
    };
  }, []);

  return { supported, listening, interim, error, start, stop, setError };
}

export type SpeechOptions = { rate?: number; pitch?: number; voiceName?: string | null; lang?: string };

export function useSpeaker() {
  const [supported, setSupported] = useState(false);
  const [speaking, setSpeaking] = useState(false);
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (typeof window === "undefined" || !("speechSynthesis" in window)) return;
    setSupported(true);
    const load = () => setVoices(window.speechSynthesis.getVoices());
    load();
    window.speechSynthesis.addEventListener("voiceschanged", load);
    return () => {
      window.speechSynthesis.removeEventListener("voiceschanged", load);
      window.speechSynthesis.cancel();
    };
  }, []);

  const stop = useCallback(() => {
    if (typeof window === "undefined" || !("speechSynthesis" in window)) return;
    window.speechSynthesis.cancel();
    setSpeaking(false);
  }, []);

  const speak = useCallback((text: string, options: SpeechOptions = {}) => {
    if (typeof window === "undefined" || !("speechSynthesis" in window)) {
      setError("Speech synthesis is not available in this browser.");
      return;
    }
    if (!text.trim()) return;
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text.slice(0, 4000));
    utterance.rate = options.rate ?? 1;
    utterance.pitch = options.pitch ?? 0.95;
    utterance.lang = options.lang ?? "en-US";
    const available = window.speechSynthesis.getVoices();
    const preferred = options.voiceName ? available.find((voice) => voice.name === options.voiceName) : undefined;
    const fallback = available.find((voice) => voice.lang.startsWith("en-GB")) ?? available.find((voice) => voice.lang.startsWith("en"));
    if (preferred ?? fallback) utterance.voice = (preferred ?? fallback) as SpeechSynthesisVoice;
    utterance.onstart = () => setSpeaking(true);
    utterance.onend = () => setSpeaking(false);
    utterance.onerror = () => {
      setSpeaking(false);
      setError("Speech playback failed. Try a different system voice.");
    };
    window.speechSynthesis.speak(utterance);
  }, []);

  return { supported, speaking, voices, speak, stop, error, setError };
}

export function speechAvailable(): { recognition: boolean; synthesis: boolean } {
  if (typeof window === "undefined") return { recognition: false, synthesis: false };
  const candidate = window as unknown as { SpeechRecognition?: unknown; webkitSpeechRecognition?: unknown };
  return {
    recognition: Boolean(candidate.SpeechRecognition ?? candidate.webkitSpeechRecognition),
    synthesis: "speechSynthesis" in window,
  };
}
