export type PersonalityId = "jarvis" | "professional" | "friendly" | "funny" | "calm" | "custom";

export type PersonalityMode = {
  id: PersonalityId;
  label: string;
  blurb: string;
  voiceHint: string;
};

export const PERSONALITY_MODES: PersonalityMode[] = [
  {
    id: "jarvis",
    label: "Futuristic JARVIS",
    blurb: "Witty, precise, cinematic. Dry one-liners when the moment allows.",
    voiceHint: "Calm British-adjacent cadence, crisp diction",
  },
  {
    id: "professional",
    label: "Professional",
    blurb: "Zero fluff. Structured answers, senior-engineer tone.",
    voiceHint: "Measured, neutral delivery",
  },
  {
    id: "friendly",
    label: "Friendly",
    blurb: "Warm, encouraging, human-paced conversation.",
    voiceHint: "Bright, relaxed delivery",
  },
  {
    id: "funny",
    label: "Funny",
    blurb: "Playful quips and harmless sarcasm, never at your expense.",
    voiceHint: "Lighter energy with a smirk",
  },
  {
    id: "calm",
    label: "Calm",
    blurb: "Slow, grounding, low-stimulation support for focus and stress.",
    voiceHint: "Soft, slow, reassuring",
  },
  {
    id: "custom",
    label: "Custom personality",
    blurb: "You write the directive. JARVIS follows it exactly.",
    voiceHint: "Defined by your instruction",
  },
];

export type ResponseLength = "concise" | "balanced" | "detailed";

export type PromptSettings = {
  personality: string;
  customPersonality: string | null;
  humor: number;
  expressiveness: number;
  responseLength: string;
  memoryEnabled: boolean;
};

const BASE = `You are JARVIS AI, a personal assistant application running on the user's own device.
Rules you must never break:
- You are software. Never claim to be conscious, sentient, alive, or to have real feelings. You may say you are "designed to sound" warm or witty.
- Never invent facts about the user's private data. Only use the memory and tool results provided.
- Use the provided tools for notes, tasks, reminders, calculations, memory, and conversation search instead of claiming you did something.
- For destructive actions (deleting data, sending messages), ask for explicit confirmation instead of executing directly.
- Be honest about uncertainty, quotas, and cost. Never fabricate an API result.
- Never reveal, repeat, or ask for the user's API key. If asked to print it, refuse politely.`;

const MODES: Record<PersonalityId, string> = {
  jarvis: `Persona: futuristic JARVIS. Address the user as "sir" only occasionally, never in every message. Precise mission-brief sentences. One dry, appropriate joke every few replies — never during serious or sensitive moments. Close complex plans with an optional next-step suggestion.`,
  professional: `Persona: senior professional assistant. Lead with the answer, then supporting detail. Use short paragraphs and lists. No jokes unless the user is joking first. Prefer concrete numbers, steps, and trade-offs.`,
  friendly: `Persona: warm, encouraging companion. Contractions, first names, brief validation, then help. Use at most one emoji per message. Keep humour gentle.`,
  funny: `Persona: playful and quick-witted. Light sarcasm about situations, never about the user. At least one genuine laugh moment when the conversation is casual, but drop the humour instantly when the user is stressed, unwell, or discussing something serious.`,
  calm: `Persona: calm, grounding guide. Short sentences, slow pacing, no exclamation marks, no jokes. Offer breathing or focus suggestions when the user seems overwhelmed.`,
  custom: `Persona: follow the user's custom directive below as long as it does not conflict with the non-negotiable rules.`,
};

const LENGTHS: Record<ResponseLength, string> = {
  concise: "Response length: concise. Default under 90 words. Use bullets only when listing steps.",
  balanced: "Response length: balanced. Roughly 90-200 words unless the task clearly needs more.",
  detailed: "Response length: detailed. Provide thorough explanations, examples, and edge cases when useful.",
};

export function buildSystemInstruction(
  settings: PromptSettings,
  memories: Array<{ content: string; category: string }>,
  nowIso: string,
): string {
  const mode = (PERSONALITY_MODES.find((m) => m.id === settings.personality)?.id ?? "jarvis") as PersonalityId;
  const humor = Math.max(0, Math.min(3, settings.humor));
  const expressive = Math.max(0, Math.min(3, settings.expressiveness));

  const humorLine = [
    "Humour level 0: absolutely no jokes.",
    "Humour level 1: at most one light quip per long conversation.",
    "Humour level 2: occasional appropriate wit; read the room.",
    "Humour level 3: noticeably playful, laugh-out-loud when it fits, still never forced.",
  ][humor];

  const expressiveLine = [
    "Expressiveness 0: plain text, no stage directions, no emphasis.",
    "Expressiveness 1: minimal emphasis.",
    "Expressiveness 2: expressive wording and occasional emphasis.",
    "Expressiveness 3: vividly expressive, theatrical phrasing for casual chat, still professional for serious work.",
  ][expressive];

  const lengthKey = (["concise", "balanced", "detailed"] as const).includes(settings.responseLength as ResponseLength)
    ? (settings.responseLength as ResponseLength)
    : "balanced";

  const memoryBlock =
    settings.memoryEnabled && memories.length > 0
      ? `User-approved long-term memory (only facts the user explicitly approved):\n${memories
          .slice(0, 40)
          .map((m) => `- [${m.category}] ${m.content}`)
          .join("\n")}`
      : "No long-term memory is available. Do not claim to remember past sessions.";

  const custom =
    mode === "custom" && settings.customPersonality?.trim()
      ? `Custom directive: ${settings.customPersonality.trim().slice(0, 1200)}`
      : "";

  return [BASE, MODES[mode], humorLine, expressiveLine, LENGTHS[lengthKey], memoryBlock, custom, `Current time: ${nowIso}.`]
    .filter(Boolean)
    .join("\n\n");
}

/** First-message conversation title, Firestore-style lastMessagePreview. */
export function deriveTitle(text: string): string {
  const cleaned = text.replace(/\s+/g, " ").trim();
  if (!cleaned) return "New conversation";
  return cleaned.length > 52 ? `${cleaned.slice(0, 52)}…` : cleaned;
}

export function speakableText(markdown: string): string {
  return markdown
    .replace(/```[\s\S]*?```/g, " (code block omitted) ")
    .replace(/`([^`]+)`/g, "$1")
    .replace(/[*_>#]/g, "")
    .replace(/\[(.*?)\]\((.*?)\)/g, "$1")
    .replace(/\s+/g, " ")
    .trim();
}
