import { and, desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { credentials } from "@/db/schema";
import { getDeviceId } from "@/lib/auth";
import { decryptSecret, encryptSecret, last4 } from "@/lib/crypto";
import { ApiError } from "@/lib/http";

export type ActiveCredential = {
  id: string;
  apiKey: string;
  model: string;
  last4: string;
  status: string;
  verifiedAt: Date | null;
};

/**
 * Resolves the user's own Gemini key.
 * Priority: the installation-scoped row (Keystore analogue) → the account row.
 * The plaintext key never leaves this server module.
 */
export async function resolveCredential(userId: string): Promise<ActiveCredential | null> {
  const deviceId = await getDeviceId();
  let row = deviceId
    ? (await db.select().from(credentials).where(eq(credentials.deviceId, deviceId)).limit(1))[0]
    : undefined;

  if (!row && userId) {
    row = (
      await db.select().from(credentials).where(eq(credentials.userId, userId)).orderBy(desc(credentials.updatedAt)).limit(1)
    )[0];
  }

  if (!row) return null;

  // Link a device-scoped credential to the signed-in account on first use.
  if (!row.userId && userId) {
    await db.update(credentials).set({ userId }).where(eq(credentials.id, row.id));
  }

  try {
    return {
      id: row.id,
      apiKey: decryptSecret(row.keyCipher),
      model: row.model,
      last4: row.keyLast4,
      status: row.status,
      verifiedAt: row.verifiedAt,
    };
  } catch {
    await db.update(credentials).set({ status: "invalid" }).where(eq(credentials.id, row.id));
    return null;
  }
}

export async function requireCredential(userId: string): Promise<ActiveCredential> {
  const credential = await resolveCredential(userId);
  if (!credential) {
    throw new ApiError(428, "gemini_not_connected", "No Gemini key is connected on this device.", "Reconnect your Gemini API key to continue.");
  }
  if (credential.status === "invalid") {
    throw new ApiError(428, "gemini_invalid", "The saved Gemini key is no longer valid.", "Reconnect with a fresh API key.");
  }
  return credential;
}

export async function saveCredential(params: {
  deviceId: string;
  userId: string | null;
  apiKey: string;
  model: string;
}): Promise<void> {
  const now = new Date();
  const values = {
    deviceId: params.deviceId,
    userId: params.userId,
    keyCipher: encryptSecret(params.apiKey),
    keyLast4: last4(params.apiKey),
    model: params.model,
    status: "valid",
    verifiedAt: now,
    updatedAt: now,
  };
  await db
    .insert(credentials)
    .values(values)
    .onConflictDoUpdate({
      target: credentials.deviceId,
      set: {
        userId: params.userId,
        keyCipher: values.keyCipher,
        keyLast4: values.keyLast4,
        model: values.model,
        status: "valid",
        verifiedAt: now,
        updatedAt: now,
      },
    });
}

export async function markCredentialStatus(credentialId: string, status: "valid" | "invalid"): Promise<void> {
  await db.update(credentials).set({ status, updatedAt: new Date() }).where(eq(credentials.id, credentialId));
}

export async function updateCredentialModel(credentialId: string, model: string): Promise<void> {
  await db.update(credentials).set({ model, updatedAt: new Date() }).where(eq(credentials.id, credentialId));
}

export async function disconnectCredential(userId: string): Promise<void> {
  const deviceId = await getDeviceId();
  if (deviceId) {
    await db.delete(credentials).where(eq(credentials.deviceId, deviceId));
  }
  if (userId) {
    await db.delete(credentials).where(and(eq(credentials.userId, userId)));
  }
}

export async function hasCredential(userId: string | null): Promise<{ connected: boolean; model?: string; last4?: string; status?: string }> {
  const deviceId = await getDeviceId();
  let row = deviceId
    ? (await db.select().from(credentials).where(eq(credentials.deviceId, deviceId)).limit(1))[0]
    : undefined;
  if (!row && userId) {
    row = (await db.select().from(credentials).where(eq(credentials.userId, userId)).limit(1))[0];
  }
  if (!row) return { connected: false };
  return { connected: true, model: row.model, last4: row.keyLast4, status: row.status };
}
