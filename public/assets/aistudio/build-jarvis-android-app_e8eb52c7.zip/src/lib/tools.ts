import { and, desc, eq, ilike, or, sql } from "drizzle-orm";
import { db } from "@/db";
import { conversations, memories, messages, notes, reminders, tasks } from "@/db/schema";
import { safeCalculate } from "@/lib/calc";

export type GeminiFunctionDeclaration = {
  name: string;
  description: string;
  parameters: {
    type: "OBJECT";
    properties: Record<string, { type: string; description: string; enum?: string[] }>;
    required?: string[];
  };
};

export const TOOL_DECLARATIONS: GeminiFunctionDeclaration[] = [
  {
    name: "create_task",
    description: "Create a task/to-do for the user. Use whenever the user asks to be reminded to do something or wants a task tracked.",
    parameters: {
      type: "OBJECT",
      properties: {
        title: { type: "STRING", description: "Short task title" },
        description: { type: "STRING", description: "Optional detail" },
        dueAt: { type: "STRING", description: "Optional ISO-8601 datetime for the due date" },
        priority: { type: "STRING", description: "low, normal or high", enum: ["low", "normal", "high"] },
      },
      required: ["title"],
    },
  },
  {
    name: "list_tasks",
    description: "List the user's open tasks.",
    parameters: { type: "OBJECT", properties: {}, required: [] },
  },
  {
    name: "complete_task",
    description: "Mark a task as completed. Match by title text.",
    parameters: { type: "OBJECT", properties: { title: { type: "STRING", description: "Task title to match" } }, required: ["title"] },
  },
  {
    name: "create_note",
    description: "Save a note with a title and body.",
    parameters: {
      type: "OBJECT",
      properties: { title: { type: "STRING", description: "Note title" }, content: { type: "STRING", description: "Note body (markdown allowed)" } },
      required: ["title", "content"],
    },
  },
  {
    name: "create_reminder",
    description: "Schedule a local reminder notification for a specific future time.",
    parameters: {
      type: "OBJECT",
      properties: { title: { type: "STRING", description: "Reminder text" }, remindAt: { type: "STRING", description: "ISO-8601 datetime in the user's timezone" } },
      required: ["title", "remindAt"],
    },
  },
  {
    name: "save_memory",
    description: "Persist a long-term memory the user explicitly asked you to remember. Never store secrets, API keys, passwords, or health data.",
    parameters: {
      type: "OBJECT",
      properties: {
        content: { type: "STRING", description: "One concise fact or preference" },
        category: { type: "STRING", description: "preference, project, person, routine or general" },
      },
      required: ["content"],
    },
  },
  {
    name: "calculate",
    description: "Evaluate an arithmetic expression exactly instead of estimating.",
    parameters: {
      type: "OBJECT",
      properties: { expression: { type: "STRING", description: "Arithmetic expression, e.g. (1450*0.18)+32" } },
      required: ["expression"],
    },
  },
  {
    name: "current_datetime",
    description: "Get the current date and time, optionally for an IANA timezone.",
    parameters: { type: "OBJECT", properties: { timezone: { type: "STRING", description: "IANA timezone, e.g. Europe/London" } }, required: [] },
  },
  {
    name: "search_conversations",
    description: "Search the user's saved conversation history for a keyword.",
    parameters: { type: "OBJECT", properties: { query: { type: "STRING", description: "Search term" } }, required: ["query"] },
  },
];

export type ToolContext = { userId: string };

export type ToolOutcome = { result: unknown; summary: string };

function argsRecord(input: unknown): Record<string, unknown> {
  return input && typeof input === "object" ? (input as Record<string, unknown>) : {};
}

function asString(value: unknown, fallback = ""): string {
  return typeof value === "string" ? value : typeof value === "number" ? String(value) : fallback;
}

function parseDate(value: unknown): Date | null {
  const raw = asString(value);
  if (!raw) return null;
  const date = new Date(raw);
  return Number.isNaN(date.getTime()) ? null : date;
}

const MEMORY_BLOCKLIST = /(api[\s_-]?key|password|secret|token|passport|social security|credit card|cvv)/i;

export async function executeTool(name: string, rawArgs: unknown, ctx: ToolContext): Promise<ToolOutcome> {
  const args = argsRecord(rawArgs);
  try {
    switch (name) {
      case "create_task": {
        const title = asString(args.title).trim().slice(0, 200);
        if (!title) return { result: { error: "title required" }, summary: "Task not created" };
        const [row] = await db
          .insert(tasks)
          .values({
            userId: ctx.userId,
            title,
            description: asString(args.description).slice(0, 1000),
            dueAt: parseDate(args.dueAt),
            priority: ["low", "normal", "high"].includes(asString(args.priority)) ? asString(args.priority) : "normal",
          })
          .returning();
        return { result: { id: row.id, title: row.title, dueAt: row.dueAt }, summary: `Task created: ${row.title}` };
      }
      case "list_tasks": {
        const rows = await db
          .select()
          .from(tasks)
          .where(and(eq(tasks.userId, ctx.userId), eq(tasks.completed, false)))
          .orderBy(tasks.createdAt)
          .limit(25);
        return { result: rows.map((t) => ({ title: t.title, dueAt: t.dueAt, priority: t.priority })), summary: `${rows.length} open task(s)` };
      }
      case "complete_task": {
        const title = asString(args.title).trim();
        const [row] = await db
          .update(tasks)
          .set({ completed: true, updatedAt: new Date() })
          .where(and(eq(tasks.userId, ctx.userId), sql`lower(${tasks.title}) like ${`%${title.toLowerCase()}%`}`))
          .returning();
        return row
          ? { result: { completed: row.title }, summary: `Task completed: ${row.title}` }
          : { result: { error: "no matching task" }, summary: "No matching task found" };
      }
      case "create_note": {
        const title = asString(args.title).trim().slice(0, 160) || "Untitled note";
        const [row] = await db
          .insert(notes)
          .values({ userId: ctx.userId, title, content: asString(args.content).slice(0, 20000) })
          .returning();
        return { result: { id: row.id, title: row.title }, summary: `Note saved: ${row.title}` };
      }
      case "create_reminder": {
        const remindAt = parseDate(args.remindAt);
        if (!remindAt) return { result: { error: "remindAt must be an ISO datetime" }, summary: "Reminder not scheduled" };
        const [row] = await db
          .insert(reminders)
          .values({ userId: ctx.userId, title: asString(args.title).trim().slice(0, 200) || "Reminder", remindAt })
          .returning();
        return { result: { id: row.id, remindAt: row.remindAt }, summary: `Reminder scheduled for ${remindAt.toISOString()}` };
      }
      case "save_memory": {
        const content = asString(args.content).trim().slice(0, 500);
        if (!content) return { result: { error: "content required" }, summary: "Memory not saved" };
        if (MEMORY_BLOCKLIST.test(content)) {
          return { result: { error: "refused: sensitive data" }, summary: "Refused to store sensitive memory" };
        }
        const category = ["preference", "project", "person", "routine", "general"].includes(asString(args.category))
          ? asString(args.category)
          : "general";
        const [row] = await db.insert(memories).values({ userId: ctx.userId, content, category }).returning();
        return { result: { id: row.id, category }, summary: `Memory stored (${category})` };
      }
      case "calculate": {
        const expression = asString(args.expression);
        const value = safeCalculate(expression);
        return { result: { expression, value }, summary: `${expression} = ${value}` };
      }
      case "current_datetime": {
        const tz = asString(args.timezone) || "UTC";
        let formatted: string;
        try {
          formatted = new Intl.DateTimeFormat("en-GB", {
            dateStyle: "full",
            timeStyle: "long",
            timeZone: tz,
          }).format(new Date());
        } catch {
          formatted = new Date().toISOString();
        }
        return { result: { iso: new Date().toISOString(), timezone: tz, formatted }, summary: formatted };
      }
      case "search_conversations": {
        const query = asString(args.query).trim();
        if (!query) return { result: [], summary: "Empty search" };
        const rows = await db
          .select({ conversationId: conversations.id, title: conversations.title, content: messages.content })
          .from(messages)
          .innerJoin(conversations, eq(conversations.id, messages.conversationId))
          .where(and(eq(messages.userId, ctx.userId), or(ilike(messages.content, `%${query}%`), ilike(conversations.title, `%${query}%`))))
          .orderBy(desc(messages.createdAt))
          .limit(8);
        return { result: rows, summary: `${rows.length} matching message(s) for "${query}"` };
      }
      default:
        return { result: { error: "unknown tool" }, summary: `Unknown tool: ${name}` };
    }
  } catch (error) {
    return {
      result: { error: error instanceof Error ? error.message : "tool failure" },
      summary: `Tool ${name} failed`,
    };
  }
}
