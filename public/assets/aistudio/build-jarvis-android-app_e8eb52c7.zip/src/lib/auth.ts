import { cookies } from "next/headers";
import { and, eq, gt } from "drizzle-orm";
import { cache } from "react";
import { db } from "@/db";
import { sessions, userSettings, users } from "@/db/schema";
import { randomToken, sha256 } from "@/lib/crypto";
import { ApiError } from "@/lib/http";

export const SESSION_COOKIE = "jarvis_session";
export const DEVICE_COOKIE = "jarvis_device";
const SESSION_TTL_MS = 1000 * 60 * 60 * 24 * 30;

export type SessionUser = {
  id: string;
  email: string;
  displayName: string;
  emailVerified: boolean;
  createdAt: Date;
};

export const getSessionUser = cache(async (): Promise<SessionUser | null> => {
  const jar = await cookies();
  const token = jar.get(SESSION_COOKIE)?.value;
  if (!token) return null;

  const rows = await db
    .select({
      id: users.id,
      email: users.email,
      displayName: users.displayName,
      emailVerified: users.emailVerified,
      createdAt: users.createdAt,
    })
    .from(sessions)
    .innerJoin(users, eq(users.id, sessions.userId))
    .where(and(eq(sessions.tokenHash, sha256(token)), gt(sessions.expiresAt, new Date())))
    .limit(1);

  return rows[0] ?? null;
});

export async function requireUser(): Promise<SessionUser> {
  const user = await getSessionUser();
  if (!user) {
    throw new ApiError(401, "unauthenticated", "Sign in to continue.", "Complete account setup to open JARVIS.");
  }
  return user;
}

export async function createSession(userId: string): Promise<void> {
  const token = randomToken(32);
  await db.insert(sessions).values({
    userId,
    tokenHash: sha256(token),
    expiresAt: new Date(Date.now() + SESSION_TTL_MS),
  });
  const jar = await cookies();
  jar.set(SESSION_COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: SESSION_TTL_MS / 1000,
  });
}

export async function destroySession(): Promise<void> {
  const jar = await cookies();
  const token = jar.get(SESSION_COOKIE)?.value;
  if (token) {
    await db.delete(sessions).where(eq(sessions.tokenHash, sha256(token)));
  }
  jar.delete(SESSION_COOKIE);
}

export async function getDeviceId(): Promise<string | null> {
  const jar = await cookies();
  return jar.get(DEVICE_COOKIE)?.value ?? null;
}

export async function setDeviceId(deviceId: string): Promise<void> {
  const jar = await cookies();
  jar.set(DEVICE_COOKIE, deviceId, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: 60 * 60 * 24 * 365,
  });
}

export function newDeviceId(): string {
  return `dev_${randomToken(18)}`;
}

export const DEFAULT_SETTINGS = {
  personality: "jarvis",
  customPersonality: null as string | null,
  humor: 2,
  expressiveness: 2,
  responseLength: "balanced",
  autoSpeak: true,
  animations: true,
  memoryEnabled: true,
  voiceRate: 1,
  voicePitch: 0.95,
  voiceName: null as string | null,
  model: "gemini-2.5-flash",
  temperature: 0.8,
};

export type AssistantSettings = typeof DEFAULT_SETTINGS;

export async function getSettings(userId: string): Promise<AssistantSettings> {
  const existing = await db.select().from(userSettings).where(eq(userSettings.userId, userId)).limit(1);
  if (existing[0]) {
    const row = existing[0];
    return {
      personality: row.personality,
      customPersonality: row.customPersonality,
      humor: row.humor,
      expressiveness: row.expressiveness,
      responseLength: row.responseLength,
      autoSpeak: row.autoSpeak,
      animations: row.animations,
      memoryEnabled: row.memoryEnabled,
      voiceRate: row.voiceRate,
      voicePitch: row.voicePitch,
      voiceName: row.voiceName,
      model: row.model,
      temperature: row.temperature,
    };
  }
  await db.insert(userSettings).values({ userId }).onConflictDoNothing();
  return { ...DEFAULT_SETTINGS };
}

export function isValidEmail(email: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email);
}

export function passwordProblem(password: string): string | null {
  if (password.length < 8) return "Password must be at least 8 characters.";
  if (!/[a-zA-Z]/.test(password) || !/[0-9]/.test(password)) {
    return "Password needs at least one letter and one number.";
  }
  return null;
}
