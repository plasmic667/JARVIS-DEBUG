/**
 * Recursive-descent arithmetic evaluator — no eval, no arbitrary code.
 * Kept dependency-free so it can be unit tested in isolation.
 */
export function safeCalculate(rawExpression: string): number {
  const expr = rawExpression
    .replace(/,/g, ".")
    .replace(/[×x]/g, "*")
    .replace(/÷/g, "/")
    .replace(/\s+/g, "");
  if (!expr || expr.length > 200 || /[^0-9+\-*/%^().a-z]/i.test(expr)) {
    throw new Error("Unsupported characters in expression");
  }
  let pos = 0;

  const eat = (token: string) => {
    if (expr.startsWith(token, pos)) {
      pos += token.length;
      return true;
    }
    return false;
  };

  const parseExpression = (): number => {
    let value = parseTerm();
    for (;;) {
      if (eat("+")) value += parseTerm();
      else if (eat("-")) value -= parseTerm();
      else return value;
    }
  };

  const parseTerm = (): number => {
    let value = parseFactor();
    for (;;) {
      if (eat("*")) value *= parseFactor();
      else if (eat("/")) value /= parseFactor();
      else if (eat("%")) value %= parseFactor();
      else return value;
    }
  };

  const parseFactor = (): number => {
    const base = parseUnary();
    if (eat("^")) return Math.pow(base, parseFactor());
    return base;
  };

  const parseUnary = (): number => {
    if (eat("-")) return -parseUnary();
    if (eat("+")) return parseUnary();
    return parsePrimary();
  };

  const parsePrimary = (): number => {
    if (eat("(")) {
      const value = parseExpression();
      if (!eat(")")) throw new Error("Missing closing parenthesis");
      return value;
    }
    const fnMatch = expr.slice(pos).match(/^(sqrt|sin|cos|tan|log|ln|abs|round|floor|ceil)/);
    if (fnMatch) {
      pos += fnMatch[1].length;
      if (!eat("(")) throw new Error("Missing function parentheses");
      const arg = parseExpression();
      if (!eat(")")) throw new Error("Missing closing parenthesis");
      const fns: Record<string, (n: number) => number> = {
        sqrt: Math.sqrt,
        sin: Math.sin,
        cos: Math.cos,
        tan: Math.tan,
        log: Math.log10,
        ln: Math.log,
        abs: Math.abs,
        round: Math.round,
        floor: Math.floor,
        ceil: Math.ceil,
      };
      return fns[fnMatch[1]](arg);
    }
    const constant = expr.slice(pos).match(/^(pi|e)/);
    if (constant) {
      pos += constant[1].length;
      return constant[1] === "pi" ? Math.PI : Math.E;
    }
    const number = expr.slice(pos).match(/^\d*\.?\d+/);
    if (!number) throw new Error("Expected a number");
    pos += number[0].length;
    return Number.parseFloat(number[0]);
  };

  const result = parseExpression();
  if (pos !== expr.length) throw new Error("Unexpected trailing input");
  if (!Number.isFinite(result)) throw new Error("Result is not a finite number");
  return result;
}
