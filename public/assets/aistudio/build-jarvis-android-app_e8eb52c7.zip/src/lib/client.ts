"use client";

export type ApiResult<T> = ({ ok: true } & T) | { ok: false; error: { code: string; message: string; hint?: string } };

export class ClientError extends Error {
  code: string;
  hint?: string;
  status: number;

  constructor(message: string, code = "error", status = 0, hint?: string) {
    super(message);
    this.code = code;
    this.status = status;
    this.hint = hint;
  }
}

export async function api<T>(url: string, init?: RequestInit): Promise<T> {
  const response = await fetch(url, {
    ...init,
    headers: {
      "Content-Type": "application/json",
      ...(init?.headers ?? {}),
    },
    cache: "no-store",
  });
  let payload: unknown = null;
  try {
    payload = await response.json();
  } catch {
    payload = null;
  }
  if (!response.ok) {
    const error = (payload as { error?: { message?: string; code?: string; hint?: string } } | null)?.error;
    throw new ClientError(error?.message ?? `Request failed (${response.status})`, error?.code ?? "http_error", response.status, error?.hint);
  }
  return payload as T;
}

export type SessionResponse = {
  ok: true;
  authenticated: boolean;
  user: { id: string; email: string; displayName: string; emailVerified: boolean; createdAt: string } | null;
  gemini: { connected: boolean; model?: string; last4?: string; status?: string };
  settings: AssistantSettings | null;
  nextStep: "connect_gemini" | "authenticate" | "dashboard";
};

export type AssistantSettings = {
  personality: string;
  customPersonality: string | null;
  humor: number;
  expressiveness: number;
  responseLength: string;
  autoSpeak: boolean;
  animations: boolean;
  memoryEnabled: boolean;
  voiceRate: number;
  voicePitch: number;
  voiceName: string | null;
  model: string;
  temperature: number;
};

export type ConversationRow = {
  id: string;
  title: string;
  lastMessagePreview: string;
  pinned: boolean;
  createdAt: string;
  updatedAt: string;
};

export type MessageRow = {
  id: string;
  conversationId: string;
  role: "user" | "assistant";
  content: string;
  status: string;
  metadata?: { model?: string; tools?: Array<{ name: string; summary: string }>; latencyMs?: number } | null;
  createdAt: string;
};

export type MemoryRow = { id: string; content: string; category: string; createdAt: string; updatedAt: string };
export type NoteRow = { id: string; title: string; content: string; createdAt: string; updatedAt: string };
export type TaskRow = {
  id: string;
  title: string;
  description: string;
  dueAt: string | null;
  priority: string;
  completed: boolean;
  createdAt: string;
  updatedAt: string;
};
export type ReminderRow = { id: string; title: string; remindAt: string; status: string; createdAt: string };

export type OverviewResponse = {
  ok: true;
  authenticated: boolean;
  user?: { id: string; email: string; displayName: string; emailVerified: boolean };
  settings?: AssistantSettings;
  gemini?: { connected: boolean; model?: string; last4?: string; status?: string };
  stats?: {
    conversations: number;
    messages: number;
    memories: number;
    notes: number;
    openTasks: number;
    reminders: number;
    requestsToday: number;
  };
  recentConversations?: ConversationRow[];
  openTasks?: TaskRow[];
  upcomingReminders?: ReminderRow[];
  memoryPreview?: Array<{ content: string; category: string }>;
};

export type ChatStreamEvent =
  | { type: "meta"; conversationId: string; model: string }
  | { type: "token"; value: string }
  | { type: "tool"; name: string; summary: string }
  | { type: "done"; messageId: string; latencyMs: number; tools: Array<{ name: string; summary: string }>; content: string }
  | { type: "error"; code: string; message: string; hint?: string; partial: string };

export async function streamChat(
  body: { conversationId?: string; message?: string; regenerate?: boolean },
  handlers: {
    onEvent: (event: ChatStreamEvent) => void;
    signal?: AbortSignal;
  },
): Promise<void> {
  const response = await fetch("/api/chat", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
    signal: handlers.signal,
  });

  if (!response.ok) {
    let message = `Request failed (${response.status})`;
    let code = "http_error";
    let hint: string | undefined;
    try {
      const payload = (await response.json()) as { error?: { message?: string; code?: string; hint?: string } };
      message = payload.error?.message ?? message;
      code = payload.error?.code ?? code;
      hint = payload.error?.hint;
    } catch {
      /* ignore */
    }
    handlers.onEvent({ type: "error", code, message, hint, partial: "" });
    return;
  }

  if (!response.body) {
    handlers.onEvent({ type: "error", code: "no_body", message: "The response stream could not be opened.", partial: "" });
    return;
  }

  const reader = response.body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";
  while (true) {
    const { value, done } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split("\n");
    buffer = lines.pop() ?? "";
    for (const line of lines) {
      const trimmed = line.trim();
      if (!trimmed.startsWith("data:")) continue;
      try {
        handlers.onEvent(JSON.parse(trimmed.slice(5).trim()) as ChatStreamEvent);
      } catch {
        /* malformed frame — skip */
      }
    }
  }
}

export function formatWhen(value: string | null | undefined): string {
  if (!value) return "No date";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "Invalid date";
  return date.toLocaleString(undefined, { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" });
}

export function relativeTime(value: string): string {
  const date = new Date(value);
  const diff = Date.now() - date.getTime();
  const minutes = Math.round(diff / 60000);
  if (minutes < 1) return "just now";
  if (minutes < 60) return `${minutes}m ago`;
  const hours = Math.round(minutes / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.round(hours / 24);
  if (days < 7) return `${days}d ago`;
  return date.toLocaleDateString();
}
