import { redactSecrets } from "@/lib/crypto";
import type { GeminiFunctionDeclaration } from "@/lib/tools";

const API_ROOT = "https://generativelanguage.googleapis.com/v1beta";

export const DEFAULT_MODEL = "gemini-2.5-flash";
export const FALLBACK_MODELS = [
  "gemini-2.5-flash",
  "gemini-2.5-pro",
  "gemini-2.5-flash-lite",
  "gemini-flash-latest",
  "gemini-pro-latest",
];

export type GeminiPart = {
  text?: string;
  functionCall?: { name: string; args?: Record<string, unknown> };
  functionResponse?: { name: string; response: Record<string, unknown> };
  /** Gemini 2.5 thinking models require this opaque signature to be echoed back with tool results. */
  thoughtSignature?: string;
};

export type GeminiContent = { role: "user" | "model"; parts: GeminiPart[] };

export type GeminiErrorCode =
  | "invalid_key"
  | "permission_denied"
  | "model_unavailable"
  | "quota_exceeded"
  | "rate_limited"
  | "provider_unavailable"
  | "network_error"
  | "bad_request"
  | "cancelled"
  | "unknown";

export class GeminiError extends Error {
  code: GeminiErrorCode;
  status: number;
  hint?: string;

  constructor(code: GeminiErrorCode, status: number, message: string, hint?: string) {
    super(message);
    this.code = code;
    this.status = status;
    this.hint = hint;
  }
}

export type KeyValidation =
  | { ok: true; model: string; latencyMs: number; sample: string }
  | { ok: false; code: GeminiErrorCode; message: string; hint?: string };

function mapStatus(status: number, body: string): GeminiError {
  const lower = body.toLowerCase();
  if (lower.includes("api key not valid") || lower.includes("api_key_invalid") || status === 401) {
    return new GeminiError(
      "invalid_key",
      401,
      "Gemini rejected this API key.",
      "Copy the key again from Google AI Studio → Get API key. Keys start with AIza.",
    );
  }
  if (status === 403) {
    return new GeminiError("permission_denied", 403, "This key is not permitted to use the Generative Language API.", "Enable the Generative Language API for the key's project.");
  }
  if (status === 404) {
    return new GeminiError("model_unavailable", 404, "That Gemini model is not available for this key.", "Pick another model from the list and reconnect.");
  }
  if (status === 429 && (lower.includes("quota") || lower.includes("billing"))) {
    return new GeminiError("quota_exceeded", 429, "Your Gemini quota is exhausted right now.", "Check your plan/billing in Google AI Studio, or retry after the quota window resets.");
  }
  if (status === 429) {
    return new GeminiError("rate_limited", 429, "Gemini is rate-limiting this key.", "Wait a few seconds, then retry.");
  }
  if (status >= 500) {
    return new GeminiError("provider_unavailable", status, "Gemini is temporarily unavailable.", "This is on Google's side. Retry in a moment.");
  }
  return new GeminiError("bad_request", status, "Gemini rejected the request.", body ? redactSecrets(body).slice(0, 240) : undefined);
}

async function post(path: string, apiKey: string, body: unknown, signal?: AbortSignal): Promise<Response> {
  try {
    return await fetch(`${API_ROOT}/${path}`, {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-goog-api-key": apiKey },
      body: JSON.stringify(body),
      signal,
      cache: "no-store",
    });
  } catch (error) {
    if (error instanceof DOMException && error.name === "AbortError") {
      throw new GeminiError("cancelled", 499, "Request cancelled.");
    }
    throw new GeminiError("network_error", 0, "Could not reach the Gemini API.", "Check your connection or the server's outbound network access.");
  }
}

/** Real validation: a live generateContent round-trip, never a format guess. */
export async function validateGeminiKey(apiKey: string, model: string): Promise<KeyValidation> {
  const started = Date.now();
  try {
    const response = await post(
      `models/${encodeURIComponent(model)}:generateContent`,
      apiKey,
      {
        contents: [{ role: "user", parts: [{ text: "Reply with exactly one word: online" }] }],
        generationConfig: { maxOutputTokens: 24, temperature: 0 },
      },
      AbortSignal.timeout(25_000),
    );
    const raw = await response.text();
    if (!response.ok) {
      const mapped = mapStatus(response.status, raw);
      return { ok: false, code: mapped.code, message: mapped.message, hint: mapped.hint };
    }
    let sample = "";
    try {
      const parsed = JSON.parse(raw) as {
        candidates?: Array<{ content?: { parts?: Array<{ text?: string }> } }>;
      };
      sample = parsed.candidates?.[0]?.content?.parts?.map((p) => p.text ?? "").join("") ?? "";
    } catch {
      sample = "";
    }
    return { ok: true, model, latencyMs: Date.now() - started, sample: sample.slice(0, 80) };
  } catch (error) {
    if (error instanceof GeminiError) {
      return { ok: false, code: error.code, message: error.message, hint: error.hint };
    }
    return { ok: false, code: "unknown", message: "Could not verify the key." };
  }
}

export type GeminiModel = { id: string; displayName: string; description: string };

export async function listGeminiModels(apiKey: string): Promise<GeminiModel[]> {
  const response = await fetch(`${API_ROOT}/models?pageSize=100`, {
    headers: { "x-goog-api-key": apiKey },
    cache: "no-store",
    signal: AbortSignal.timeout(20_000),
  });
  const raw = await response.text();
  if (!response.ok) throw mapStatus(response.status, raw);
  const parsed = JSON.parse(raw) as {
    models?: Array<{
      name?: string;
      displayName?: string;
      description?: string;
      supportedGenerationMethods?: string[];
    }>;
  };
  return (parsed.models ?? [])
    .filter((m) => (m.supportedGenerationMethods ?? []).includes("generateContent"))
    .map((m) => ({
      id: (m.name ?? "").replace(/^models\//, ""),
      displayName: m.displayName ?? (m.name ?? "").replace(/^models\//, ""),
      description: m.description ?? "",
    }))
    .filter((m) => m.id && !m.id.includes("embedding") && !m.id.includes("aqa"))
    .sort((a, b) => a.id.localeCompare(b.id));
}

type StreamOptions = {
  apiKey: string;
  model: string;
  contents: GeminiContent[];
  systemInstruction: string;
  temperature: number;
  maxOutputTokens: number;
  tools?: GeminiFunctionDeclaration[];
  signal?: AbortSignal;
};

export type StreamSummary = {
  functionCalls: Array<{ name: string; args: Record<string, unknown> }>;
  /** Raw function-call parts (including thoughtSignature) to send back to Gemini. */
  rawParts: GeminiPart[];
  text: string;
  finishReason?: string;
};

/**
 * Streams Gemini tokens over SSE. Yields text deltas and, once complete,
 * returns any requested function calls so the caller can run tools.
 */
export async function* streamGeminiText(options: StreamOptions): AsyncGenerator<string, StreamSummary, void> {
  const body: Record<string, unknown> = {
    contents: options.contents,
    systemInstruction: { parts: [{ text: options.systemInstruction }] },
    generationConfig: {
      temperature: options.temperature,
      maxOutputTokens: options.maxOutputTokens,
    },
  };
  if (options.tools?.length) {
    body.tools = [{ functionDeclarations: options.tools }];
  }

  const response = await post(
    `models/${encodeURIComponent(options.model)}:streamGenerateContent?alt=sse`,
    options.apiKey,
    body,
    options.signal ?? AbortSignal.timeout(120_000),
  );

  if (!response.ok || !response.body) {
    const raw = await response.text().catch(() => "");
    throw mapStatus(response.status, raw);
  }

  const reader = response.body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";
  let text = "";
  let finishReason: string | undefined;
  const functionCalls: Array<{ name: string; args: Record<string, unknown> }> = [];
  const rawParts: GeminiPart[] = [];

  try {
    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split("\n");
      buffer = lines.pop() ?? "";
      for (const line of lines) {
        const trimmed = line.trim();
        if (!trimmed.startsWith("data:")) continue;
        const payload = trimmed.slice(5).trim();
        if (!payload || payload === "[DONE]") continue;
        let parsed: {
          candidates?: Array<{
            content?: { parts?: GeminiPart[] };
            finishReason?: string;
          }>;
          promptFeedback?: { blockReason?: string };
        };
        try {
          parsed = JSON.parse(payload);
        } catch {
          continue;
        }
        if (parsed.promptFeedback?.blockReason) {
          throw new GeminiError("bad_request", 400, "Gemini blocked this request for safety reasons.", "Rephrase the prompt without disallowed content.");
        }
        const candidate = parsed.candidates?.[0];
        if (!candidate) continue;
        if (candidate.finishReason) finishReason = candidate.finishReason;
        for (const part of candidate.content?.parts ?? []) {
          if (part.text) {
            text += part.text;
            yield part.text;
          }
          if (part.functionCall?.name) {
            functionCalls.push({
              name: part.functionCall.name,
              args: (part.functionCall.args ?? {}) as Record<string, unknown>,
            });
            // Preserve the part verbatim (thoughtSignature is required by 2.5 models).
            rawParts.push({
              functionCall: { name: part.functionCall.name, args: (part.functionCall.args ?? {}) as Record<string, unknown> },
              ...(part.thoughtSignature ? { thoughtSignature: part.thoughtSignature } : {}),
            });
          }
        }
      }
    }
  } finally {
    reader.releaseLock();
  }

  return { functionCalls, rawParts, text, finishReason };
}

/** Non-streaming helper for document summaries. */
export async function generateGeminiText(options: Omit<StreamOptions, "tools">): Promise<string> {
  const response = await post(
    `models/${encodeURIComponent(options.model)}:generateContent`,
    options.apiKey,
    {
      contents: options.contents,
      systemInstruction: { parts: [{ text: options.systemInstruction }] },
      generationConfig: { temperature: options.temperature, maxOutputTokens: options.maxOutputTokens },
    },
    options.signal ?? AbortSignal.timeout(90_000),
  );
  const raw = await response.text();
  if (!response.ok) throw mapStatus(response.status, raw);
  const parsed = JSON.parse(raw) as { candidates?: Array<{ content?: { parts?: Array<{ text?: string }> } }> };
  return parsed.candidates?.[0]?.content?.parts?.map((p) => p.text ?? "").join("") ?? "";
}

export function maxTokensFor(length: string): number {
  if (length === "concise") return 512;
  if (length === "detailed") return 4096;
  return 1536;
}
