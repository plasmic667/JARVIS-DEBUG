import { redactSecrets } from "@/lib/crypto";

export class ApiError extends Error {
  status: number;
  code: string;
  hint?: string;

  constructor(status: number, code: string, message: string, hint?: string) {
    super(message);
    this.status = status;
    this.code = code;
    this.hint = hint;
  }
}

export type ApiFailure = {
  ok: false;
  error: { code: string; message: string; hint?: string };
};

export function ok<T extends object>(data: T, init?: ResponseInit) {
  return Response.json({ ok: true, ...data }, init);
}

export function fail(error: unknown): Response {
  if (error instanceof ApiError) {
    return Response.json(
      { ok: false, error: { code: error.code, message: error.message, hint: error.hint } },
      { status: error.status },
    );
  }
  const message = redactSecrets(error instanceof Error ? error.message : "Unexpected server error");
  console.error("[api] unhandled error:", message);
  return Response.json(
    { ok: false, error: { code: "internal", message: "Something went wrong on our side." } },
    { status: 500 },
  );
}

export async function readJson<T>(request: Request): Promise<T> {
  try {
    return (await request.json()) as T;
  } catch {
    throw new ApiError(400, "invalid_json", "Request body must be valid JSON.");
  }
}

export function str(value: unknown, field: string, opts: { min?: number; max?: number } = {}): string {
  if (typeof value !== "string") {
    throw new ApiError(400, "validation", `${field} is required.`);
  }
  const trimmed = value.trim();
  const min = opts.min ?? 0;
  const max = opts.max ?? 8000;
  if (trimmed.length < min) throw new ApiError(400, "validation", `${field} is too short.`);
  if (trimmed.length > max) throw new ApiError(400, "validation", `${field} is too long.`);
  return trimmed;
}

export function bool(value: unknown, fallback: boolean): boolean {
  return typeof value === "boolean" ? value : fallback;
}

export function clampNumber(value: unknown, fallback: number, min: number, max: number): number {
  const num = typeof value === "number" ? value : Number(value);
  if (!Number.isFinite(num)) return fallback;
  return Math.min(max, Math.max(min, num));
}

const buckets = new Map<string, { count: number; resetAt: number }>();

/**
 * Lightweight in-process rate limiter. For horizontal scale, back this with
 * Redis / Firestore counters; the call sites stay identical.
 */
export function rateLimit(key: string, limit: number, windowMs: number): void {
  const now = Date.now();
  const bucket = buckets.get(key);
  if (!bucket || bucket.resetAt < now) {
    buckets.set(key, { count: 1, resetAt: now + windowMs });
    return;
  }
  bucket.count += 1;
  if (bucket.count > limit) {
    throw new ApiError(429, "rate_limited", "You are moving faster than my circuits allow. Try again shortly.", "Wait a few seconds and retry.");
  }
}
