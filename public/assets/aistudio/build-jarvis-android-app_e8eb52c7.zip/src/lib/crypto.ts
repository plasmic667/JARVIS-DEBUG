import { createCipheriv, createDecipheriv, createHash, randomBytes, scryptSync, timingSafeEqual } from "node:crypto";

/**
 * Keystore-equivalent secret handling.
 *
 * - User-owned Gemini keys are encrypted with AES-256-GCM before touching the DB.
 * - The master key is derived from JARVIS_VAULT_SECRET (env). In production this
 *   must be a long random value managed by a secret manager, never committed.
 * - Nothing here ever logs key material.
 */

const DEFAULT_DEV_SECRET = "jarvis-local-development-vault-do-not-ship";

function masterKey(): Buffer {
  const secret = process.env.JARVIS_VAULT_SECRET?.trim() || DEFAULT_DEV_SECRET;
  return scryptSync(secret, "jarvis-vault-v1", 32);
}

export function encryptSecret(plaintext: string): string {
  const iv = randomBytes(12);
  const cipher = createCipheriv("aes-256-gcm", masterKey(), iv);
  const encrypted = Buffer.concat([cipher.update(plaintext, "utf8"), cipher.final()]);
  const tag = cipher.getAuthTag();
  return `v1.${iv.toString("base64url")}.${tag.toString("base64url")}.${encrypted.toString("base64url")}`;
}

export function decryptSecret(payload: string): string {
  const [version, ivB64, tagB64, dataB64] = payload.split(".");
  if (version !== "v1" || !ivB64 || !tagB64 || !dataB64) {
    throw new Error("Unsupported credential payload");
  }
  const decipher = createDecipheriv("aes-256-gcm", masterKey(), Buffer.from(ivB64, "base64url"));
  decipher.setAuthTag(Buffer.from(tagB64, "base64url"));
  return Buffer.concat([decipher.update(Buffer.from(dataB64, "base64url")), decipher.final()]).toString("utf8");
}

export function last4(value: string): string {
  return value.trim().slice(-4);
}

/** Password hashing with scrypt (server-side only). */
export function hashPassword(password: string): string {
  const salt = randomBytes(16);
  const hash = scryptSync(password, salt, 64);
  return `scrypt.${salt.toString("base64url")}.${hash.toString("base64url")}`;
}

export function verifyPassword(password: string, stored: string): boolean {
  const [scheme, saltB64, hashB64] = stored.split(".");
  if (scheme !== "scrypt" || !saltB64 || !hashB64) return false;
  const expected = Buffer.from(hashB64, "base64url");
  const actual = scryptSync(password, Buffer.from(saltB64, "base64url"), expected.length);
  return expected.length === actual.length && timingSafeEqual(expected, actual);
}

export function randomToken(bytes = 32): string {
  return randomBytes(bytes).toString("base64url");
}

export function sha256(value: string): string {
  return createHash("sha256").update(value).digest("hex");
}

/** Mask any accidental secret material before it reaches a log or UI error. */
export function redactSecrets(input: string): string {
  return input
    .replace(/AIza[0-9A-Za-z\-_]{20,}/g, "AIza••••REDACTED")
    .replace(/key=[0-9A-Za-z\-_]{10,}/g, "key=REDACTED")
    .replace(/x-goog-api-key[^,\n]*/gi, "x-goog-api-key: REDACTED");
}
