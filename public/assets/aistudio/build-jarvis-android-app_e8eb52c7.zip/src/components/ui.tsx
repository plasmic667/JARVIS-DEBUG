"use client";

import Link from "next/link";
import Markdown from "react-markdown";
import remarkGfm from "remark-gfm";
import type { ReactNode } from "react";

export function Logo({ compact = false, href = "/dashboard" }: { compact?: boolean; href?: string }) {
  return (
    <Link href={href} className="group flex items-center gap-2.5" aria-label="JARVIS AI home">
      <span className="relative grid h-9 w-9 place-items-center rounded-xl border border-fuchsia-400/30 bg-gradient-to-br from-fuchsia-500/25 via-violet-500/20 to-indigo-500/20 shadow-[0_0_28px_-8px_rgba(217,70,239,0.9)]">
        <span
          className="bg-gradient-to-br from-pink-300 via-fuchsia-200 to-violet-300 bg-clip-text font-[var(--font-display)] text-lg font-extrabold text-transparent"
          style={{ fontFamily: "var(--font-display)" }}
        >
          J
        </span>
        <span className="absolute inset-0 rounded-xl ring-1 ring-inset ring-white/10" />
      </span>
      {!compact && (
        <span className="flex flex-col leading-none">
          <span
            className="text-[0.95rem] font-semibold tracking-[0.34em] text-white"
            style={{ fontFamily: "var(--font-display)" }}
          >
            JARVIS
          </span>
          <span className="mt-1 text-[0.5rem] font-medium tracking-[0.42em] text-fuchsia-200/60">AI ASSISTANT</span>
        </span>
      )}
    </Link>
  );
}

export function Spinner({ size = 16, className = "" }: { size?: number; className?: string }) {
  return (
    <span
      className={`inline-block animate-spin rounded-full border-2 border-white/25 border-t-white ${className}`}
      style={{ width: size, height: size }}
      role="status"
      aria-label="Loading"
    />
  );
}

export function Alert({
  kind = "error",
  message,
  hint,
  action,
}: {
  kind?: "error" | "success" | "info" | "warning";
  message: string;
  hint?: string;
  action?: ReactNode;
}) {
  const styles: Record<string, string> = {
    error: "border-rose-400/35 bg-rose-500/10 text-rose-100",
    success: "border-emerald-400/35 bg-emerald-500/10 text-emerald-100",
    info: "border-violet-400/30 bg-violet-500/10 text-violet-100",
    warning: "border-amber-400/35 bg-amber-500/10 text-amber-100",
  };
  const icons: Record<string, string> = { error: "!", success: "✓", info: "i", warning: "!" };
  return (
    <div className={`flex items-start gap-3 rounded-xl border px-3.5 py-3 text-sm ${styles[kind]}`} role={kind === "error" ? "alert" : "status"}>
      <span className="mt-0.5 grid h-5 w-5 shrink-0 place-items-center rounded-full border border-current/40 text-[0.65rem] font-bold">
        {icons[kind]}
      </span>
      <div className="min-w-0 flex-1">
        <p className="font-medium leading-snug">{message}</p>
        {hint && <p className="mt-1 text-xs leading-relaxed opacity-80">{hint}</p>}
        {action && <div className="mt-2">{action}</div>}
      </div>
    </div>
  );
}

export function Toggle({
  checked,
  onChange,
  label,
  description,
  disabled,
}: {
  checked: boolean;
  onChange: (next: boolean) => void;
  label: string;
  description?: string;
  disabled?: boolean;
}) {
  return (
    <div className="flex items-start justify-between gap-4 py-3">
      <div className="min-w-0">
        <p className="text-sm font-medium text-white">{label}</p>
        {description && <p className="mt-0.5 text-xs leading-relaxed text-muted">{description}</p>}
      </div>
      <button
        type="button"
        role="switch"
        aria-checked={checked}
        aria-label={label}
        disabled={disabled}
        onClick={() => onChange(!checked)}
        className={`relative mt-0.5 h-6 w-11 shrink-0 rounded-full border transition-all ${
          checked
            ? "border-fuchsia-300/50 bg-gradient-to-r from-fuchsia-500 to-violet-500 shadow-[0_0_18px_-4px_rgba(217,70,239,0.9)]"
            : "border-white/15 bg-white/5"
        } ${disabled ? "cursor-not-allowed opacity-50" : "cursor-pointer"}`}
      >
        <span
          className={`absolute top-0.5 h-4.5 w-4.5 rounded-full bg-white shadow transition-all ${checked ? "left-[1.35rem]" : "left-0.5"}`}
          style={{ height: "1.125rem", width: "1.125rem" }}
        />
      </button>
    </div>
  );
}

export function Range({
  label,
  value,
  min,
  max,
  step,
  onChange,
  display,
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  step: number;
  onChange: (next: number) => void;
  display?: string;
}) {
  return (
    <label className="block py-2">
      <span className="flex items-center justify-between">
        <span className="label mb-0">{label}</span>
        <span className="mono text-[0.65rem] text-fuchsia-200/80">{display ?? value}</span>
      </span>
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        aria-label={label}
        onChange={(event) => onChange(Number(event.target.value))}
        className="mt-2 h-1.5 w-full cursor-pointer appearance-none rounded-full bg-white/10 accent-fuchsia-400"
      />
    </label>
  );
}

export function Modal({
  open,
  title,
  onClose,
  children,
  width = "max-w-lg",
}: {
  open: boolean;
  title: string;
  onClose: () => void;
  children: ReactNode;
  width?: string;
}) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/70 p-3 backdrop-blur-sm sm:items-center" role="dialog" aria-modal="true" aria-label={title}>
      <div className={`panel w-full ${width} max-h-[88dvh] overflow-y-auto p-5 scroll-thin animate-fade-up`}>
        <div className="mb-4 flex items-center justify-between gap-4">
          <h2 className="text-sm tracking-[0.2em] text-white">{title}</h2>
          <button type="button" onClick={onClose} className="icon-btn" aria-label="Close dialog">
            ✕
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}

export function MarkdownView({ content }: { content: string }) {
  return (
    <div className="markdown-body">
      <Markdown remarkPlugins={[remarkGfm]}>{content}</Markdown>
    </div>
  );
}

export function EmptyState({ icon, title, body, action }: { icon: string; title: string; body: string; action?: ReactNode }) {
  return (
    <div className="flex flex-col items-center justify-center rounded-2xl border border-dashed border-white/12 bg-white/[0.02] px-6 py-10 text-center">
      <span className="mb-3 grid h-11 w-11 place-items-center rounded-full border border-fuchsia-300/25 bg-fuchsia-500/10 text-lg">{icon}</span>
      <p className="text-sm font-semibold tracking-wide text-white">{title}</p>
      <p className="mt-1 max-w-sm text-xs leading-relaxed text-muted">{body}</p>
      {action && <div className="mt-4">{action}</div>}
    </div>
  );
}

export function SectionHeading({ eyebrow, title, action }: { eyebrow: string; title: string; action?: ReactNode }) {
  return (
    <div className="mb-4 flex items-end justify-between gap-3">
      <div>
        <p className="eyebrow">{eyebrow}</p>
        <h2 className="mt-1 text-lg text-white">{title}</h2>
      </div>
      {action}
    </div>
  );
}

export function StatusChip({ connected, model, last4 }: { connected: boolean; model?: string; last4?: string }) {
  if (!connected) {
    return (
      <span className="chip chip-warn">
        <span className="dot" /> Gemini offline
      </span>
    );
  }
  return (
    <span className="chip chip-live" title={`Key ending ${last4 ?? "••••"}`}>
      <span className="dot" /> Gemini live{model ? ` · ${model.replace("gemini-", "")}` : ""}
    </span>
  );
}

export async function requestNotificationPermission(): Promise<NotificationPermission> {
  if (typeof window === "undefined" || !("Notification" in window)) return "denied";
  if (Notification.permission === "granted") return "granted";
  return Notification.requestPermission();
}
