"use client";

import { useEffect, useRef } from "react";

export type OrbState = "idle" | "listening" | "thinking" | "speaking";

type Point = { phi: number; theta: number; seed: number };

const PALETTE = [
  { stop: 0, rgb: [255, 74, 162] },
  { stop: 0.35, rgb: [236, 92, 231] },
  { stop: 0.62, rgb: [176, 108, 255] },
  { stop: 0.85, rgb: [110, 105, 255] },
  { stop: 1, rgb: [72, 132, 255] },
] as const;

function mixColor(t: number): [number, number, number] {
  const clamped = Math.min(1, Math.max(0, t));
  for (let i = 0; i < PALETTE.length - 1; i += 1) {
    const a = PALETTE[i];
    const b = PALETTE[i + 1];
    if (clamped >= a.stop && clamped <= b.stop) {
      const k = (clamped - a.stop) / (b.stop - a.stop || 1);
      return [a.rgb[0] + (b.rgb[0] - a.rgb[0]) * k, a.rgb[1] + (b.rgb[1] - a.rgb[1]) * k, a.rgb[2] + (b.rgb[2] - a.rgb[2]) * k];
    }
  }
  const last = PALETTE[PALETTE.length - 1].rgb;
  return [last[0], last[1], last[2]];
}

function buildPoints(count: number): Point[] {
  const points: Point[] = [];
  const golden = Math.PI * (3 - Math.sqrt(5));
  for (let i = 0; i < count; i += 1) {
    const phi = Math.acos(1 - (2 * (i + 0.5)) / count);
    const theta = golden * i;
    points.push({ phi, theta, seed: (Math.sin(i * 12.9898) * 43758.5453) % 1 });
  }
  return points;
}

/**
 * Particle-sphere "intelligence orb" — recreates the dotted halftone sphere of
 * the reference design with real-time canvas rendering (1800 points, additive
 * blending, depth-based alpha). Degrades to a static frame for reduced motion.
 */
export function Orb({
  state = "idle",
  className = "",
  density = 1800,
}: {
  state?: OrbState;
  className?: string;
  density?: number;
}) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const stateRef = useRef<OrbState>(state);
  stateRef.current = state;

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const context = canvas.getContext("2d", { alpha: true });
    if (!context) return;

    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const points = buildPoints(density);
    let width = 0;
    let height = 0;
    let frame = 0;
    let raf = 0;
    let start = performance.now();

    const resize = () => {
      const rect = canvas.getBoundingClientRect();
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      width = Math.max(1, rect.width);
      height = Math.max(1, rect.height);
      canvas.width = Math.floor(width * dpr);
      canvas.height = Math.floor(height * dpr);
      context.setTransform(dpr, 0, 0, dpr, 0, 0);
    };
    resize();
    const observer = new ResizeObserver(resize);
    observer.observe(canvas);

    const draw = (now: number) => {
      const t = (now - start) / 1000;
      const current = stateRef.current;
      const speed = current === "thinking" ? 2.4 : current === "listening" ? 1.8 : current === "speaking" ? 1.5 : 0.85;
      const radius = Math.min(width, height) * 0.335;
      const cx = width / 2;
      const cy = height / 2;

      context.clearRect(0, 0, width, height);

      // Soft inner atmosphere
      const atmosphere = context.createRadialGradient(cx, cy, radius * 0.15, cx, cy, radius * 1.35);
      atmosphere.addColorStop(0, "rgba(216, 92, 255, 0.20)");
      atmosphere.addColorStop(0.45, "rgba(124, 58, 237, 0.10)");
      atmosphere.addColorStop(1, "rgba(12, 5, 26, 0)");
      context.fillStyle = atmosphere;
      context.beginPath();
      context.arc(cx, cy, radius * 1.35, 0, Math.PI * 2);
      context.fill();

      const rotY = t * 0.16 * speed;
      const tiltX = -0.32 + Math.sin(t * 0.25) * 0.06;
      const breathe = 1 + Math.sin(t * (current === "idle" ? 0.9 : 1.6)) * 0.018;

      context.globalCompositeOperation = "lighter";

      for (let i = 0; i < points.length; i += 1) {
        const p = points[i];
        const ripple =
          1 +
          0.055 * Math.sin(p.phi * 4 + t * 1.35 * speed) * Math.cos(p.theta * 3 + t * 0.85 * speed) +
          0.03 * Math.sin(p.theta * 6 - t * 1.1 * speed);

        const r = radius * ripple * breathe;
        let x = Math.sin(p.phi) * Math.cos(p.theta + rotY) * r;
        let y = Math.cos(p.phi) * r;
        let z = Math.sin(p.phi) * Math.sin(p.theta + rotY) * r;

        // tilt around X axis
        const yTilt = y * Math.cos(tiltX) - z * Math.sin(tiltX);
        const zTilt = y * Math.sin(tiltX) + z * Math.cos(tiltX);
        y = yTilt;
        z = zTilt;

        const perspective = 1 / (1 + z / (radius * 5.2));
        const px = cx + x * perspective;
        const py = cy + y * perspective;
        const depth = (z / radius + 1) / 2; // 0 back → 1 front
        const colorT = 0.5 - y / (radius * 2.1) + (x / (radius * 3.4));
        const [red, green, blue] = mixColor(colorT);
        const alpha = 0.1 + depth * 0.82;
        const size = (0.55 + depth * 1.25) * (0.85 + (p.seed % 1) * 0.3);

        context.fillStyle = `rgba(${Math.round(red)}, ${Math.round(green)}, ${Math.round(blue)}, ${alpha.toFixed(3)})`;
        context.beginPath();
        context.arc(px, py, size, 0, Math.PI * 2);
        context.fill();
      }

      // Speaking / listening energy rings
      if (current !== "idle") {
        const rings = current === "speaking" ? 3 : 2;
        for (let i = 0; i < rings; i += 1) {
          const phase = (t * 0.7 + i * 0.33) % 1;
          context.strokeStyle = `rgba(255, 92, 190, ${(0.4 * (1 - phase)).toFixed(3)})`;
          context.lineWidth = 1;
          context.beginPath();
          context.arc(cx, cy, radius * (1 + phase * 0.55), 0, Math.PI * 2);
          context.stroke();
        }
      }

      context.globalCompositeOperation = "source-over";
      if (!reduced) {
        raf = requestAnimationFrame(draw);
      }
    };

    if (reduced) {
      draw(performance.now());
    } else {
      raf = requestAnimationFrame(draw);
    }

    return () => {
      cancelAnimationFrame(raf);
      observer.disconnect();
      frame += 1;
      void frame;
      start = 0;
    };
  }, [density]);

  return (
    <div className={`orb-frame ${className}`} aria-hidden="true">
      <canvas ref={canvasRef} className="h-full w-full" />
    </div>
  );
}

export function Waveform({ active, bars = 22, className = "" }: { active: boolean; bars?: number; className?: string }) {
  return (
    <div className={`flex h-8 items-center gap-[3px] ${className}`} aria-hidden="true">
      {Array.from({ length: bars }).map((_, index) => (
        <span
          key={index}
          className="wave-bar"
          style={{
            height: `${30 + Math.abs(Math.sin(index * 1.7)) * 70}%`,
            animationDelay: `${(index % 7) * 0.09}s`,
            animationPlayState: active ? "running" : "paused",
            opacity: active ? 1 : 0.35,
          }}
        />
      ))}
    </div>
  );
}
