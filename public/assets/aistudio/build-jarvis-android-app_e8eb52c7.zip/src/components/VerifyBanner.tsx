"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Alert, Spinner } from "@/components/ui";
import { api } from "@/lib/client";

export function VerifyBanner() {
  const router = useRouter();
  const [token, setToken] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState<string | null>(null);

  const resend = async () => {
    setBusy(true);
    setMessage(null);
    try {
      const result = await api<{ message: string; verification?: { token: string } }>("/api/auth/resend-verification", {
        method: "POST",
        body: JSON.stringify({}),
      });
      setToken(result.verification?.token ?? null);
      setMessage(result.verification ? "Verification token generated — use it below." : result.message);
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "Could not generate a link.");
    } finally {
      setBusy(false);
    }
  };

  const verify = async () => {
    if (!token) return;
    setBusy(true);
    try {
      await api("/api/auth/verify", { method: "POST", body: JSON.stringify({ token }) });
      setMessage("Email verified.");
      setToken(null);
      router.refresh();
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "Verification failed.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div>
      <Alert
        kind="warning"
        message="Your email is not verified yet."
        hint="Verification is a real single-use token. This environment has no email provider, so it is delivered to a local inbox."
      />
      <div className="mt-2 flex flex-wrap items-center gap-2">
        <button type="button" onClick={resend} disabled={busy} className="btn btn-outline btn-sm">
          {busy ? <Spinner size={12} /> : null} Send verification token
        </button>
        {token && (
          <button type="button" onClick={verify} disabled={busy} className="btn btn-primary btn-sm">
            Verify now
          </button>
        )}
        {message && <span className="text-[0.7rem] text-muted">{message}</span>}
      </div>
    </div>
  );
}
