"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useRef, useState, type ReactNode } from "react";
import {
  Bell,
  Blocks,
  BrainCircuit,
  History,
  LayoutDashboard,
  LogOut,
  MessageSquare,
  Mic,
  Settings as SettingsIcon,
  ShieldCheck,
} from "lucide-react";
import { Logo, StatusChip } from "@/components/ui";
import { api, type ReminderRow } from "@/lib/client";

const NAV = [
  { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { href: "/chat", label: "Assistant", icon: MessageSquare },
  { href: "/voice", label: "Voice", icon: Mic },
  { href: "/conversations", label: "History", icon: History },
  { href: "/memory", label: "Memory", icon: BrainCircuit },
  { href: "/workspace", label: "Workspace", icon: Blocks },
  { href: "/settings", label: "Settings", icon: SettingsIcon },
];

const MOBILE_NAV = [NAV[0], NAV[1], NAV[2], NAV[5], NAV[6]];

export function AppShell({
  children,
  user,
  gemini,
}: {
  children: ReactNode;
  user: { displayName: string; email: string; emailVerified: boolean };
  gemini: { connected: boolean; model?: string; last4?: string; status?: string };
}) {
  const pathname = usePathname();
  const router = useRouter();
  const [menuOpen, setMenuOpen] = useState(false);
  const [signingOut, setSigningOut] = useState(false);
  const [online, setOnline] = useState(true);
  const notified = useRef<Set<string>>(new Set());

  useEffect(() => {
    const goOnline = () => setOnline(true);
    const goOffline = () => setOnline(false);
    setOnline(navigator.onLine);
    window.addEventListener("online", goOnline);
    window.addEventListener("offline", goOffline);
    return () => {
      window.removeEventListener("online", goOnline);
      window.removeEventListener("offline", goOffline);
    };
  }, []);

  useEffect(() => {
    let cancelled = false;
    const tick = async () => {
      try {
        const data = await api<{ reminders: ReminderRow[] }>("/api/data?type=reminders");
        if (cancelled) return;
        const due = data.reminders.filter(
          (reminder) => reminder.status === "scheduled" && new Date(reminder.remindAt).getTime() <= Date.now(),
        );
        for (const reminder of due) {
          if (!notified.current.has(reminder.id)) {
            notified.current.add(reminder.id);
            if (typeof window !== "undefined" && "Notification" in window && Notification.permission === "granted") {
              new Notification("JARVIS reminder", { body: reminder.title, tag: reminder.id });
            }
          }
          await api("/api/data", {
            method: "PATCH",
            body: JSON.stringify({ type: "reminders", id: reminder.id, status: "fired" }),
          });
        }
      } catch {
        /* offline or unauthenticated — retry next tick */
      }
    };
    void tick();
    const interval = window.setInterval(tick, 30_000);
    return () => {
      cancelled = true;
      window.clearInterval(interval);
    };
  }, []);

  const signOut = async () => {
    setSigningOut(true);
    try {
      await api("/api/auth/logout", { method: "POST", body: JSON.stringify({}) });
      router.replace("/");
      router.refresh();
    } finally {
      setSigningOut(false);
    }
  };

  const initials = user.displayName
    .split(/\s+/)
    .map((part) => part[0])
    .slice(0, 2)
    .join("")
    .toUpperCase();

  return (
    <div className="relative z-10 min-h-dvh">
      <header className="glass-nav sticky top-0 z-40">
        <div className="mx-auto flex h-16 max-w-7xl items-center justify-between gap-4 px-4 sm:px-6">
          <div className="flex items-center gap-6">
            <Logo />
            <nav className="hidden items-center gap-1 lg:flex" aria-label="Primary">
              {NAV.map((item) => {
                const active = pathname === item.href || pathname.startsWith(`${item.href}/`);
                return (
                  <Link
                    key={item.href}
                    href={item.href}
                    aria-current={active ? "page" : undefined}
                    className={`rounded-full px-3.5 py-2 text-[0.62rem] font-semibold uppercase tracking-[0.22em] transition-colors ${
                      active ? "bg-white/10 text-white" : "text-muted hover:bg-white/5 hover:text-white"
                    }`}
                    style={{ fontFamily: "var(--font-display)" }}
                  >
                    {item.label}
                  </Link>
                );
              })}
            </nav>
          </div>

          <div className="flex items-center gap-2.5">
            <div className="hidden sm:block">
              <StatusChip connected={gemini.connected} model={gemini.model} last4={gemini.last4} />
            </div>
            <div className="relative">
              <button
                type="button"
                onClick={() => setMenuOpen((open) => !open)}
                className="flex items-center gap-2 rounded-full border border-white/12 bg-white/5 py-1 pl-1 pr-2.5 transition-colors hover:border-fuchsia-300/40"
                aria-haspopup="menu"
                aria-expanded={menuOpen}
                aria-label="Account menu"
              >
                <span className="grid h-7 w-7 place-items-center rounded-full bg-gradient-to-br from-fuchsia-500 to-indigo-500 text-[0.65rem] font-bold text-white">
                  {initials || "J"}
                </span>
                <span className="hidden max-w-24 truncate text-xs text-white/90 sm:block">{user.displayName.split(" ")[0]}</span>
              </button>
              {menuOpen && (
                <div
                  className="panel absolute right-0 top-12 z-50 w-72 p-4 animate-fade-up"
                  role="menu"
                  onMouseLeave={() => setMenuOpen(false)}
                >
                  <p className="text-sm font-semibold text-white">{user.displayName}</p>
                  <p className="mt-0.5 truncate text-xs text-muted">{user.email}</p>
                  <div className="mt-2 flex items-center gap-1.5 text-[0.65rem] text-muted">
                    <ShieldCheck size={13} className={user.emailVerified ? "text-emerald-300" : "text-amber-300"} />
                    {user.emailVerified ? "Email verified" : "Email not verified"}
                  </div>
                  <div className="my-3 hairline" />
                  <Link href="/settings" onClick={() => setMenuOpen(false)} className="flex items-center gap-2 rounded-lg px-2 py-2 text-xs text-muted hover:bg-white/5 hover:text-white">
                    <SettingsIcon size={14} /> Assistant settings
                  </Link>
                  <Link href="/settings#privacy" onClick={() => setMenuOpen(false)} className="flex items-center gap-2 rounded-lg px-2 py-2 text-xs text-muted hover:bg-white/5 hover:text-white">
                    <Bell size={14} /> Privacy, export &amp; deletion
                  </Link>
                  <button
                    type="button"
                    onClick={signOut}
                    disabled={signingOut}
                    className="flex w-full items-center gap-2 rounded-lg px-2 py-2 text-left text-xs text-rose-200 hover:bg-rose-500/10"
                  >
                    <LogOut size={14} /> {signingOut ? "Signing out…" : "Sign out"}
                  </button>
                  <p className="mt-2 px-2 text-[0.6rem] leading-relaxed text-faint">
                    Your Gemini key is AES-256-GCM encrypted on the server and never shown again.
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>
      </header>

      {!online && (
        <div className="border-b border-amber-300/25 bg-amber-500/10 px-4 py-2 text-center text-[0.7rem] text-amber-100" role="status">
          Offline — saved conversations, notes and tasks stay readable. Live Gemini requests need a connection.
        </div>
      )}

      <main className="mx-auto w-full max-w-7xl px-4 pb-28 pt-6 sm:px-6 lg:pb-12">{children}</main>

      <footer className="mx-auto hidden max-w-7xl items-center justify-between gap-4 border-t border-white/8 px-6 py-5 text-[0.62rem] text-faint lg:flex">
        <span style={{ fontFamily: "var(--font-display)" }} className="tracking-[0.3em]">
          JARVIS AI · PERSONAL INTELLIGENCE
        </span>
        <span>Bring your own Gemini key · Keys encrypted at rest · No credential logging</span>
      </footer>

      <nav
        className="fixed inset-x-0 bottom-0 z-40 border-t border-white/10 bg-[#08040f]/90 pb-[env(safe-area-inset-bottom)] backdrop-blur-xl lg:hidden"
        aria-label="Mobile navigation"
      >
        <div className="flex items-stretch justify-around">
          {MOBILE_NAV.map((item) => {
            const active = pathname === item.href;
            const Icon = item.icon;
            return (
              <Link
                key={item.href}
                href={item.href}
                aria-current={active ? "page" : undefined}
                className={`flex flex-1 flex-col items-center gap-1 py-2.5 text-[0.55rem] uppercase tracking-[0.14em] transition-colors ${
                  active ? "text-fuchsia-200" : "text-faint"
                }`}
              >
                <Icon size={18} strokeWidth={active ? 2.2 : 1.6} />
                {item.label}
              </Link>
            );
          })}
        </div>
      </nav>
    </div>
  );
}
