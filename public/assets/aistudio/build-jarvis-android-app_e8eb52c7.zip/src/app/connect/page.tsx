"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { Eye, EyeOff, KeyRound, Lock, ShieldCheck, Sparkles, ExternalLink, ArrowRight, RotateCcw } from "lucide-react";
import { Orb } from "@/components/Orb";
import { Alert, Logo, Spinner } from "@/components/ui";
import { api, ClientError, type SessionResponse } from "@/lib/client";

const MODEL_OPTIONS = [
  { id: "gemini-2.5-flash", label: "Gemini 2.5 Flash — fastest, recommended" },
  { id: "gemini-2.5-pro", label: "Gemini 2.5 Pro — deepest reasoning" },
  { id: "gemini-2.5-flash-lite", label: "Gemini 2.5 Flash-Lite — lightest quota" },
  { id: "gemini-flash-latest", label: "Gemini Flash (latest alias)" },
];

const AI_STUDIO_URL = "https://aistudio.google.com/app/apikey";

type ConnectSuccess = { connected: boolean; model: string; last4: string; latencyMs: number; sample: string; message: string };

export default function ConnectPage() {
  const router = useRouter();
  const [apiKey, setApiKey] = useState("");
  const [showKey, setShowKey] = useState(false);
  const [model, setModel] = useState(MODEL_OPTIONS[0].id);
  const [status, setStatus] = useState<"idle" | "testing" | "success">("idle");
  const [error, setError] = useState<{ message: string; hint?: string; code?: string } | null>(null);
  const [success, setSuccess] = useState<ConnectSuccess | null>(null);
  const [helpOpen, setHelpOpen] = useState(false);
  const [checking, setChecking] = useState(true);
  const [changeMode, setChangeMode] = useState(false);

  useEffect(() => {
    let active = true;
    const change = new URLSearchParams(window.location.search).get("change") === "1";
    setChangeMode(change);
    api<SessionResponse>("/api/session")
      .then((session) => {
        if (!active) return;
        if (change) {
          // Key replacement flow: stay here, validate the new key before switching.
          setChecking(false);
          return;
        }
        if (session.gemini.connected && session.authenticated) {
          router.replace("/dashboard");
        } else if (session.gemini.connected) {
          router.replace("/auth");
        } else {
          setChecking(false);
        }
      })
      .catch(() => {
        if (active) setChecking(false);
      });
    return () => {
      active = false;
    };
  }, [router]);

  const connect = async () => {
    setError(null);
    setSuccess(null);

    if (!apiKey.trim()) {
      setError({ message: "Enter your Gemini API key to activate JARVIS.", hint: "No key yet? Use “How to get a Gemini API key” below." });
      return;
    }
    if (apiKey.trim().length < 20) {
      setError({ message: "That key looks too short.", hint: "Paste the complete key from Google AI Studio — it usually starts with AIza." });
      return;
    }

    setStatus("testing");
    try {
      const result = await api<{ ok: true } & ConnectSuccess>("/api/gemini", {
        method: "POST",
        body: JSON.stringify({ action: "connect", apiKey: apiKey.trim(), model }),
      });
      setStatus("success");
      setSuccess(result);
      setApiKey("");
      // Advance only after a real successful handshake.
      window.setTimeout(() => {
        router.replace(changeMode ? "/settings" : "/auth");
        router.refresh();
      }, 1200);
    } catch (caught) {
      const clientError = caught instanceof ClientError ? caught : null;
      setStatus("idle");
      setError({
        message: clientError?.message ?? "Could not verify the key.",
        hint: clientError?.hint ?? "Check your connection and try again.",
        code: clientError?.code,
      });
    }
  };

  const retry = () => {
    setError(null);
    setStatus("idle");
    if (apiKey) void connect();
  };

  return (
    <div className="relative z-10 flex min-h-dvh flex-col">
      <header className="relative z-20 mx-auto flex w-full max-w-7xl items-center justify-between px-4 py-5 sm:px-6">
        <Logo href="/connect" />
        <div className="flex items-center gap-2">
          <span className="hidden items-center gap-2 rounded-full border border-white/12 bg-white/5 px-3 py-1.5 text-[0.58rem] uppercase tracking-[0.22em] text-muted sm:flex" style={{ fontFamily: "var(--font-display)" }}>
            <ShieldCheck size={12} className="text-emerald-300" /> Secure setup
          </span>
          <span className="flex items-center gap-1.5 rounded-full border border-white/12 bg-white/5 px-3 py-1.5 text-[0.58rem] uppercase tracking-[0.2em] text-muted" style={{ fontFamily: "var(--font-display)" }}>
            <span className="dot text-fuchsia-300" /> Eng
          </span>
        </div>
      </header>

      <div className="relative flex flex-1 items-center justify-center px-4 pb-14 pt-2 sm:px-6">
        <div className="w-full max-w-3xl text-center">
          {/* Orb hero */}
          <div className="relative mx-auto mb-[-3.5rem] h-64 w-64 sm:h-80 sm:w-80 lg:h-[22rem] lg:w-[22rem]" aria-hidden="true">
            <div className="absolute inset-0 animate-float">
              <Orb state={status === "testing" ? "thinking" : status === "success" ? "speaking" : "idle"} className="h-full w-full" />
            </div>
          </div>

          <div className="relative z-10">
            <p className="eyebrow animate-fade-up">{changeMode ? "Credential replacement · live validation" : "Step 01 · Since 2025"}</p>
            <h1 className="title-gradient mt-3 text-[2rem] leading-[1.05] sm:text-5xl lg:text-[3.6rem] animate-fade-up">
              Connect Your
              <br />
              Intelligence
            </h1>
            <p className="mx-auto mt-4 max-w-xl text-sm leading-relaxed text-muted sm:text-base animate-fade-up">
              Connect your Gemini API key to activate your personal AI assistant. Your key stays encrypted on this device and is
              never shared with other accounts.
            </p>
          </div>

          {/* Credential panel */}
          <div className="panel relative z-10 mx-auto mt-8 max-w-xl p-5 text-left sm:p-6 animate-fade-up">
            <div className="mb-4 flex items-center justify-between">
              <span className="eyebrow">Gemini uplink</span>
              <span className={`chip ${success ? "chip-live" : status === "testing" ? "chip-warn" : ""}`}>
                <span className="dot" />
                {success ? "Connected" : status === "testing" ? "Testing live" : "Awaiting key"}
              </span>
            </div>

            <label htmlFor="gemini-key" className="label">
              Gemini API key
            </label>
            <div className="relative">
              <KeyRound size={16} className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-fuchsia-200/60" />
              <input
                id="gemini-key"
                type={showKey ? "text" : "password"}
                value={apiKey}
                onChange={(event) => setApiKey(event.target.value)}
                onKeyDown={(event) => {
                  if (event.key === "Enter" && status !== "testing") void connect();
                }}
                placeholder="AIzaSy••••••••••••••••••••••••••••"
                autoComplete="off"
                spellCheck={false}
                autoCapitalize="none"
                disabled={status === "testing" || status === "success"}
                className="field field-mono pl-10 pr-12"
                aria-describedby="key-help"
              />
              <button
                type="button"
                onClick={() => setShowKey((visible) => !visible)}
                className="absolute right-2 top-1/2 -translate-y-1/2 rounded-lg p-2 text-muted transition-colors hover:text-white"
                aria-label={showKey ? "Hide API key" : "Show API key"}
              >
                {showKey ? <EyeOff size={16} /> : <Eye size={16} />}
              </button>
            </div>
            <p id="key-help" className="mt-2 flex items-center gap-1.5 text-[0.68rem] text-faint">
              <Lock size={11} /> Encrypted with AES-256-GCM server-side · hidden by default · never logged
            </p>

            <div className="mt-4">
              <label htmlFor="model" className="label">
                Default model
              </label>
              <select id="model" className="field" value={model} onChange={(event) => setModel(event.target.value)} disabled={status !== "idle" && status !== "success"}>
                {MODEL_OPTIONS.map((option) => (
                  <option key={option.id} value={option.id}>
                    {option.label}
                  </option>
                ))}
              </select>
              <p className="mt-1.5 text-[0.68rem] text-faint">
                A live test request runs against this model before the key is saved. Unavailable models are reported, never faked.
              </p>
            </div>

            {error && (
              <div className="mt-4">
                <Alert kind="error" message={error.message} hint={error.hint} />
                <div className="mt-2 flex flex-wrap gap-2">
                  <button type="button" onClick={retry} className="btn btn-outline btn-sm">
                    <RotateCcw size={12} /> Retry test
                  </button>
                  <button type="button" onClick={() => setError(null)} className="btn btn-ghost btn-sm">
                    Edit key
                  </button>
                  {error.code === "invalid_key" && (
                    <a href={AI_STUDIO_URL} target="_blank" rel="noreferrer noopener" className="btn btn-ghost btn-sm">
                      Open AI Studio <ExternalLink size={12} />
                    </a>
                  )}
                </div>
              </div>
            )}

            {success && (
              <div className="mt-4">
                <Alert
                  kind="success"
                  message={`Gemini handshake verified in ${success.latencyMs}ms · key ••••${success.last4}`}
                  hint={`Model ${success.model} replied: “${success.sample || "online"}”. Your credential is encrypted. Redirecting to account setup…`}
                />
              </div>
            )}

            <button
              type="button"
              onClick={connect}
              disabled={status === "testing" || status === "success" || checking}
              className="btn btn-primary mt-5 w-full"
            >
              {status === "testing" ? (
                <>
                  <Spinner size={14} /> Testing live connection…
                </>
              ) : status === "success" ? (
                <>
                  <ShieldCheck size={15} /> Connected
                </>
              ) : (
                <>
                  <Sparkles size={15} /> Connect via Gemini API Key <ArrowRight size={15} />
                </>
              )}
            </button>

            <div className="mt-3 flex flex-col items-center justify-between gap-2 text-[0.7rem] sm:flex-row">
              <button type="button" onClick={() => setHelpOpen((open) => !open)} className="inline-flex items-center gap-1.5 text-fuchsia-200/80 underline decoration-fuchsia-300/40 underline-offset-4 hover:text-white">
                How to get a Gemini API key
              </button>
              <span className="text-faint">No key is bundled with this app.</span>
            </div>

            {helpOpen && (
              <div className="panel-soft mt-4 space-y-2.5 p-4 text-xs leading-relaxed text-muted animate-fade-up">
                <p className="text-white">Four steps, about a minute:</p>
                <ol className="list-decimal space-y-1.5 pl-4">
                  <li>Open Google AI Studio and sign in with your Google account.</li>
                  <li>Choose “Get API key”, then create a key in your own Google Cloud project.</li>
                  <li>Copy the key (it starts with <span className="mono text-fuchsia-200">AIza</span>) and paste it above.</li>
                  <li>Keep it private. You can revoke or rotate it in AI Studio at any time.</li>
                </ol>
                <a href={AI_STUDIO_URL} target="_blank" rel="noreferrer noopener" className="btn btn-outline btn-sm mt-1">
                  Open Google AI Studio <ExternalLink size={12} />
                </a>
                <p className="text-[0.66rem] text-faint">
                  Usage is billed by Google against your own key and quota. JARVIS never proxies your key to another user.
                </p>
              </div>
            )}
          </div>

          {/* Reference-style stat plate */}
          <div className="relative z-10 mx-auto mt-6 flex max-w-xl items-center justify-between gap-3 rounded-2xl border border-white/12 bg-white/[0.04] px-4 py-3 backdrop-blur-xl">
            <div className="text-left">
              <p className="text-[0.55rem] uppercase tracking-[0.3em] text-faint" style={{ fontFamily: "var(--font-display)" }}>
                Credential vault
              </p>
              <p className="mt-1 text-sm font-semibold text-white">Encrypted · device-scoped</p>
            </div>
            <div className="h-8 w-px bg-white/10" />
            <div className="text-left">
              <p className="text-[0.55rem] uppercase tracking-[0.3em] text-faint" style={{ fontFamily: "var(--font-display)" }}>
                Next
              </p>
              <p className="mt-1 text-sm font-semibold text-white">Account · Dashboard</p>
            </div>
            <ShieldCheck className="text-emerald-300/80" size={20} />
          </div>
        </div>
      </div>

      <div className="mx-auto flex w-full max-w-7xl flex-col items-center justify-between gap-2 border-t border-white/8 px-4 py-4 text-[0.62rem] text-faint sm:flex-row sm:px-6">
        <span>JARVIS AI · Gemini-powered personal intelligence</span>
        <span className="flex items-center gap-3">
          <Link href="/auth" className="hover:text-white">
            Already onboarded?
          </Link>
          <span className="hidden sm:inline">Keys never leave this server except to Google&apos;s Gemini API</span>
        </span>
      </div>
    </div>
  );
}
