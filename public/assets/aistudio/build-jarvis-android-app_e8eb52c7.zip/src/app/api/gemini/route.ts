import { eq } from "drizzle-orm";
import { db } from "@/db";
import { userSettings } from "@/db/schema";
import { getDeviceId, getSessionUser, newDeviceId, setDeviceId } from "@/lib/auth";
import { ApiError, fail, ok, rateLimit, readJson, str } from "@/lib/http";
import { DEFAULT_MODEL, FALLBACK_MODELS, GeminiError, listGeminiModels, validateGeminiKey } from "@/lib/gemini";
import { logUsage } from "@/lib/usage";
import { hasCredential, markCredentialStatus, resolveCredential, saveCredential, disconnectCredential, updateCredentialModel } from "@/lib/vault";

export const dynamic = "force-dynamic";

const MAX_KEY_LENGTH = 200;

function normalizeModel(value: unknown): string {
  const model = typeof value === "string" ? value.trim() : "";
  if (!model || model.length > 120 || /[^a-zA-Z0-9._-]/.test(model)) return DEFAULT_MODEL;
  return model;
}

export async function GET() {
  try {
    const user = await getSessionUser();
    const state = await hasCredential(user?.id ?? null);
    return ok({ gemini: state, suggestedModels: FALLBACK_MODELS });
  } catch (error) {
    return fail(error);
  }
}

export async function POST(request: Request) {
  try {
    const body = await readJson<Record<string, unknown>>(request);
    const action = str(body.action, "Action", { min: 3, max: 40 });
    const user = await getSessionUser();
    const started = Date.now();

    if (action === "connect") {
      const apiKey = str(body.apiKey, "Gemini API key", { min: 20, max: MAX_KEY_LENGTH });
      if (/\s/.test(apiKey)) {
        throw new ApiError(400, "validation", "API keys never contain spaces.", "Paste the key exactly as Google AI Studio shows it.");
      }
      if (!apiKey.startsWith("AIza")) {
        throw new ApiError(
          400,
          "validation",
          "That does not look like a Google AI Studio key.",
          "Keys generated in AI Studio begin with “AIza”. Format checks are only a hint — the live test below is the real verification.",
        );
      }
      const model = normalizeModel(body.model);
      rateLimit(`gemini:connect:${user?.id ?? (await getDeviceId()) ?? "anon"}`, 8, 60_000);

      const result = await validateGeminiKey(apiKey, model);
      await logUsage({
        userId: user?.id ?? null,
        route: "gemini.connect",
        model,
        ok: result.ok,
        statusCode: result.ok ? 200 : 400,
        latencyMs: Date.now() - started,
      });

      if (!result.ok) {
        const status = result.code === "rate_limited" || result.code === "quota_exceeded" ? 429 : result.code === "provider_unavailable" ? 503 : 400;
        return Response.json(
          { ok: false, error: { code: result.code, message: result.message, hint: result.hint } },
          { status },
        );
      }

      const deviceId = (await getDeviceId()) ?? newDeviceId();
      await setDeviceId(deviceId);
      await saveCredential({ deviceId, userId: user?.id ?? null, apiKey, model });
      if (user) {
        await db.update(userSettings).set({ model, updatedAt: new Date() }).where(eq(userSettings.userId, user.id));
      }
      return ok({
        connected: true,
        model,
        last4: apiKey.slice(-4),
        latencyMs: result.latencyMs,
        sample: result.sample,
        message: "Live Gemini handshake verified. Credential encrypted and stored on this device.",
      });
    }

    if (action === "test") {
      const credential = await resolveCredential(user?.id ?? "");
      if (!credential) throw new ApiError(428, "gemini_not_connected", "No key to test.", "Connect a Gemini API key first.");
      const result = await validateGeminiKey(credential.apiKey, credential.model);
      await markCredentialStatus(credential.id, result.ok ? "valid" : "invalid");
      await logUsage({ userId: user?.id ?? null, route: "gemini.test", model: credential.model, ok: result.ok, latencyMs: Date.now() - started });
      if (!result.ok) {
        return Response.json({ ok: false, error: { code: result.code, message: result.message, hint: result.hint } }, { status: 400 });
      }
      return ok({ connected: true, model: credential.model, latencyMs: result.latencyMs, message: "Key still valid — handshake completed." });
    }

    if (action === "models") {
      const credential = await resolveCredential(user?.id ?? "");
      if (!credential) throw new ApiError(428, "gemini_not_connected", "Connect a key to list models.", "Models are read live from your own key.");
      try {
        const models = await listGeminiModels(credential.apiKey);
        return ok({ models, current: credential.model, source: "live" as const });
      } catch (error) {
        if (error instanceof GeminiError) {
          throw new ApiError(error.status || 502, error.code, error.message, error.hint);
        }
        throw error;
      }
    }

    if (action === "set-model") {
      const credential = await resolveCredential(user?.id ?? "");
      if (!credential) throw new ApiError(428, "gemini_not_connected", "Connect a key before choosing a model.", "Reconnect Gemini.");
      const model = normalizeModel(body.model);
      const result = await validateGeminiKey(credential.apiKey, model);
      if (!result.ok) {
        return Response.json({ ok: false, error: { code: result.code, message: result.message, hint: result.hint } }, { status: 400 });
      }
      await updateCredentialModel(credential.id, model);
      if (user) {
        await db.update(userSettings).set({ model, updatedAt: new Date() }).where(eq(userSettings.userId, user.id));
      }
      return ok({ model, message: `Switched to ${model} after a live check.` });
    }

    if (action === "disconnect") {
      if (!user) {
        const deviceId = await getDeviceId();
        if (!deviceId) throw new ApiError(428, "gemini_not_connected", "Nothing to disconnect.");
        await disconnectCredential("");
        return ok({ connected: false, message: "Encrypted key removed from this device." });
      }
      await disconnectCredential(user.id);
      return ok({ connected: false, message: "Encrypted key removed. Connect a new key to reactivate JARVIS." });
    }

    throw new ApiError(404, "unknown_action", "Unknown Gemini action.");
  } catch (error) {
    return fail(error);
  }
}
