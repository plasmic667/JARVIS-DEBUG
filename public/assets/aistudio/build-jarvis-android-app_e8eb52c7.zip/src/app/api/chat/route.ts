import { and, asc, desc, eq, gte } from "drizzle-orm";
import { db } from "@/db";
import { conversations, memories, messages } from "@/db/schema";
import { getSettings, requireUser } from "@/lib/auth";
import { ApiError, fail, rateLimit, readJson } from "@/lib/http";
import { GeminiError, maxTokensFor, streamGeminiText, type GeminiContent } from "@/lib/gemini";
import { buildSystemInstruction, deriveTitle } from "@/lib/personality";
import { TOOL_DECLARATIONS, executeTool } from "@/lib/tools";
import { logUsage } from "@/lib/usage";
import { markCredentialStatus, requireCredential } from "@/lib/vault";

export const dynamic = "force-dynamic";
export const maxDuration = 120;

type ChatBody = {
  conversationId?: string;
  message?: string;
  regenerate?: boolean;
};

export async function POST(request: Request) {
  try {
    const user = await requireUser();
    const body = await readJson<ChatBody>(request);
    rateLimit(`chat:${user.id}`, 25, 60_000);
    const credential = await requireCredential(user.id);
    const settings = await getSettings(user.id);
    const model = credential.model || settings.model;

    const conversationId = typeof body.conversationId === "string" ? body.conversationId : null;
    const userText = typeof body.message === "string" ? body.message.trim() : "";
    const regenerate = body.regenerate === true;

    let conversation = conversationId
      ? (await db.select().from(conversations).where(and(eq(conversations.id, conversationId), eq(conversations.userId, user.id))).limit(1))[0]
      : undefined;

    if (conversationId && !conversation) {
      throw new ApiError(404, "conversation_not_found", "Conversation not found.");
    }

    if (!regenerate) {
      if (userText.length < 1) throw new ApiError(400, "validation", "Say something first.");
      if (userText.length > 8000) throw new ApiError(400, "validation", "Message too long (max 8000 characters).");
      if (!conversation) {
        const [created] = await db
          .insert(conversations)
          .values({ userId: user.id, title: deriveTitle(userText), lastMessagePreview: userText.slice(0, 160) })
          .returning();
        conversation = created;
      }
      await db.insert(messages).values({ conversationId: conversation.id, userId: user.id, role: "user", content: userText });
    } else {
      if (!conversation) throw new ApiError(400, "validation", "Regeneration requires a conversation.");
      const [lastUserMessage] = await db
        .select({ createdAt: messages.createdAt })
        .from(messages)
        .where(and(eq(messages.conversationId, conversation.id), eq(messages.role, "user")))
        .orderBy(desc(messages.createdAt))
        .limit(1);
      if (!lastUserMessage) throw new ApiError(400, "validation", "Nothing to regenerate yet.");
      // Remove only the response(s) generated since the last user turn.
      await db
        .delete(messages)
        .where(
          and(
            eq(messages.conversationId, conversation.id),
            eq(messages.role, "assistant"),
            gte(messages.createdAt, lastUserMessage.createdAt),
          ),
        );
    }

    const activeConversation = conversation;
    const history = await db
      .select()
      .from(messages)
      .where(eq(messages.conversationId, activeConversation.id))
      .orderBy(asc(messages.createdAt))
      .limit(40);

    const trimmed = history.slice(-16);
    if (trimmed.length === 0) throw new ApiError(400, "validation", "Nothing to generate. Send a message first.");

    const userSettingsRow = await getSettings(user.id);
    const memoryRows = userSettingsRow.memoryEnabled
      ? await db.select({ content: memories.content, category: memories.category }).from(memories).where(eq(memories.userId, user.id)).orderBy(desc(memories.updatedAt)).limit(40)
      : [];

    const systemInstruction = buildSystemInstruction(userSettingsRow, memoryRows, new Date().toISOString());
    const contents: GeminiContent[] = trimmed.map((m) => ({
      role: m.role === "assistant" ? "model" : "user",
      parts: [{ text: m.content }],
    }));

    const encoder = new TextEncoder();
    const startedAt = Date.now();

    const stream = new ReadableStream<Uint8Array>({
      async start(controller) {
        let full = "";
        const toolTrace: Array<{ name: string; summary: string }> = [];
        const push = (payload: Record<string, unknown>) => controller.enqueue(encoder.encode(`data: ${JSON.stringify(payload)}\n\n`));

        try {
          push({ type: "meta", conversationId: activeConversation.id, model });
          let rounds = 0;
          while (rounds < 3) {
            rounds += 1;
            const generator = streamGeminiText({
              apiKey: credential.apiKey,
              model,
              contents,
              systemInstruction,
              temperature: Math.min(1.4, Math.max(0, userSettingsRow.temperature)),
              maxOutputTokens: maxTokensFor(userSettingsRow.responseLength),
              tools: TOOL_DECLARATIONS,
              signal: AbortSignal.any([request.signal, AbortSignal.timeout(120_000)]),
            });

            let summary = await generator.next();
            while (!summary.done) {
              full += summary.value;
              push({ type: "token", value: summary.value });
              summary = await generator.next();
            }
            const result = summary.value;
            if (result.functionCalls.length === 0) break;

            const outcomes = [];
            for (const call of result.functionCalls.slice(0, 4)) {
              const outcome = await executeTool(call.name, call.args, { userId: user.id });
              toolTrace.push({ name: call.name, summary: outcome.summary });
              push({ type: "tool", name: call.name, summary: outcome.summary });
              outcomes.push({ name: call.name, outcome });
            }

            contents.push({
              role: "model",
              parts: result.rawParts.length > 0 ? result.rawParts : result.functionCalls.slice(0, 4).map((call) => ({ functionCall: { name: call.name, args: call.args } })),
            });
            contents.push({
              role: "user",
              parts: outcomes.map((o) => ({
                functionResponse: { name: o.name, response: { result: o.outcome.result } },
              })),
            });
          }

          const text = full.trim() || "I completed that, but Gemini returned an empty response. Try rephrasing.";
          const [saved] = await db
            .insert(messages)
            .values({
              conversationId: activeConversation.id,
              userId: user.id,
              role: "assistant",
              content: text,
              status: "complete",
              metadata: { model, tools: toolTrace, latencyMs: Date.now() - startedAt },
            })
            .returning();

          await db
            .update(conversations)
            .set({ updatedAt: new Date(), lastMessagePreview: text.slice(0, 160), title: activeConversation.title })
            .where(eq(conversations.id, activeConversation.id));

          await logUsage({ userId: user.id, route: "chat", model, ok: true, latencyMs: Date.now() - startedAt });
          push({ type: "done", messageId: saved.id, latencyMs: Date.now() - startedAt, tools: toolTrace, content: text });
          controller.close();
        } catch (error) {
          const isAbort = error instanceof DOMException && error.name === "AbortError";
          if (full.trim()) {
            await db
              .insert(messages)
              .values({
                conversationId: activeConversation.id,
                userId: user.id,
                role: "assistant",
                content: full,
                status: isAbort ? "cancelled" : "error",
                metadata: { model, tools: toolTrace, latencyMs: Date.now() - startedAt },
              })
              .catch(() => undefined);
          }
          let code = "unknown";
          let message = "Gemini request failed.";
          let hint: string | undefined;
          if (error instanceof GeminiError) {
            code = error.code;
            message = error.message;
            hint = error.hint;
            if (error.code === "invalid_key") {
              await markCredentialStatus(credential.id, "invalid").catch(() => undefined);
            }
          } else if (isAbort) {
            code = "cancelled";
            message = "Generation stopped.";
          }
          await logUsage({ userId: user.id, route: "chat", model, ok: false, statusCode: 502, latencyMs: Date.now() - startedAt });
          try {
            push({ type: "error", code, message, hint, partial: full });
            controller.close();
          } catch {
            // The browser already cancelled the stream — nothing left to write.
          }
        }
      },
    });

    return new Response(stream, {
      headers: {
        "Content-Type": "text/event-stream; charset=utf-8",
        "Cache-Control": "no-cache, no-transform",
        Connection: "keep-alive",
        "X-Accel-Buffering": "no",
      },
    });
  } catch (error) {
    return fail(error);
  }
}

export async function GET() {
  try {
    const user = await requireUser();
    const since = new Date(Date.now() - 1000 * 60 * 60 * 24);
    const rows = await db
      .select({ id: messages.id })
      .from(messages)
      .where(and(eq(messages.userId, user.id), gte(messages.createdAt, since)));
    return Response.json({ ok: true, sentLast24h: rows.length });
  } catch (error) {
    return fail(error);
  }
}
