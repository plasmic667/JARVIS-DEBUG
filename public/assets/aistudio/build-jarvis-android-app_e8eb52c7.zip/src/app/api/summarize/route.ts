import { db } from "@/db";
import { notes } from "@/db/schema";
import { getSettings, requireUser } from "@/lib/auth";
import { ApiError, fail, ok, rateLimit, readJson, str } from "@/lib/http";
import { generateGeminiText, GeminiError } from "@/lib/gemini";
import { logUsage } from "@/lib/usage";
import { requireCredential } from "@/lib/vault";

export const dynamic = "force-dynamic";
export const maxDuration = 90;

export async function POST(request: Request) {
  const started = Date.now();
  try {
    const user = await requireUser();
    rateLimit(`summarize:${user.id}`, 6, 60_000);
    const credential = await requireCredential(user.id);
    const settings = await getSettings(user.id);
    const body = await readJson<{ text?: string; saveAsNote?: boolean }>(request);
    const text = str(body.text, "Document text", { min: 40, max: 24000 });

    const summary = await generateGeminiText({
      apiKey: credential.apiKey,
      model: credential.model,
      systemInstruction:
        "You are JARVIS. Summarise the user-provided document faithfully. Output: a one-sentence bottom line, then 3-6 bullet key points, then any action items. Never invent facts.",
      temperature: 0.4,
      maxOutputTokens: 1200,
      contents: [{ role: "user", parts: [{ text }] }],
    });

    let noteId: string | null = null;
    if (body.saveAsNote) {
      const [row] = await db
        .insert(notes)
        .values({ userId: user.id, title: `Summary · ${new Date().toLocaleDateString()}`, content: summary })
        .returning();
      noteId = row.id;
    }

    await logUsage({ userId: user.id, route: "summarize", model: credential.model, ok: true, latencyMs: Date.now() - started });
    return ok({ summary, noteId, model: credential.model, latencyMs: Date.now() - started, personality: settings.personality });
  } catch (error) {
    if (error instanceof GeminiError) {
      return Response.json(
        { ok: false, error: { code: error.code, message: error.message, hint: error.hint } },
        { status: error.status || 502 },
      );
    }
    if (error instanceof ApiError) return fail(error);
    return fail(error);
  }
}
