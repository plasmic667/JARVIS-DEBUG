import { eq } from "drizzle-orm";
import { db } from "@/db";
import { userSettings } from "@/db/schema";
import { getSettings, requireUser } from "@/lib/auth";
import { ApiError, clampNumber, fail, ok, readJson } from "@/lib/http";
import { PERSONALITY_MODES } from "@/lib/personality";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const user = await requireUser();
    return ok({ settings: await getSettings(user.id) });
  } catch (error) {
    return fail(error);
  }
}

export async function PATCH(request: Request) {
  try {
    const user = await requireUser();
    const body = await readJson<Record<string, unknown>>(request);
    const current = await getSettings(user.id);
    const personality = typeof body.personality === "string" && PERSONALITY_MODES.some((m) => m.id === body.personality)
      ? body.personality
      : current.personality;
    if (personality === "custom" && typeof body.customPersonality === "string" && body.customPersonality.trim().length < 10) {
      throw new ApiError(400, "validation", "A custom personality needs at least 10 characters of direction.");
    }
    const responseLength = ["concise", "balanced", "detailed"].includes(String(body.responseLength))
      ? String(body.responseLength)
      : current.responseLength;
    const customPersonality =
      typeof body.customPersonality === "string" ? body.customPersonality.trim().slice(0, 1200) : current.customPersonality;

    const [updated] = await db
      .update(userSettings)
      .set({
        personality,
        customPersonality,
        humor: clampNumber(body.humor, current.humor, 0, 3),
        expressiveness: clampNumber(body.expressiveness, current.expressiveness, 0, 3),
        responseLength,
        autoSpeak: typeof body.autoSpeak === "boolean" ? body.autoSpeak : current.autoSpeak,
        animations: typeof body.animations === "boolean" ? body.animations : current.animations,
        memoryEnabled: typeof body.memoryEnabled === "boolean" ? body.memoryEnabled : current.memoryEnabled,
        voiceRate: clampNumber(body.voiceRate, current.voiceRate, 0.5, 2),
        voicePitch: clampNumber(body.voicePitch, current.voicePitch, 0, 2),
        voiceName: typeof body.voiceName === "string" ? body.voiceName.slice(0, 120) : current.voiceName,
        temperature: clampNumber(body.temperature, current.temperature, 0, 1.4),
        updatedAt: new Date(),
      })
      .where(eq(userSettings.userId, user.id))
      .returning();

    return ok({ settings: updated, message: "Assistant preferences saved." });
  } catch (error) {
    return fail(error);
  }
}
