import { getSessionUser, getSettings } from "@/lib/auth";
import { fail, ok } from "@/lib/http";
import { hasCredential } from "@/lib/vault";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const user = await getSessionUser();
    const gemini = await hasCredential(user?.id ?? null);
    const settings = user ? await getSettings(user.id) : null;
    return ok({
      authenticated: Boolean(user),
      user: user
        ? {
            id: user.id,
            email: user.email,
            displayName: user.displayName,
            emailVerified: user.emailVerified,
            createdAt: user.createdAt,
          }
        : null,
      gemini,
      settings,
      // Boot gate: first-launch must be the Gemini connection screen.
      nextStep: !gemini.connected ? "connect_gemini" : !user ? "authenticate" : "dashboard",
    });
  } catch (error) {
    return fail(error);
  }
}
