import { and, asc, count, desc, eq, gte } from "drizzle-orm";
import { db } from "@/db";
import { conversations, memories, messages, notes, reminders, tasks, usageEvents } from "@/db/schema";
import { getSessionUser, getSettings } from "@/lib/auth";
import { fail, ok } from "@/lib/http";
import { hasCredential } from "@/lib/vault";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const user = await getSessionUser();
    if (!user) return ok({ authenticated: false, gemini: { connected: false } });

    const startOfDay = new Date();
    startOfDay.setHours(0, 0, 0, 0);

    const [conversationCount, messageCount, memoryCount, noteCount, openTaskCount, taskRows, reminderRows, recent, memoryPreview, usageToday] =
      await Promise.all([
        db.select({ value: count() }).from(conversations).where(eq(conversations.userId, user.id)),
        db.select({ value: count() }).from(messages).where(eq(messages.userId, user.id)),
        db.select({ value: count() }).from(memories).where(eq(memories.userId, user.id)),
        db.select({ value: count() }).from(notes).where(eq(notes.userId, user.id)),
        db.select({ value: count() }).from(tasks).where(and(eq(tasks.userId, user.id), eq(tasks.completed, false))),
        db.select().from(tasks).where(and(eq(tasks.userId, user.id), eq(tasks.completed, false))).orderBy(asc(tasks.dueAt)).limit(6),
        db
          .select()
          .from(reminders)
          .where(and(eq(reminders.userId, user.id), eq(reminders.status, "scheduled")))
          .orderBy(asc(reminders.remindAt))
          .limit(6),
        db.select().from(conversations).where(eq(conversations.userId, user.id)).orderBy(desc(conversations.updatedAt)).limit(4),
        db.select({ content: memories.content, category: memories.category }).from(memories).where(eq(memories.userId, user.id)).orderBy(desc(memories.updatedAt)).limit(3),
        db
          .select({ value: count() })
          .from(usageEvents)
          .where(and(eq(usageEvents.userId, user.id), gte(usageEvents.createdAt, startOfDay), eq(usageEvents.ok, true))),
      ]);

    const settings = await getSettings(user.id);
    const gemini = await hasCredential(user.id);

    return ok({
      authenticated: true,
      user,
      settings,
      gemini,
      stats: {
        conversations: conversationCount[0]?.value ?? 0,
        messages: messageCount[0]?.value ?? 0,
        memories: memoryCount[0]?.value ?? 0,
        notes: noteCount[0]?.value ?? 0,
        openTasks: openTaskCount[0]?.value ?? 0,
        reminders: reminderRows.length,
        requestsToday: usageToday[0]?.value ?? 0,
      },
      recentConversations: recent,
      openTasks: taskRows,
      upcomingReminders: reminderRows,
      memoryPreview,
      serverTime: new Date().toISOString(),
    });
  } catch (error) {
    return fail(error);
  }
}
