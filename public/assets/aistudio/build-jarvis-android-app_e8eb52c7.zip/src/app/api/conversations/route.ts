import { and, asc, desc, eq, ilike, or } from "drizzle-orm";
import { db } from "@/db";
import { conversations, messages } from "@/db/schema";
import { requireUser } from "@/lib/auth";
import { ApiError, fail, ok, readJson, str } from "@/lib/http";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  try {
    const user = await requireUser();
    const url = new URL(request.url);
    const id = url.searchParams.get("id");
    const search = (url.searchParams.get("search") ?? "").trim();

    if (id) {
      const [conversation] = await db
        .select()
        .from(conversations)
        .where(and(eq(conversations.id, id), eq(conversations.userId, user.id)))
        .limit(1);
      if (!conversation) throw new ApiError(404, "conversation_not_found", "Conversation not found.");
      const rows = await db
        .select()
        .from(messages)
        .where(eq(messages.conversationId, id))
        .orderBy(asc(messages.createdAt));
      return ok({ conversation, messages: rows });
    }

    const rows = await db
      .select()
      .from(conversations)
      .where(
        search
          ? and(
              eq(conversations.userId, user.id),
              or(ilike(conversations.title, `%${search}%`), ilike(conversations.lastMessagePreview, `%${search}%`)),
            )
          : eq(conversations.userId, user.id),
      )
      .orderBy(desc(conversations.pinned), desc(conversations.updatedAt))
      .limit(100);
    return ok({ conversations: rows, search });
  } catch (error) {
    return fail(error);
  }
}

export async function POST(request: Request) {
  try {
    const user = await requireUser();
    const body = await readJson<{ title?: string }>(request).catch(() => ({ title: undefined }));
    const title = body.title ? str(body.title, "Title", { min: 1, max: 120 }) : "New conversation";
    const [created] = await db.insert(conversations).values({ userId: user.id, title }).returning();
    return ok({ conversation: created });
  } catch (error) {
    return fail(error);
  }
}

export async function PATCH(request: Request) {
  try {
    const user = await requireUser();
    const body = await readJson<{ id?: string; title?: string; pinned?: boolean }>(request);
    const id = str(body.id, "Conversation id", { min: 8, max: 60 });
    const updates: { title?: string; pinned?: boolean; updatedAt: Date } = { updatedAt: new Date() };
    if (typeof body.title === "string") updates.title = str(body.title, "Title", { min: 1, max: 120 });
    if (typeof body.pinned === "boolean") updates.pinned = body.pinned;
    const [updated] = await db
      .update(conversations)
      .set(updates)
      .where(and(eq(conversations.id, id), eq(conversations.userId, user.id)))
      .returning();
    if (!updated) throw new ApiError(404, "conversation_not_found", "Conversation not found.");
    return ok({ conversation: updated });
  } catch (error) {
    return fail(error);
  }
}

export async function DELETE(request: Request) {
  try {
    const user = await requireUser();
    const url = new URL(request.url);
    let id = url.searchParams.get("id");
    if (!id) {
      const body = await readJson<{ id?: string }>(request).catch(() => ({ id: undefined }));
      id = body.id ?? null;
    }
    if (!id) throw new ApiError(400, "validation", "Conversation id is required.");
    const [deleted] = await db
      .delete(conversations)
      .where(and(eq(conversations.id, id), eq(conversations.userId, user.id)))
      .returning({ id: conversations.id });
    if (!deleted) throw new ApiError(404, "conversation_not_found", "Conversation not found.");
    return ok({ deleted: deleted.id });
  } catch (error) {
    return fail(error);
  }
}
