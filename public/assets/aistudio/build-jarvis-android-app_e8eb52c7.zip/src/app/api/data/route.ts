import { and, asc, desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { memories, notes, reminders, tasks } from "@/db/schema";
import { requireUser } from "@/lib/auth";
import { ApiError, fail, ok, readJson, str } from "@/lib/http";

export const dynamic = "force-dynamic";

const TYPES = ["memories", "notes", "tasks", "reminders"] as const;
type DataType = (typeof TYPES)[number];

function readType(value: unknown): DataType {
  if (typeof value === "string" && (TYPES as readonly string[]).includes(value)) return value as DataType;
  throw new ApiError(400, "validation", "Unknown collection type.");
}

function dateOrNull(value: unknown): Date | null {
  if (typeof value !== "string" || !value) return null;
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return null;
  return date;
}

export async function GET(request: Request) {
  try {
    const user = await requireUser();
    const type = readType(new URL(request.url).searchParams.get("type"));
    switch (type) {
      case "memories":
        return ok({ memories: await db.select().from(memories).where(eq(memories.userId, user.id)).orderBy(desc(memories.updatedAt)).limit(200) });
      case "notes":
        return ok({ notes: await db.select().from(notes).where(eq(notes.userId, user.id)).orderBy(desc(notes.updatedAt)).limit(200) });
      case "tasks":
        return ok({ tasks: await db.select().from(tasks).where(eq(tasks.userId, user.id)).orderBy(asc(tasks.completed), asc(tasks.dueAt)).limit(300) });
      case "reminders":
        return ok({ reminders: await db.select().from(reminders).where(eq(reminders.userId, user.id)).orderBy(asc(reminders.remindAt)).limit(200) });
    }
  } catch (error) {
    return fail(error);
  }
}

export async function POST(request: Request) {
  try {
    const user = await requireUser();
    const body = await readJson<Record<string, unknown>>(request);
    const type = readType(body.type);
    switch (type) {
      case "memories": {
        const content = str(body.content, "Memory", { min: 3, max: 500 });
        if (/(api[\s_-]?key|password|secret|token|credit card)/i.test(content)) {
          throw new ApiError(400, "sensitive", "That looks sensitive — JARVIS memory refuses API keys, passwords and payment data.");
        }
        const category = str(body.category ?? "general", "Category", { min: 2, max: 30 });
        const [row] = await db.insert(memories).values({ userId: user.id, content, category }).returning();
        return ok({ memory: row });
      }
      case "notes": {
        const title = str(body.title, "Title", { min: 1, max: 160 });
        const content = str(body.content ?? "", "Content", { max: 20000 });
        const [row] = await db.insert(notes).values({ userId: user.id, title, content }).returning();
        return ok({ note: row });
      }
      case "tasks": {
        const title = str(body.title, "Title", { min: 1, max: 200 });
        const [row] = await db
          .insert(tasks)
          .values({
            userId: user.id,
            title,
            description: str(body.description ?? "", "Description", { max: 2000 }),
            dueAt: dateOrNull(body.dueAt),
            priority: ["low", "normal", "high"].includes(String(body.priority)) ? String(body.priority) : "normal",
          })
          .returning();
        return ok({ task: row });
      }
      case "reminders": {
        const title = str(body.title, "Title", { min: 1, max: 200 });
        const remindAt = dateOrNull(body.remindAt);
        if (!remindAt) throw new ApiError(400, "validation", "A valid reminder time is required.");
        const [row] = await db.insert(reminders).values({ userId: user.id, title, remindAt }).returning();
        return ok({ reminder: row });
      }
    }
  } catch (error) {
    return fail(error);
  }
}

export async function PATCH(request: Request) {
  try {
    const user = await requireUser();
    const body = await readJson<Record<string, unknown>>(request);
    const type = readType(body.type);
    const id = str(body.id, "Id", { min: 8, max: 60 });
    switch (type) {
      case "memories": {
        const [row] = await db
          .update(memories)
          .set({
            content: typeof body.content === "string" ? str(body.content, "Memory", { min: 3, max: 500 }) : undefined,
            category: typeof body.category === "string" ? str(body.category, "Category", { min: 2, max: 30 }) : undefined,
            updatedAt: new Date(),
          })
          .where(and(eq(memories.id, id), eq(memories.userId, user.id)))
          .returning();
        if (!row) throw new ApiError(404, "not_found", "Memory not found.");
        return ok({ memory: row });
      }
      case "notes": {
        const [row] = await db
          .update(notes)
          .set({
            title: typeof body.title === "string" ? str(body.title, "Title", { min: 1, max: 160 }) : undefined,
            content: typeof body.content === "string" ? str(body.content, "Content", { max: 20000 }) : undefined,
            updatedAt: new Date(),
          })
          .where(and(eq(notes.id, id), eq(notes.userId, user.id)))
          .returning();
        if (!row) throw new ApiError(404, "not_found", "Note not found.");
        return ok({ note: row });
      }
      case "tasks": {
        const [row] = await db
          .update(tasks)
          .set({
            title: typeof body.title === "string" ? str(body.title, "Title", { min: 1, max: 200 }) : undefined,
            description: typeof body.description === "string" ? str(body.description, "Description", { max: 2000 }) : undefined,
            completed: typeof body.completed === "boolean" ? body.completed : undefined,
            dueAt: body.dueAt === null ? null : dateOrNull(body.dueAt) ?? undefined,
            priority: ["low", "normal", "high"].includes(String(body.priority)) ? String(body.priority) : undefined,
            updatedAt: new Date(),
          })
          .where(and(eq(tasks.id, id), eq(tasks.userId, user.id)))
          .returning();
        if (!row) throw new ApiError(404, "not_found", "Task not found.");
        return ok({ task: row });
      }
      case "reminders": {
        const [row] = await db
          .update(reminders)
          .set({
            title: typeof body.title === "string" ? str(body.title, "Title", { min: 1, max: 200 }) : undefined,
            remindAt: dateOrNull(body.remindAt) ?? undefined,
            status: ["scheduled", "fired", "done"].includes(String(body.status)) ? String(body.status) : undefined,
          })
          .where(and(eq(reminders.id, id), eq(reminders.userId, user.id)))
          .returning();
        if (!row) throw new ApiError(404, "not_found", "Reminder not found.");
        return ok({ reminder: row });
      }
    }
  } catch (error) {
    return fail(error);
  }
}

export async function DELETE(request: Request) {
  try {
    const user = await requireUser();
    const url = new URL(request.url);
    const type = readType(url.searchParams.get("type"));
    const id = url.searchParams.get("id");
    if (!id) throw new ApiError(400, "validation", "Id is required.");
    if (id === "all") {
      // Explicit full purge (memory opt-out). Requires an authenticated owner scope.
      switch (type) {
        case "memories":
          await db.delete(memories).where(eq(memories.userId, user.id));
          break;
        case "notes":
          await db.delete(notes).where(eq(notes.userId, user.id));
          break;
        case "tasks":
          await db.delete(tasks).where(eq(tasks.userId, user.id));
          break;
        case "reminders":
          await db.delete(reminders).where(eq(reminders.userId, user.id));
          break;
      }
      return ok({ purged: type });
    }
    switch (type) {
      case "memories":
        await db.delete(memories).where(and(eq(memories.id, id), eq(memories.userId, user.id)));
        break;
      case "notes":
        await db.delete(notes).where(and(eq(notes.id, id), eq(notes.userId, user.id)));
        break;
      case "tasks":
        await db.delete(tasks).where(and(eq(tasks.id, id), eq(tasks.userId, user.id)));
        break;
      case "reminders":
        await db.delete(reminders).where(and(eq(reminders.id, id), eq(reminders.userId, user.id)));
        break;
    }
    return ok({ deleted: id });
  } catch (error) {
    return fail(error);
  }
}
