import { eq } from "drizzle-orm";
import { db } from "@/db";
import { credentials, sessions, userSettings, users } from "@/db/schema";
import {
  createSession,
  destroySession,
  getDeviceId,
  getSessionUser,
  isValidEmail,
  passwordProblem,
  requireUser,
} from "@/lib/auth";
import { hashPassword, randomToken, verifyPassword } from "@/lib/crypto";
import { ApiError, fail, ok, rateLimit, readJson, str } from "@/lib/http";

export const dynamic = "force-dynamic";

type Body = Record<string, unknown>;

function emailOf(body: Body): string {
  const email = str(body.email, "Email", { min: 3, max: 254 }).toLowerCase();
  if (!isValidEmail(email)) throw new ApiError(400, "validation", "Enter a valid email address.");
  return email;
}

function passwordOf(body: Body): string {
  const password = typeof body.password === "string" ? body.password : "";
  const problem = passwordProblem(password);
  if (problem) throw new ApiError(400, "validation", problem);
  return password;
}

/**
 * Local email transport. In this sandbox no outbound mail provider is configured,
 * so verification/reset links are delivered to the signed-in local inbox instead
 * of silently pretending an email was sent. Swap `deliverLocal` for Firebase Auth
 * email actions / a transactional provider in production.
 */
function deliverLocal(kind: "verify" | "reset", token: string) {
  return {
    transport: "local_inbox" as const,
    kind,
    token,
    url: `/auth?${kind === "verify" ? "verify" : "reset"}=${token}`,
    note:
      "Local inbox delivery: replace with Firebase Authentication email actions or a transactional email provider before release.",
  };
}

export async function POST(request: Request, context: { params: Promise<{ action: string }> }) {
  const { action } = await context.params;
  try {
    const body = (await readJson<Body>(request).catch(() => ({} as Body))) as Body;

    if (action === "register") {
      const email = emailOf(body);
      const password = passwordOf(body);
      const displayName = str(body.displayName, "Display name", { min: 2, max: 60 });
      rateLimit(`auth:register:${email}`, 6, 60_000);

      const existing = await db.select({ id: users.id }).from(users).where(eq(users.email, email)).limit(1);
      if (existing[0]) {
        throw new ApiError(409, "email_in_use", "An account already exists for this email.", "Sign in instead, or reset the password.");
      }

      const verificationToken = randomToken(24);
      const [created] = await db
        .insert(users)
        .values({
          email,
          displayName,
          passwordHash: hashPassword(password),
          verificationToken,
          emailVerified: false,
        })
        .returning();
      await db.insert(userSettings).values({ userId: created.id }).onConflictDoNothing();
      const deviceId = await getDeviceId();
      if (deviceId) {
        // Bind the installation-scoped encrypted key to this new account.
        await db.update(credentials).set({ userId: created.id }).where(eq(credentials.deviceId, deviceId));
      }
      await createSession(created.id);

      return ok({
        user: { id: created.id, email: created.email, displayName: created.displayName, emailVerified: false },
        verification: deliverLocal("verify", verificationToken),
        message: "Account created. Verify your email to unlock the full dashboard.",
      });
    }

    if (action === "login") {
      const email = emailOf(body);
      const password = typeof body.password === "string" ? body.password : "";
      rateLimit(`auth:login:${email}`, 10, 60_000);
      const rows = await db.select().from(users).where(eq(users.email, email)).limit(1);
      const user = rows[0];
      if (!user || !verifyPassword(password, user.passwordHash)) {
        throw new ApiError(401, "invalid_credentials", "Email or password is incorrect.", "Check both fields. Passwords are case-sensitive.");
      }
      await createSession(user.id);
      const loginDeviceId = await getDeviceId();
      if (loginDeviceId) {
        await db.update(credentials).set({ userId: user.id }).where(eq(credentials.deviceId, loginDeviceId));
      }
      return ok({
        user: { id: user.id, email: user.email, displayName: user.displayName, emailVerified: user.emailVerified },
        message: `Welcome back, ${user.displayName}.`,
      });
    }

    if (action === "logout") {
      await destroySession();
      return ok({ message: "Signed out. Your encrypted Gemini key stays on this device until you disconnect it." });
    }

    if (action === "verify") {
      const token = str(body.token, "Verification token", { min: 8, max: 200 });
      const rows = await db.select().from(users).where(eq(users.verificationToken, token)).limit(1);
      if (!rows[0]) throw new ApiError(400, "invalid_token", "That verification link is no longer valid.", "Request a new verification link.");
      await db.update(users).set({ emailVerified: true, verificationToken: null }).where(eq(users.id, rows[0].id));
      return ok({ message: "Email verified. Full access unlocked." });
    }

    if (action === "resend-verification") {
      const user = await requireUser();
      if (user.emailVerified) return ok({ message: "Email already verified." });
      rateLimit(`auth:resend:${user.id}`, 3, 60_000);
      const token = randomToken(24);
      await db.update(users).set({ verificationToken: token }).where(eq(users.id, user.id));
      return ok({ verification: deliverLocal("verify", token), message: "Verification link generated." });
    }

    if (action === "request-reset") {
      const email = emailOf(body);
      rateLimit(`auth:reset:${email}`, 5, 60_000);
      const rows = await db.select().from(users).where(eq(users.email, email)).limit(1);
      if (!rows[0]) {
        // Same response shape either way — no account enumeration.
        return ok({ message: "If that account exists, a reset link has been generated.", verification: null });
      }
      const token = randomToken(24);
      await db
        .update(users)
        .set({ resetToken: token, resetTokenExpires: new Date(Date.now() + 1000 * 60 * 30) })
        .where(eq(users.id, rows[0].id));
      return ok({ message: "Reset link generated. It expires in 30 minutes.", verification: deliverLocal("reset", token) });
    }

    if (action === "reset") {
      const token = str(body.token, "Reset token", { min: 8, max: 200 });
      const password = passwordOf(body);
      const rows = await db.select().from(users).where(eq(users.resetToken, token)).limit(1);
      const user = rows[0];
      if (!user || !user.resetTokenExpires || user.resetTokenExpires.getTime() < Date.now()) {
        throw new ApiError(400, "invalid_token", "That reset link is invalid or expired.", "Request a new password reset link.");
      }
      await db
        .update(users)
        .set({ passwordHash: hashPassword(password), resetToken: null, resetTokenExpires: null })
        .where(eq(users.id, user.id));
      await db.delete(sessions).where(eq(sessions.userId, user.id));
      await createSession(user.id);
      return ok({ message: "Password updated. Other sessions were revoked." });
    }

    if (action === "delete") {
      const user = await requireUser();
      const password = typeof body.password === "string" ? body.password : "";
      const rows = await db.select().from(users).where(eq(users.id, user.id)).limit(1);
      if (!rows[0] || !verifyPassword(password, rows[0].passwordHash)) {
        throw new ApiError(401, "invalid_credentials", "Password confirmation failed.", "Account deletion requires your current password.");
      }
      await db.delete(credentials).where(eq(credentials.userId, user.id));
      await db.delete(users).where(eq(users.id, user.id));
      await destroySession();
      return ok({ message: "Account, conversations, memories, notes, tasks and reminders permanently deleted." });
    }

    throw new ApiError(404, "unknown_action", "Unknown authentication action.");
  } catch (error) {
    return fail(error);
  }
}

export async function GET(_request: Request, context: { params: Promise<{ action: string }> }) {
  const { action } = await context.params;
  try {
    if (action === "me") {
      const user = await getSessionUser();
      return ok({ user });
    }
    throw new ApiError(404, "unknown_action", "Unknown authentication action.");
  } catch (error) {
    return fail(error);
  }
}
