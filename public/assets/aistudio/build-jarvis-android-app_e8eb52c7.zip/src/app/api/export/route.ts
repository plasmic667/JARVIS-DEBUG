import { eq, asc } from "drizzle-orm";
import { db } from "@/db";
import { conversations, memories, messages, notes, reminders, tasks } from "@/db/schema";
import { getSettings, requireUser } from "@/lib/auth";
import { fail } from "@/lib/http";

export const dynamic = "force-dynamic";

/** GDPR-style full user data export. API keys are never included. */
export async function GET() {
  try {
    const user = await requireUser();
    const [conversationRows, messageRows, memoryRows, noteRows, taskRows, reminderRows, settings] = await Promise.all([
      db.select().from(conversations).where(eq(conversations.userId, user.id)),
      db.select().from(messages).where(eq(messages.userId, user.id)).orderBy(asc(messages.createdAt)),
      db.select().from(memories).where(eq(memories.userId, user.id)),
      db.select().from(notes).where(eq(notes.userId, user.id)),
      db.select().from(tasks).where(eq(tasks.userId, user.id)),
      db.select().from(reminders).where(eq(reminders.userId, user.id)),
      getSettings(user.id),
    ]);

    const payload = {
      exportedAt: new Date().toISOString(),
      schemaVersion: 1,
      note: "Your Gemini API key is intentionally excluded. It stays encrypted at rest and never leaves the server.",
      account: { id: user.id, email: user.email, displayName: user.displayName, createdAt: user.createdAt },
      settings,
      conversations: conversationRows.map((conversation) => ({
        ...conversation,
        messages: messageRows.filter((m) => m.conversationId === conversation.id),
      })),
      memories: memoryRows,
      notes: noteRows,
      tasks: taskRows,
      reminders: reminderRows,
    };

    return new Response(JSON.stringify(payload, null, 2), {
      headers: {
        "Content-Type": "application/json; charset=utf-8",
        "Content-Disposition": `attachment; filename="jarvis-export-${user.id.slice(0, 8)}.json"`,
        "Cache-Control": "no-store",
      },
    });
  } catch (error) {
    return fail(error);
  }
}
