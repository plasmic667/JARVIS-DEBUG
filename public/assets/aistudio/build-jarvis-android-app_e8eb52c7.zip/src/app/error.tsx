"use client";

import { useEffect } from "react";
import Link from "next/link";
import { Alert } from "@/components/ui";
import { Logo } from "@/components/ui";

export default function GlobalError({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  useEffect(() => {
    // Never log message content or credentials from the client.
    console.error("[jarvis] render error", error.digest ?? error.name);
  }, [error]);

  return (
    <div className="relative z-10 flex min-h-dvh flex-col items-center justify-center gap-5 px-4 text-center">
      <Logo href="/" />
      <Alert kind="error" message="JARVIS hit an unexpected fault." hint="The interface recovered safely. None of your encrypted credentials were exposed." />
      <div className="flex gap-2">
        <button type="button" onClick={reset} className="btn btn-primary btn-sm">Retry</button>
        <Link href="/dashboard" className="btn btn-outline btn-sm">Back to dashboard</Link>
      </div>
    </div>
  );
}
