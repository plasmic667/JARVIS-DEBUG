import Link from "next/link";
import { Logo } from "@/components/ui";

export default function NotFound() {
  return (
    <div className="relative z-10 flex min-h-dvh flex-col items-center justify-center gap-5 px-4 text-center">
      <Logo href="/" />
      <p className="eyebrow">Signal lost</p>
      <h1 className="title-gradient text-3xl">Route not found</h1>
      <p className="max-w-sm text-sm text-muted">That sector of the JARVIS interface does not exist. Return to a known deck.</p>
      <div className="flex gap-2">
        <Link href="/" className="btn btn-primary btn-sm">Boot sequence</Link>
        <Link href="/dashboard" className="btn btn-outline btn-sm">Dashboard</Link>
      </div>
    </div>
  );
}
