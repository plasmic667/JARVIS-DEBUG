"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { ArrowRight, CheckCircle2, KeyRound, Mail, ShieldCheck, UserRound } from "lucide-react";
import { Orb } from "@/components/Orb";
import { Alert, Logo, Spinner } from "@/components/ui";
import { api, ClientError, type SessionResponse } from "@/lib/client";

type Mode = "login" | "register" | "verify" | "request-reset" | "reset";

type LocalInbox = { kind: "verify" | "reset"; token: string; url: string; note: string };

export default function AuthPage() {
  const router = useRouter();
  const [mode, setMode] = useState<Mode>("login");
  const [geminiLast4, setGeminiLast4] = useState<string | null>(null);
  const [geminiModel, setGeminiModel] = useState<string | null>(null);
  const [checking, setChecking] = useState(true);

  const [displayName, setDisplayName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [token, setToken] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<{ message: string; hint?: string } | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [inbox, setInbox] = useState<LocalInbox | null>(null);
  const [registered, setRegistered] = useState(false);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const verifyToken = params.get("verify");
    const resetToken = params.get("reset");
    if (verifyToken) {
      setToken(verifyToken);
      setMode("verify");
    } else if (resetToken) {
      setToken(resetToken);
      setMode("reset");
    }

    api<SessionResponse>("/api/session")
      .then((session) => {
        if (!session.gemini.connected) {
          router.replace("/connect");
          return;
        }
        setGeminiLast4(session.gemini.last4 ?? null);
        setGeminiModel(session.gemini.model ?? null);
        if (session.authenticated) {
          router.replace("/dashboard");
          return;
        }
        setChecking(false);
      })
      .catch(() => setChecking(false));
  }, [router]);

  const run = async (fn: () => Promise<void>) => {
    setBusy(true);
    setError(null);
    setNotice(null);
    try {
      await fn();
    } catch (caught) {
      const clientError = caught instanceof ClientError ? caught : null;
      setError({ message: clientError?.message ?? "Something went wrong.", hint: clientError?.hint });
    } finally {
      setBusy(false);
    }
  };

  const submitLogin = (event: React.FormEvent) => {
    event.preventDefault();
    void run(async () => {
      const result = await api<{ message: string }>("/api/auth/login", {
        method: "POST",
        body: JSON.stringify({ email, password }),
      });
      setNotice(result.message);
      router.replace("/dashboard");
      router.refresh();
    });
  };

  const submitRegister = (event: React.FormEvent) => {
    event.preventDefault();
    void run(async () => {
      if (password !== confirm) throw new ClientError("Passwords do not match.");
      const result = await api<{ message: string; verification: LocalInbox }>("/api/auth/register", {
        method: "POST",
        body: JSON.stringify({ displayName, email, password }),
      });
      setRegistered(true);
      setInbox(result.verification);
      setNotice(result.message);
    });
  };

  const verifyToken = (value?: string) => {
    void run(async () => {
      const result = await api<{ message: string }>("/api/auth/verify", {
        method: "POST",
        body: JSON.stringify({ token: value ?? token }),
      });
      setNotice(result.message);
      setInbox(null);
      router.replace("/dashboard");
      router.refresh();
    });
  };

  const requestReset = (event: React.FormEvent) => {
    event.preventDefault();
    void run(async () => {
      const result = await api<{ message: string; verification: LocalInbox | null }>("/api/auth/request-reset", {
        method: "POST",
        body: JSON.stringify({ email }),
      });
      setNotice(result.message);
      if (result.verification) {
        setInbox(result.verification);
        setToken(result.verification.token);
        setMode("reset");
      }
    });
  };

  const submitReset = (event: React.FormEvent) => {
    event.preventDefault();
    void run(async () => {
      if (password !== confirm) throw new ClientError("Passwords do not match.");
      const result = await api<{ message: string }>("/api/auth/reset", {
        method: "POST",
        body: JSON.stringify({ token, password }),
      });
      setNotice(result.message);
      setInbox(null);
      router.replace("/dashboard");
      router.refresh();
    });
  };

  const tab = (target: Mode, label: string) => (
    <button
      type="button"
      onClick={() => {
        setMode(target);
        setError(null);
        setNotice(null);
        setInbox(null);
      }}
      className={`flex-1 rounded-full px-3 py-2 text-[0.62rem] uppercase tracking-[0.2em] transition-all ${
        mode === target ? "bg-white/10 text-white shadow-inner" : "text-muted hover:text-white"
      }`}
      style={{ fontFamily: "var(--font-display)" }}
      aria-pressed={mode === target}
    >
      {label}
    </button>
  );

  return (
    <div className="relative z-10 flex min-h-dvh flex-col">
      <header className="mx-auto flex w-full max-w-7xl items-center justify-between px-4 py-5 sm:px-6">
        <Logo href="/connect" />
        <span className="flex items-center gap-2 rounded-full border border-emerald-300/25 bg-emerald-500/8 px-3 py-1.5 text-[0.58rem] uppercase tracking-[0.18em] text-emerald-200" style={{ fontFamily: "var(--font-display)" }}>
          <ShieldCheck size={12} /> Gemini secured {geminiLast4 ? `••••${geminiLast4}` : ""}
        </span>
      </header>

      <div className="mx-auto grid w-full flex-1 max-w-6xl items-center gap-8 px-4 py-6 sm:px-6 lg:grid-cols-2 lg:gap-12">
        <div className="hidden flex-col items-center text-center lg:flex">
          <div className="h-72 w-72 xl:h-80 xl:w-80">
            <Orb state="listening" className="h-full w-full" />
          </div>
          <p className="eyebrow mt-2">Step 02 · Identity</p>
          <h1 className="title-gradient mt-3 text-4xl">
            Verify Your
            <br />
            Operator
          </h1>
          <p className="mt-4 max-w-sm text-sm leading-relaxed text-muted">
            Your Gemini uplink is live{geminiModel ? ` on ${geminiModel}` : ""}. Now secure the account that stores conversations,
            memories, notes and tasks.
          </p>
          <div className="panel-soft mt-6 w-full max-w-sm p-4 text-left">
            <p className="eyebrow mb-2">Onboarding sequence</p>
            {["Gemini API key — verified", "Operator account — in progress", "Dashboard unlock — pending"].map((line, index) => (
              <p key={line} className="flex items-center gap-2 py-1 text-xs text-muted">
                {index === 0 ? <CheckCircle2 size={13} className="text-emerald-300" /> : <span className="grid h-3.5 w-3.5 place-items-center rounded-full border border-white/20 text-[0.5rem] text-faint">{index + 1}</span>}
                {line}
              </p>
            ))}
          </div>
        </div>

        <div className="panel w-full p-5 sm:p-7 animate-fade-up">
          <div className="mb-5">
            <p className="eyebrow">Account access</p>
            <h2 className="mt-1.5 text-xl text-white">{mode === "register" ? "Create operator" : mode === "login" ? "Welcome back" : mode === "verify" ? "Verify email" : mode === "reset" ? "New password" : "Reset access"}</h2>
            <p className="mt-1.5 text-xs leading-relaxed text-muted">
              Authentication is separate from your Gemini connection. Connecting Gemini never signs you in, and signing in never
              changes your key.
            </p>
          </div>

          {(mode === "login" || mode === "register") && (
            <div className="mb-5 flex gap-1 rounded-full border border-white/10 bg-black/30 p-1">
              {tab("login", "Sign in")}
              {tab("register", "Create account")}
            </div>
          )}

          {checking ? (
            <div className="flex items-center gap-2 py-8 text-sm text-muted">
              <Spinner /> Checking device state…
            </div>
          ) : mode === "login" ? (
            <form onSubmit={submitLogin} className="space-y-3.5">
              <div>
                <label htmlFor="login-email" className="label">Email</label>
                <div className="relative">
                  <Mail size={15} className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-violet-200/60" />
                  <input id="login-email" type="email" autoComplete="email" required value={email} onChange={(event) => setEmail(event.target.value)} className="field pl-10" placeholder="operator@domain.com" />
                </div>
              </div>
              <div>
                <label htmlFor="login-password" className="label">Password</label>
                <div className="relative">
                  <KeyRound size={15} className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-violet-200/60" />
                  <input id="login-password" type="password" autoComplete="current-password" required value={password} onChange={(event) => setPassword(event.target.value)} className="field pl-10" placeholder="••••••••" />
                </div>
              </div>
              {error && <Alert kind="error" message={error.message} hint={error.hint} />}
              {notice && <Alert kind="success" message={notice} />}
              <button type="submit" className="btn btn-primary w-full" disabled={busy}>
                {busy ? <Spinner size={14} /> : <ArrowRight size={15} />} Enter JARVIS
              </button>
              <div className="flex items-center justify-between text-[0.7rem]">
                <button type="button" onClick={() => setMode("request-reset")} className="text-fuchsia-200/80 hover:text-white">Forgot password?</button>
                <button type="button" onClick={() => setMode("verify")} className="text-muted hover:text-white">Have a verification link?</button>
              </div>
            </form>
          ) : mode === "register" ? (
            <form onSubmit={submitRegister} className="space-y-3.5">
              <div>
                <label htmlFor="reg-name" className="label">Operator name</label>
                <div className="relative">
                  <UserRound size={15} className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-violet-200/60" />
                  <input id="reg-name" required minLength={2} maxLength={60} value={displayName} onChange={(event) => setDisplayName(event.target.value)} className="field pl-10" placeholder="Tony Stark" autoComplete="name" />
                </div>
              </div>
              <div>
                <label htmlFor="reg-email" className="label">Email</label>
                <input id="reg-email" type="email" required value={email} onChange={(event) => setEmail(event.target.value)} className="field" placeholder="operator@domain.com" autoComplete="email" />
              </div>
              <div className="grid gap-3 sm:grid-cols-2">
                <div>
                  <label htmlFor="reg-password" className="label">Password</label>
                  <input id="reg-password" type="password" required minLength={8} value={password} onChange={(event) => setPassword(event.target.value)} className="field" placeholder="8+ chars, letters & numbers" autoComplete="new-password" />
                </div>
                <div>
                  <label htmlFor="reg-confirm" className="label">Confirm</label>
                  <input id="reg-confirm" type="password" required value={confirm} onChange={(event) => setConfirm(event.target.value)} className="field" placeholder="Repeat password" autoComplete="new-password" />
                </div>
              </div>
              {error && <Alert kind="error" message={error.message} hint={error.hint} />}
              {notice && <Alert kind="success" message={notice} />}
              <button type="submit" className="btn btn-primary w-full" disabled={busy}>
                {busy ? <Spinner size={14} /> : <ShieldCheck size={15} />} Create account &amp; continue
              </button>
              <p className="text-[0.66rem] leading-relaxed text-faint">
                Passwords are hashed with scrypt server-side (never stored or logged in plaintext). In the Android build this maps
                to Firebase Authentication.
              </p>
            </form>
          ) : mode === "verify" ? (
            <form onSubmit={(event) => { event.preventDefault(); verifyToken(); }} className="space-y-3.5">
              <div>
                <label htmlFor="verify-token" className="label">Verification token</label>
                <input id="verify-token" value={token} onChange={(event) => setToken(event.target.value)} className="field field-mono" placeholder="Paste the token from your local inbox" />
              </div>
              {error && <Alert kind="error" message={error.message} hint={error.hint} />}
              {notice && <Alert kind="success" message={notice} />}
              <button type="submit" className="btn btn-primary w-full" disabled={busy || !token}>
                {busy ? <Spinner size={14} /> : <CheckCircle2 size={15} />} Verify email
              </button>
              <button type="button" onClick={() => setMode("login")} className="btn btn-ghost w-full">Back to sign in</button>
            </form>
          ) : mode === "request-reset" ? (
            <form onSubmit={requestReset} className="space-y-3.5">
              <div>
                <label htmlFor="reset-email" className="label">Account email</label>
                <input id="reset-email" type="email" required value={email} onChange={(event) => setEmail(event.target.value)} className="field" placeholder="operator@domain.com" />
              </div>
              {error && <Alert kind="error" message={error.message} hint={error.hint} />}
              {notice && <Alert kind="success" message={notice} />}
              <button type="submit" className="btn btn-primary w-full" disabled={busy}>
                {busy ? <Spinner size={14} /> : <Mail size={15} />} Generate reset link
              </button>
              <button type="button" onClick={() => setMode("login")} className="btn btn-ghost w-full">Back to sign in</button>
            </form>
          ) : (
            <form onSubmit={submitReset} className="space-y-3.5">
              <div>
                <label htmlFor="new-password" className="label">New password</label>
                <input id="new-password" type="password" required minLength={8} value={password} onChange={(event) => setPassword(event.target.value)} className="field" placeholder="8+ chars, letters & numbers" autoComplete="new-password" />
              </div>
              <div>
                <label htmlFor="new-confirm" className="label">Confirm password</label>
                <input id="new-confirm" type="password" required value={confirm} onChange={(event) => setConfirm(event.target.value)} className="field" placeholder="Repeat password" autoComplete="new-password" />
              </div>
              {error && <Alert kind="error" message={error.message} hint={error.hint} />}
              {notice && <Alert kind="success" message={notice} />}
              <button type="submit" className="btn btn-primary w-full" disabled={busy}>
                {busy ? <Spinner size={14} /> : <KeyRound size={15} />} Update password
              </button>
            </form>
          )}

          {inbox && (
            <div className="panel-soft mt-4 p-3.5">
              <p className="eyebrow mb-1">Local inbox · development transport</p>
              <p className="text-[0.7rem] leading-relaxed text-muted">
                No email provider is configured in this environment, so the signed {inbox.kind === "verify" ? "verification" : "reset"} link is
                delivered here instead of pretending an email was sent.
              </p>
              <button
                type="button"
                onClick={() => {
                  if (inbox.kind === "verify") verifyToken(inbox.token);
                  else {
                    setToken(inbox.token);
                    setMode("reset");
                    setInbox(null);
                  }
                }}
                className="btn btn-outline btn-sm mt-2.5"
              >
                Use {inbox.kind === "verify" ? "verification" : "reset"} token <ArrowRight size={12} />
              </button>
            </div>
          )}

          {registered && (
            <button type="button" onClick={() => router.replace("/dashboard")} className="btn btn-ghost mt-3 w-full">
              Continue to dashboard without verifying <ArrowRight size={13} />
            </button>
          )}

          <div className="mt-5 flex items-center justify-between border-t border-white/8 pt-3 text-[0.65rem] text-faint">
            <Link href="/connect" className="hover:text-white">← Change Gemini key</Link>
            <span className="flex items-center gap-1"><ShieldCheck size={11} /> Sessions expire in 30 days</span>
          </div>
        </div>
      </div>
    </div>
  );
}
