"use client";

import { useCallback, useEffect, useState } from "react";
import { Bell, BellRing, Check, Clock, FileText, Plus, Sparkles, Trash2, Upload } from "lucide-react";
import { Alert, EmptyState, MarkdownView, Modal, Spinner } from "@/components/ui";
import { api, formatWhen, type NoteRow, type ReminderRow, type TaskRow } from "@/lib/client";
import { requestNotificationPermission } from "@/components/ui";

type Tab = "notes" | "tasks" | "reminders" | "summarize";

const TABS: Array<{ id: Tab; label: string; icon: typeof FileText }> = [
  { id: "notes", label: "Notes", icon: FileText },
  { id: "tasks", label: "Tasks", icon: Check },
  { id: "reminders", label: "Reminders", icon: Bell },
  { id: "summarize", label: "Summarize", icon: Sparkles },
];

export default function WorkspacePage() {
  const [tab, setTab] = useState<Tab>("notes");
  const [notes, setNotes] = useState<NoteRow[]>([]);
  const [tasks, setTasks] = useState<TaskRow[]>([]);
  const [reminders, setReminders] = useState<ReminderRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [notifyPermission, setNotifyPermission] = useState<NotificationPermission>("default");

  const [noteTitle, setNoteTitle] = useState("");
  const [noteContent, setNoteContent] = useState("");
  const [taskTitle, setTaskTitle] = useState("");
  const [taskDue, setTaskDue] = useState("");
  const [taskPriority, setTaskPriority] = useState("normal");
  const [reminderTitle, setReminderTitle] = useState("");
  const [reminderAt, setReminderAt] = useState("");
  const [deleteTarget, setDeleteTarget] = useState<{ type: "notes" | "tasks" | "reminders"; id: string; label: string } | null>(null);

  const [documentText, setDocumentText] = useState("");
  const [summary, setSummary] = useState<string | null>(null);
  const [summarizing, setSummarizing] = useState(false);

  const loadAll = useCallback(async () => {
    setLoading(true);
    try {
      const [noteData, taskData, reminderData] = await Promise.all([
        api<{ notes: NoteRow[] }>("/api/data?type=notes"),
        api<{ tasks: TaskRow[] }>("/api/data?type=tasks"),
        api<{ reminders: ReminderRow[] }>("/api/data?type=reminders"),
      ]);
      setNotes(noteData.notes);
      setTasks(taskData.tasks);
      setReminders(reminderData.reminders);
      setError(null);
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Could not load the workspace.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const requested = params.get("tab") as Tab | null;
    if (requested && TABS.some((entry) => entry.id === requested)) setTab(requested);
    if (typeof window !== "undefined" && "Notification" in window) setNotifyPermission(Notification.permission);
    void loadAll();
  }, [loadAll]);

  const createNote = async (event: React.FormEvent) => {
    event.preventDefault();
    setBusy(true);
    try {
      const data = await api<{ note: NoteRow }>("/api/data", {
        method: "POST",
        body: JSON.stringify({ type: "notes", title: noteTitle, content: noteContent }),
      });
      setNotes((current) => [data.note, ...current]);
      setNoteTitle("");
      setNoteContent("");
      setNotice("Note saved.");
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Could not save the note.");
    } finally {
      setBusy(false);
    }
  };

  const createTask = async (event: React.FormEvent) => {
    event.preventDefault();
    setBusy(true);
    try {
      const data = await api<{ task: TaskRow }>("/api/data", {
        method: "POST",
        body: JSON.stringify({
          type: "tasks",
          title: taskTitle,
          priority: taskPriority,
          dueAt: taskDue ? new Date(taskDue).toISOString() : null,
        }),
      });
      setTasks((current) => [data.task, ...current]);
      setTaskTitle("");
      setTaskDue("");
      setNotice("Task created.");
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Could not create the task.");
    } finally {
      setBusy(false);
    }
  };

  const toggleTask = async (task: TaskRow) => {
    try {
      const data = await api<{ task: TaskRow }>("/api/data", {
        method: "PATCH",
        body: JSON.stringify({ type: "tasks", id: task.id, completed: !task.completed }),
      });
      setTasks((current) => current.map((item) => (item.id === data.task.id ? data.task : item)));
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Could not update the task.");
    }
  };

  const createReminder = async (event: React.FormEvent) => {
    event.preventDefault();
    if (!reminderAt) {
      setError("Choose a reminder date and time.");
      return;
    }
    setBusy(true);
    try {
      const data = await api<{ reminder: ReminderRow }>("/api/data", {
        method: "POST",
        body: JSON.stringify({ type: "reminders", title: reminderTitle, remindAt: new Date(reminderAt).toISOString() }),
      });
      setReminders((current) => [...current, data.reminder].sort((a, b) => a.remindAt.localeCompare(b.remindAt)));
      setReminderTitle("");
      setReminderAt("");
      setNotice("Reminder scheduled in your local time zone.");
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Could not schedule the reminder.");
    } finally {
      setBusy(false);
    }
  };

  const remove = async () => {
    if (!deleteTarget) return;
    setBusy(true);
    try {
      await api(`/api/data?type=${deleteTarget.type}&id=${deleteTarget.id}`, { method: "DELETE" });
      if (deleteTarget.type === "notes") setNotes((current) => current.filter((item) => item.id !== deleteTarget.id));
      if (deleteTarget.type === "tasks") setTasks((current) => current.filter((item) => item.id !== deleteTarget.id));
      if (deleteTarget.type === "reminders") setReminders((current) => current.filter((item) => item.id !== deleteTarget.id));
      setDeleteTarget(null);
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Delete failed.");
    } finally {
      setBusy(false);
    }
  };

  const summarize = async (saveAsNote: boolean) => {
    setSummarizing(true);
    setError(null);
    setSummary(null);
    try {
      const data = await api<{ summary: string; noteId: string | null }>("/api/summarize", {
        method: "POST",
        body: JSON.stringify({ text: documentText, saveAsNote }),
      });
      setSummary(data.summary);
      if (data.noteId) {
        setNotice("Summary saved in Notes.");
        void loadAll();
      }
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Summarization failed.");
    } finally {
      setSummarizing(false);
    }
  };

  const onFile = async (file: File | null) => {
    if (!file) return;
    if (file.size > 200_000) {
      setError("Please use a text file under 200 KB.");
      return;
    }
    const text = await file.text();
    setDocumentText(text.slice(0, 24000));
  };

  return (
    <div className="space-y-5">
      <header className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <p className="eyebrow">Smart tools</p>
          <h1 className="mt-1 text-2xl text-white">Workspace</h1>
          <p className="mt-1.5 max-w-2xl text-xs leading-relaxed text-muted">
            Notes, tasks and reminders are real database records that JARVIS can create through tool calling. Deletions always
            require confirmation.
          </p>
        </div>
        <div className="flex gap-1 rounded-full border border-white/10 bg-black/30 p-1">
          {TABS.map((entry) => {
            const Icon = entry.icon;
            return (
              <button
                key={entry.id}
                type="button"
                onClick={() => setTab(entry.id)}
                className={`flex items-center gap-1.5 rounded-full px-3 py-1.5 text-[0.6rem] uppercase tracking-[0.16em] transition-colors ${
                  tab === entry.id ? "bg-white/10 text-white" : "text-muted hover:text-white"
                }`}
                style={{ fontFamily: "var(--font-display)" }}
              >
                <Icon size={12} /> {entry.label}
              </button>
            );
          })}
        </div>
      </header>

      {error && <Alert kind="error" message={error} />}
      {notice && <Alert kind="success" message={notice} />}

      {loading ? (
        <div className="flex items-center gap-2 py-10 text-sm text-muted"><Spinner /> Loading workspace…</div>
      ) : tab === "notes" ? (
        <div className="grid gap-4 lg:grid-cols-[1fr_20rem]">
          <section className="panel p-5">
            <p className="eyebrow mb-3">Saved notes · {notes.length}</p>
            {notes.length === 0 ? (
              <EmptyState icon="✎" title="No notes yet" body="Add one here, or ask JARVIS to save a note during a conversation." />
            ) : (
              <ul className="space-y-2">
                {notes.map((note) => (
                  <li key={note.id} className="rounded-xl border border-white/8 bg-white/[0.02] p-3">
                    <div className="flex items-start justify-between gap-3">
                      <div className="min-w-0">
                        <p className="text-sm font-semibold text-white">{note.title}</p>
                        <div className="mt-1 line-clamp-3 text-xs text-muted"><MarkdownView content={note.content} /></div>
                        <p className="mt-1.5 text-[0.58rem] uppercase tracking-[0.2em] text-faint">{formatWhen(note.updatedAt)}</p>
                      </div>
                      <button type="button" onClick={() => setDeleteTarget({ type: "notes", id: note.id, label: note.title })} className="icon-btn shrink-0 hover:border-rose-400/50 hover:text-rose-200" aria-label="Delete note">
                        <Trash2 size={12} />
                      </button>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </section>
          <aside className="panel p-5">
            <p className="eyebrow">New note</p>
            <form onSubmit={createNote} className="mt-3 space-y-3">
              <input value={noteTitle} onChange={(event) => setNoteTitle(event.target.value)} required maxLength={160} placeholder="Title" className="field" aria-label="Note title" />
              <textarea value={noteContent} onChange={(event) => setNoteContent(event.target.value)} rows={6} placeholder="Write anything… markdown supported" className="field resize-none" aria-label="Note content" />
              <button type="submit" disabled={busy} className="btn btn-primary btn-sm w-full">
                {busy ? <Spinner size={12} /> : <Plus size={13} />} Save note
              </button>
            </form>
          </aside>
        </div>
      ) : tab === "tasks" ? (
        <div className="grid gap-4 lg:grid-cols-[1fr_20rem]">
          <section className="panel p-5">
            <p className="eyebrow mb-3">Task queue · {tasks.filter((task) => !task.completed).length} open</p>
            {tasks.length === 0 ? (
              <EmptyState icon="✓" title="No tasks" body="Ask “remind me to review the deck tomorrow” or add one manually." />
            ) : (
              <ul className="space-y-2">
                {tasks.map((task) => (
                  <li key={task.id} className={`flex items-start gap-3 rounded-xl border p-3 ${task.completed ? "border-white/5 bg-white/[0.01] opacity-60" : "border-white/8 bg-white/[0.02]"}`}>
                    <button
                      type="button"
                      onClick={() => void toggleTask(task)}
                      aria-label={task.completed ? `Reopen ${task.title}` : `Complete ${task.title}`}
                      className={`mt-0.5 grid h-5 w-5 shrink-0 place-items-center rounded-md border transition-colors ${task.completed ? "border-emerald-400/60 bg-emerald-500/20 text-emerald-200" : "border-white/25 text-transparent hover:border-emerald-300/70 hover:text-emerald-300"}`}
                    >
                      <Check size={12} />
                    </button>
                    <div className="min-w-0 flex-1">
                      <p className={`text-sm ${task.completed ? "text-muted line-through" : "text-white"}`}>{task.title}</p>
                      <p className="mt-0.5 text-[0.62rem] text-faint">
                        {task.dueAt ? `Due ${formatWhen(task.dueAt)}` : "No due date"} · {task.priority} priority
                      </p>
                    </div>
                    <button type="button" onClick={() => setDeleteTarget({ type: "tasks", id: task.id, label: task.title })} className="icon-btn shrink-0 hover:border-rose-400/50 hover:text-rose-200" aria-label="Delete task">
                      <Trash2 size={12} />
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </section>
          <aside className="panel p-5">
            <p className="eyebrow">New task</p>
            <form onSubmit={createTask} className="mt-3 space-y-3">
              <input value={taskTitle} onChange={(event) => setTaskTitle(event.target.value)} required maxLength={200} placeholder="Task title" className="field" aria-label="Task title" />
              <div>
                <label htmlFor="due" className="label">Due</label>
                <input id="due" type="datetime-local" value={taskDue} onChange={(event) => setTaskDue(event.target.value)} className="field" />
              </div>
              <div>
                <label htmlFor="priority" className="label">Priority</label>
                <select id="priority" value={taskPriority} onChange={(event) => setTaskPriority(event.target.value)} className="field">
                  <option value="low">Low</option>
                  <option value="normal">Normal</option>
                  <option value="high">High</option>
                </select>
              </div>
              <button type="submit" disabled={busy} className="btn btn-primary btn-sm w-full">
                {busy ? <Spinner size={12} /> : <Plus size={13} />} Add task
              </button>
            </form>
          </aside>
        </div>
      ) : tab === "reminders" ? (
        <div className="grid gap-4 lg:grid-cols-[1fr_20rem]">
          <section className="panel p-5">
            <div className="mb-3 flex items-center justify-between">
              <p className="eyebrow">Scheduled · {reminders.length}</p>
              <button
                type="button"
                onClick={async () => {
                  const permission = await requestNotificationPermission();
                  setNotifyPermission(permission);
                }}
                className={`btn btn-sm ${notifyPermission === "granted" ? "btn-outline" : "btn-primary"}`}
              >
                <BellRing size={12} /> {notifyPermission === "granted" ? "Notifications enabled" : "Enable notifications"}
              </button>
            </div>
            {reminders.length === 0 ? (
              <EmptyState icon="◔" title="No reminders" body="Schedule one here or ask JARVIS to remind you at a specific time." />
            ) : (
              <ul className="space-y-2">
                {reminders.map((reminder) => (
                  <li key={reminder.id} className="flex items-center justify-between gap-3 rounded-xl border border-white/8 bg-white/[0.02] p-3">
                    <div className="flex min-w-0 items-center gap-2.5">
                      <Clock size={14} className="shrink-0 text-fuchsia-200/70" />
                      <div className="min-w-0">
                        <p className="truncate text-sm text-white">{reminder.title}</p>
                        <p className="text-[0.62rem] text-faint">{formatWhen(reminder.remindAt)} · {reminder.status}</p>
                      </div>
                    </div>
                    <button type="button" onClick={() => setDeleteTarget({ type: "reminders", id: reminder.id, label: reminder.title })} className="icon-btn shrink-0 hover:border-rose-400/50 hover:text-rose-200" aria-label="Delete reminder">
                      <Trash2 size={12} />
                    </button>
                  </li>
                ))}
              </ul>
            )}
            <p className="mt-3 text-[0.62rem] leading-relaxed text-faint">
              Reminders fire while JARVIS is open (foreground polling every 30 seconds). Android may delay or suppress delivery
              when the app is closed or battery optimisation is active — in the native build this maps to WorkManager + FCM
              scheduling.
            </p>
          </section>
          <aside className="panel p-5">
            <p className="eyebrow">New reminder</p>
            <form onSubmit={createReminder} className="mt-3 space-y-3">
              <input value={reminderTitle} onChange={(event) => setReminderTitle(event.target.value)} required maxLength={200} placeholder="Remind me to…" className="field" aria-label="Reminder title" />
              <div>
                <label htmlFor="remind-at" className="label">When (local time)</label>
                <input id="remind-at" type="datetime-local" value={reminderAt} onChange={(event) => setReminderAt(event.target.value)} required className="field" />
              </div>
              <button type="submit" disabled={busy} className="btn btn-primary btn-sm w-full">
                {busy ? <Spinner size={12} /> : <Bell size={13} />} Schedule reminder
              </button>
            </form>
          </aside>
        </div>
      ) : (
        <div className="grid gap-4 lg:grid-cols-2">
          <section className="panel p-5">
            <p className="eyebrow">Document analysis</p>
            <p className="mt-1.5 text-xs leading-relaxed text-muted">
              Paste text or upload a .txt/.md file. JARVIS sends it to Gemini with your key and returns a faithful summary with
              action items.
            </p>
            <label className="btn btn-outline btn-sm mt-3 w-full cursor-pointer">
              <Upload size={13} /> Upload text file
              <input type="file" accept=".txt,.md,text/plain" className="hidden" onChange={(event) => void onFile(event.target.files?.[0] ?? null)} />
            </label>
            <textarea
              value={documentText}
              onChange={(event) => setDocumentText(event.target.value)}
              rows={12}
              placeholder="Paste a document, meeting notes, spec or article (40–24,000 characters)…"
              className="field mt-3 resize-none font-mono text-xs"
              aria-label="Document text"
            />
            <div className="mt-3 flex flex-wrap gap-2">
              <button type="button" onClick={() => void summarize(false)} disabled={summarizing || documentText.trim().length < 40} className="btn btn-primary btn-sm">
                {summarizing ? <Spinner size={12} /> : <Sparkles size={13} />} Summarize
              </button>
              <button type="button" onClick={() => void summarize(true)} disabled={summarizing || documentText.trim().length < 40} className="btn btn-outline btn-sm">
                Summarize &amp; save note
              </button>
              <span className="self-center text-[0.6rem] text-faint">{documentText.length.toLocaleString()} chars</span>
            </div>
          </section>
          <section className="panel p-5">
            <p className="eyebrow">Summary</p>
            {summary ? (
              <div className="mt-3"><MarkdownView content={summary} /></div>
            ) : (
              <div className="mt-3">
                <EmptyState icon="◈" title="No summary yet" body="Upload a document and run the analysis. The output is real Gemini text — never a canned sample." />
              </div>
            )}
          </section>
        </div>
      )}

      <Modal open={Boolean(deleteTarget)} title="Confirm deletion" onClose={() => setDeleteTarget(null)}>
        <p className="text-sm leading-relaxed text-muted">
          Delete <span className="text-white">{deleteTarget?.label}</span>? Destructive actions always require confirmation.
        </p>
        <div className="mt-4 flex justify-end gap-2">
          <button type="button" onClick={() => setDeleteTarget(null)} className="btn btn-ghost btn-sm">Cancel</button>
          <button type="button" onClick={remove} disabled={busy} className="btn btn-danger btn-sm">Delete</button>
        </div>
      </Modal>
    </div>
  );
}
