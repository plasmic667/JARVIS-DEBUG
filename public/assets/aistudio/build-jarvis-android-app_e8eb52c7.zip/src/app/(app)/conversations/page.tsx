"use client";

import Link from "next/link";
import { useCallback, useEffect, useState } from "react";
import { MessageSquare, Pencil, Pin, PinOff, Search, Trash2 } from "lucide-react";
import { Alert, EmptyState, Modal, Spinner } from "@/components/ui";
import { api, relativeTime, type ConversationRow } from "@/lib/client";

export default function ConversationsPage() {
  const [conversations, setConversations] = useState<ConversationRow[]>([]);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [renameTarget, setRenameTarget] = useState<ConversationRow | null>(null);
  const [renameValue, setRenameValue] = useState("");
  const [deleteTarget, setDeleteTarget] = useState<ConversationRow | null>(null);
  const [busy, setBusy] = useState(false);

  const load = useCallback(async (query = "") => {
    setLoading(true);
    try {
      const data = await api<{ conversations: ConversationRow[] }>(`/api/conversations${query ? `?search=${encodeURIComponent(query)}` : ""}`);
      setConversations(data.conversations);
      setError(null);
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Could not load conversations.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  useEffect(() => {
    const timer = window.setTimeout(() => void load(search), 300);
    return () => window.clearTimeout(timer);
  }, [search, load]);

  const rename = async () => {
    if (!renameTarget) return;
    setBusy(true);
    try {
      const data = await api<{ conversation: ConversationRow }>("/api/conversations", {
        method: "PATCH",
        body: JSON.stringify({ id: renameTarget.id, title: renameValue }),
      });
      setConversations((current) => current.map((item) => (item.id === data.conversation.id ? data.conversation : item)));
      setRenameTarget(null);
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Rename failed.");
    } finally {
      setBusy(false);
    }
  };

  const togglePin = async (conversation: ConversationRow) => {
    try {
      const data = await api<{ conversation: ConversationRow }>("/api/conversations", {
        method: "PATCH",
        body: JSON.stringify({ id: conversation.id, pinned: !conversation.pinned }),
      });
      setConversations((current) => current.map((item) => (item.id === data.conversation.id ? data.conversation : item)));
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Could not update pin.");
    }
  };

  const remove = async () => {
    if (!deleteTarget) return;
    setBusy(true);
    try {
      await api(`/api/conversations?id=${deleteTarget.id}`, { method: "DELETE" });
      setConversations((current) => current.filter((item) => item.id !== deleteTarget.id));
      setDeleteTarget(null);
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Delete failed.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="space-y-5">
      <header className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <p className="eyebrow">Transcript archive</p>
          <h1 className="mt-1 text-2xl text-white">Conversation history</h1>
          <p className="mt-1.5 max-w-xl text-xs leading-relaxed text-muted">
            Every exchange is stored in your private workspace. Rename, pin or delete conversations at any time — deletion is
            permanent and cascades to messages.
          </p>
        </div>
        <Link href="/chat" className="btn btn-primary btn-sm">
          <MessageSquare size={13} /> New conversation
        </Link>
      </header>

      <div className="relative">
        <Search size={15} className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-fuchsia-200/60" />
        <input
          value={search}
          onChange={(event) => setSearch(event.target.value)}
          placeholder="Search conversation titles and previews…"
          className="field pl-10"
          aria-label="Search conversations"
        />
      </div>

      {error && <Alert kind="error" message={error} />}

      {loading ? (
        <div className="flex items-center gap-2 py-10 text-sm text-muted"><Spinner /> Loading archive…</div>
      ) : conversations.length === 0 ? (
        <EmptyState
          icon="⌕"
          title={search ? "No matches" : "No conversations yet"}
          body={search ? "Try a different keyword. Search covers titles and last-message previews." : "Start a text or voice session and it will appear here automatically."}
          action={<Link href="/chat" className="btn btn-outline btn-sm">Open assistant</Link>}
        />
      ) : (
        <ul className="grid gap-2.5 md:grid-cols-2">
          {conversations.map((conversation) => (
            <li key={conversation.id} className="panel panel-hover p-4">
              <div className="flex items-start justify-between gap-3">
                <Link href={`/chat?id=${conversation.id}`} className="min-w-0 flex-1">
                  <p className="flex items-center gap-1.5 truncate text-sm font-semibold text-white">
                    {conversation.pinned && <Pin size={11} className="shrink-0 text-fuchsia-300" />}
                    {conversation.title}
                  </p>
                  <p className="mt-1 line-clamp-2 text-[0.72rem] leading-relaxed text-muted">
                    {conversation.lastMessagePreview || "No messages yet"}
                  </p>
                  <p className="mt-2 text-[0.6rem] uppercase tracking-[0.2em] text-faint">
                    {relativeTime(conversation.updatedAt)} · {new Date(conversation.createdAt).toLocaleDateString()}
                  </p>
                </Link>
                <div className="flex shrink-0 flex-col gap-1">
                  <button type="button" onClick={() => void togglePin(conversation)} className="icon-btn" aria-label={conversation.pinned ? "Unpin conversation" : "Pin conversation"}>
                    {conversation.pinned ? <PinOff size={13} /> : <Pin size={13} />}
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setRenameTarget(conversation);
                      setRenameValue(conversation.title);
                    }}
                    className="icon-btn"
                    aria-label="Rename conversation"
                  >
                    <Pencil size={13} />
                  </button>
                  <button type="button" onClick={() => setDeleteTarget(conversation)} className="icon-btn hover:border-rose-400/50 hover:text-rose-200" aria-label="Delete conversation">
                    <Trash2 size={13} />
                  </button>
                </div>
              </div>
            </li>
          ))}
        </ul>
      )}

      <Modal open={Boolean(renameTarget)} title="Rename conversation" onClose={() => setRenameTarget(null)}>
        <label htmlFor="rename" className="label">Title</label>
        <input id="rename" value={renameValue} onChange={(event) => setRenameValue(event.target.value)} className="field" maxLength={120} />
        <div className="mt-4 flex justify-end gap-2">
          <button type="button" onClick={() => setRenameTarget(null)} className="btn btn-ghost btn-sm">Cancel</button>
          <button type="button" onClick={rename} disabled={busy || renameValue.trim().length === 0} className="btn btn-primary btn-sm">
            {busy ? <Spinner size={12} /> : null} Save title
          </button>
        </div>
      </Modal>

      <Modal open={Boolean(deleteTarget)} title="Delete conversation" onClose={() => setDeleteTarget(null)}>
        <p className="text-sm leading-relaxed text-muted">
          Delete <span className="font-semibold text-white">{deleteTarget?.title}</span> and all of its messages? This cannot be undone.
        </p>
        <div className="mt-4 flex justify-end gap-2">
          <button type="button" onClick={() => setDeleteTarget(null)} className="btn btn-ghost btn-sm">Keep it</button>
          <button type="button" onClick={remove} disabled={busy} className="btn btn-danger btn-sm">
            {busy ? <Spinner size={12} /> : <Trash2 size={12} />} Delete permanently
          </button>
        </div>
      </Modal>
    </div>
  );
}
