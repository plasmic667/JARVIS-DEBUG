"use client";

import { useCallback, useEffect, useState } from "react";
import { BrainCircuit, Download, Pencil, Plus, ShieldOff, Trash2 } from "lucide-react";
import { Alert, EmptyState, Modal, Spinner, Toggle } from "@/components/ui";
import { api, relativeTime, type AssistantSettings, type MemoryRow } from "@/lib/client";

const CATEGORIES = ["preference", "project", "person", "routine", "general"];

export default function MemoryPage() {
  const [memories, setMemories] = useState<MemoryRow[]>([]);
  const [settings, setSettings] = useState<AssistantSettings | null>(null);
  const [content, setContent] = useState("");
  const [category, setCategory] = useState("preference");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [editing, setEditing] = useState<MemoryRow | null>(null);
  const [editContent, setEditContent] = useState("");
  const [deleteTarget, setDeleteTarget] = useState<MemoryRow | null>(null);
  const [purgeOpen, setPurgeOpen] = useState(false);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    try {
      const [memoryData, settingsData] = await Promise.all([
        api<{ memories: MemoryRow[] }>("/api/data?type=memories"),
        api<{ settings: AssistantSettings }>("/api/settings"),
      ]);
      setMemories(memoryData.memories);
      setSettings(settingsData.settings);
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Could not load memory.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const add = async (event: React.FormEvent) => {
    event.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const data = await api<{ memory: MemoryRow }>("/api/data", {
        method: "POST",
        body: JSON.stringify({ type: "memories", content, category }),
      });
      setMemories((current) => [data.memory, ...current]);
      setContent("");
      setNotice("Memory saved. JARVIS can now use it in future conversations.");
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Could not save memory.");
    } finally {
      setBusy(false);
    }
  };

  const saveEdit = async () => {
    if (!editing) return;
    setBusy(true);
    try {
      const data = await api<{ memory: MemoryRow }>("/api/data", {
        method: "PATCH",
        body: JSON.stringify({ type: "memories", id: editing.id, content: editContent }),
      });
      setMemories((current) => current.map((item) => (item.id === data.memory.id ? data.memory : item)));
      setEditing(null);
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Update failed.");
    } finally {
      setBusy(false);
    }
  };

  const remove = async () => {
    if (!deleteTarget) return;
    setBusy(true);
    try {
      await api(`/api/data?type=memories&id=${deleteTarget.id}`, { method: "DELETE" });
      setMemories((current) => current.filter((item) => item.id !== deleteTarget.id));
      setDeleteTarget(null);
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Delete failed.");
    } finally {
      setBusy(false);
    }
  };

  const toggleMemory = async (enabled: boolean) => {
    if (!settings) return;
    setSettings({ ...settings, memoryEnabled: enabled });
    try {
      await api("/api/settings", { method: "PATCH", body: JSON.stringify({ memoryEnabled: enabled }) });
      setNotice(enabled ? "Long-term memory enabled." : "Memory opted out — stored memories are no longer sent to Gemini.");
    } catch {
      setSettings(settings);
    }
  };

  const purgeAll = async () => {
    setBusy(true);
    try {
      await api("/api/data?type=memories&id=all", { method: "DELETE" });
      setMemories([]);
      setPurgeOpen(false);
      setNotice("All long-term memories deleted.");
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Purge failed.");
    } finally {
      setBusy(false);
    }
  };

  const exportMemories = () => {
    const blob = new Blob([JSON.stringify({ exportedAt: new Date().toISOString(), memories }, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "jarvis-memories.json";
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-5">
      <header>
        <p className="eyebrow">Memory core</p>
        <h1 className="mt-1 text-2xl text-white">What JARVIS remembers</h1>
        <p className="mt-1.5 max-w-2xl text-xs leading-relaxed text-muted">
          Chat context is temporary and rebuilt from stored messages. Long-term memory is separate: only the facts below are
          injected into Gemini&apos;s system instruction, and only while memory is enabled.
        </p>
      </header>

      {error && <Alert kind="error" message={error} />}
      {notice && <Alert kind="success" message={notice} />}

      <div className="grid gap-4 lg:grid-cols-[1fr_20rem]">
        <section className="panel p-5">
          <div className="mb-4 flex items-center justify-between">
            <p className="eyebrow">Approved facts · {memories.length}</p>
            <div className="flex gap-1.5">
              <button type="button" onClick={exportMemories} className="btn btn-outline btn-sm" disabled={memories.length === 0}>
                <Download size={12} /> Export
              </button>
              <button type="button" onClick={() => setPurgeOpen(true)} className="btn btn-danger btn-sm" disabled={memories.length === 0}>
                <Trash2 size={12} /> Purge all
              </button>
            </div>
          </div>

          {loading ? (
            <div className="flex items-center gap-2 py-8 text-sm text-muted"><Spinner /> Reading memory bank…</div>
          ) : memories.length === 0 ? (
            <EmptyState
              icon="◍"
              title="Memory is empty"
              body="Add a preference or ask JARVIS to remember something. Sensitive data such as API keys, passwords and payment details is refused."
            />
          ) : (
            <ul className="space-y-2">
              {memories.map((memory) => (
                <li key={memory.id} className="rounded-xl border border-white/8 bg-white/[0.02] p-3">
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <p className="text-sm leading-relaxed text-white">{memory.content}</p>
                      <p className="mt-1 text-[0.58rem] uppercase tracking-[0.22em] text-faint">
                        {memory.category} · {relativeTime(memory.updatedAt)}
                      </p>
                    </div>
                    <div className="flex shrink-0 gap-1">
                      <button
                        type="button"
                        onClick={() => {
                          setEditing(memory);
                          setEditContent(memory.content);
                        }}
                        className="icon-btn"
                        aria-label="Edit memory"
                      >
                        <Pencil size={12} />
                      </button>
                      <button type="button" onClick={() => setDeleteTarget(memory)} className="icon-btn hover:border-rose-400/50 hover:text-rose-200" aria-label="Delete memory">
                        <Trash2 size={12} />
                      </button>
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </section>

        <aside className="space-y-4">
          <section className="panel p-5">
            <p className="eyebrow">Add memory</p>
            <form onSubmit={add} className="mt-3 space-y-3">
              <div>
                <label htmlFor="memory-content" className="label">Fact or preference</label>
                <textarea
                  id="memory-content"
                  value={content}
                  onChange={(event) => setContent(event.target.value)}
                  required
                  minLength={3}
                  maxLength={500}
                  rows={3}
                  className="field resize-none"
                  placeholder="Prefers concise answers with bullet points."
                />
              </div>
              <div>
                <label htmlFor="memory-category" className="label">Category</label>
                <select id="memory-category" value={category} onChange={(event) => setCategory(event.target.value)} className="field">
                  {CATEGORIES.map((entry) => (
                    <option key={entry} value={entry}>{entry}</option>
                  ))}
                </select>
              </div>
              <button type="submit" disabled={busy} className="btn btn-primary btn-sm w-full">
                {busy ? <Spinner size={12} /> : <Plus size={13} />} Save memory
              </button>
            </form>
          </section>

          <section className="panel p-5">
            <p className="eyebrow flex items-center gap-1.5"><BrainCircuit size={12} /> Controls</p>
            <Toggle
              checked={settings?.memoryEnabled ?? true}
              onChange={(next) => void toggleMemory(next)}
              label="Use long-term memory"
              description="When disabled, no memories are sent to Gemini. Chat history still works."
            />
            <div className="mt-2 rounded-xl border border-amber-300/20 bg-amber-500/5 p-3">
              <p className="flex items-center gap-1.5 text-[0.7rem] font-semibold text-amber-100">
                <ShieldOff size={12} /> Complete opt-out
              </p>
              <p className="mt-1 text-[0.65rem] leading-relaxed text-amber-100/70">
                Disabling stops usage immediately. Purging deletes every memory permanently from your workspace.
              </p>
            </div>
          </section>
        </aside>
      </div>

      <Modal open={Boolean(editing)} title="Edit memory" onClose={() => setEditing(null)}>
        <textarea value={editContent} onChange={(event) => setEditContent(event.target.value)} rows={4} className="field resize-none" maxLength={500} />
        <div className="mt-4 flex justify-end gap-2">
          <button type="button" onClick={() => setEditing(null)} className="btn btn-ghost btn-sm">Cancel</button>
          <button type="button" onClick={saveEdit} disabled={busy} className="btn btn-primary btn-sm">Save</button>
        </div>
      </Modal>

      <Modal open={Boolean(deleteTarget)} title="Delete memory" onClose={() => setDeleteTarget(null)}>
        <p className="text-sm text-muted">Remove “{deleteTarget?.content}” from long-term memory?</p>
        <div className="mt-4 flex justify-end gap-2">
          <button type="button" onClick={() => setDeleteTarget(null)} className="btn btn-ghost btn-sm">Cancel</button>
          <button type="button" onClick={remove} disabled={busy} className="btn btn-danger btn-sm">Delete</button>
        </div>
      </Modal>

      <Modal open={purgeOpen} title="Purge all memories" onClose={() => setPurgeOpen(false)}>
        <p className="text-sm leading-relaxed text-muted">
          This permanently deletes all {memories.length} stored memories. Conversations and notes are not affected. This cannot be
          undone.
        </p>
        <div className="mt-4 flex justify-end gap-2">
          <button type="button" onClick={() => setPurgeOpen(false)} className="btn btn-ghost btn-sm">Keep memories</button>
          <button type="button" onClick={purgeAll} disabled={busy} className="btn btn-danger btn-sm">Purge permanently</button>
        </div>
      </Modal>
    </div>
  );
}
