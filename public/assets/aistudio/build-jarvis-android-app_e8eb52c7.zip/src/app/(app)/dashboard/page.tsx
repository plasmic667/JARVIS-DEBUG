"use client";

import Link from "next/link";
import { useCallback, useEffect, useState } from "react";
import {
  ArrowUpRight,
  BellRing,
  BrainCircuit,
  Check,
  ClipboardList,
  MessageSquarePlus,
  NotebookPen,
  Plus,
  Sparkles,
  Timer,
  Waves,
} from "lucide-react";
import { Orb } from "@/components/Orb";
import { VerifyBanner } from "@/components/VerifyBanner";
import { Alert, EmptyState, SectionHeading, Spinner } from "@/components/ui";
import { api, formatWhen, relativeTime, type OverviewResponse, type TaskRow } from "@/lib/client";

const QUICK_ACTIONS = [
  { href: "/chat?prompt=Give%20me%20my%20daily%20briefing.", label: "New conversation", description: "Text the assistant", icon: MessageSquarePlus },
  { href: "/voice", label: "Voice session", description: "Push to talk", icon: Waves },
  { href: "/workspace?tab=notes", label: "Capture note", description: "Save a thought", icon: NotebookPen },
  { href: "/workspace?tab=tasks", label: "Add task", description: "Track an action", icon: ClipboardList },
  { href: "/memory", label: "Memory core", description: "Review what JARVIS knows", icon: BrainCircuit },
  { href: "/workspace?tab=reminders", label: "Reminder", description: "Time-zone aware", icon: Timer },
];

export default function DashboardPage() {
  const [data, setData] = useState<OverviewResponse | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [tasks, setTasks] = useState<TaskRow[]>([]);
  const [updating, setUpdating] = useState<string | null>(null);

  const load = useCallback(async () => {
    try {
      const result = await api<OverviewResponse>("/api/overview");
      setData(result);
      setTasks(result.openTasks ?? []);
      setError(null);
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Could not load the dashboard.");
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const toggleTask = async (task: TaskRow) => {
    setUpdating(task.id);
    setTasks((current) => current.filter((t) => t.id !== task.id));
    try {
      await api("/api/data", { method: "PATCH", body: JSON.stringify({ type: "tasks", id: task.id, completed: true }) });
      void load();
    } catch {
      setTasks((current) => [task, ...current]);
    } finally {
      setUpdating(null);
    }
  };

  const name = data?.user?.displayName?.split(" ")[0] ?? "Operator";
  const hour = new Date().getHours();
  const greeting = hour < 12 ? "Good morning" : hour < 18 ? "Good afternoon" : "Good evening";
  const stats = data?.stats;
  const displayHeading = hour < 12 ? "Systems primed for the day" : hour < 18 ? "All systems nominal" : "Evening protocols active";

  return (
    <div className="space-y-6">
      {error && <Alert kind="error" message={error} hint="Check the connection and reload." />}
      {data?.user && !data.user.emailVerified && (
        <div className="panel p-4">
          <VerifyBanner />
        </div>
      )}

      {/* Hero */}
      <section className="panel relative overflow-hidden p-5 sm:p-7">
        <div className="pointer-events-none absolute -right-24 -top-32 h-80 w-80 rounded-full bg-fuchsia-600/20 blur-3xl" />
        <div className="pointer-events-none absolute -bottom-32 left-1/3 h-72 w-72 rounded-full bg-indigo-600/20 blur-3xl" />
        <div className="relative grid items-center gap-6 lg:grid-cols-[0.9fr_1.1fr]">
          <div className="relative mx-auto h-56 w-56 sm:h-64 sm:w-64 lg:h-72 lg:w-72">
            <Orb state="idle" className="h-full w-full" />
            <div className="pointer-events-none absolute inset-0 rounded-full ring-1 ring-white/5" />
          </div>

          <div>
            <div className="flex flex-wrap items-center gap-2">
              <span className="chip chip-live">
                <span className="dot" /> JARVIS online
              </span>
              <span className="chip">{data?.gemini?.model ?? "gemini-2.5-flash"}</span>
              <span className="chip">Key ••••{data?.gemini?.last4 ?? "----"}</span>
            </div>
            <p className="eyebrow mt-5">{greeting}, {name}</p>
            <h1 className="title-gradient mt-2 text-[1.8rem] leading-tight sm:text-4xl">{displayHeading}</h1>
            <p className="mt-3 max-w-lg text-sm leading-relaxed text-muted">
              Your personal intelligence layer is connected to your own Gemini key. Conversations, memory and tools are stored in
              your private workspace.
            </p>

            <div className="mt-5 inline-flex items-stretch overflow-hidden rounded-xl border border-white/12 bg-black/35 backdrop-blur">
              <div className="px-4 py-2.5">
                <p className="text-lg font-semibold leading-none text-white" style={{ fontFamily: "var(--font-display)" }}>
                  {(stats?.messages ?? 0).toLocaleString()}
                </p>
                <p className="mt-1 text-[0.55rem] uppercase tracking-[0.26em] text-faint">Total exchanges</p>
              </div>
              <div className="w-px bg-white/10" />
              <div className="px-4 py-2.5">
                <p className="text-lg font-semibold leading-none text-fuchsia-200" style={{ fontFamily: "var(--font-display)" }}>
                  {stats?.requestsToday ?? 0}
                </p>
                <p className="mt-1 text-[0.55rem] uppercase tracking-[0.26em] text-faint">Requests today</p>
              </div>
            </div>

            <div className="mt-5 flex flex-wrap gap-2">
              <Link href="/chat" className="btn btn-primary btn-sm">
                <Sparkles size={13} /> Open assistant
              </Link>
              <Link href="/voice" className="btn btn-outline btn-sm">
                <Waves size={13} /> Talk to JARVIS
              </Link>
              <Link href="/chat?prompt=Brief%20me%20on%20my%20day%2C%20then%20suggest%20the%20single%20highest-leverage%20next%20action." className="btn btn-ghost btn-sm">
                Daily briefing <ArrowUpRight size={12} />
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        {[
          { label: "Conversations", value: stats?.conversations ?? 0, accent: "text-fuchsia-200" },
          { label: "Memories", value: stats?.memories ?? 0, accent: "text-violet-200" },
          { label: "Open tasks", value: stats?.openTasks ?? 0, accent: "text-indigo-200" },
          { label: "Notes", value: stats?.notes ?? 0, accent: "text-pink-200" },
        ].map((stat) => (
          <div key={stat.label} className="panel-soft p-4">
            <p className={`text-2xl font-semibold ${stat.accent}`} style={{ fontFamily: "var(--font-display)" }}>
              {data ? stat.value : <span className="inline-block h-6 w-10 rounded shimmer" />}
            </p>
            <p className="mt-1 text-[0.58rem] uppercase tracking-[0.24em] text-faint">{stat.label}</p>
          </div>
        ))}
      </section>

      {/* Quick actions */}
      <section>
        <SectionHeading eyebrow="Command deck" title="Quick actions" />
        <div className="grid grid-cols-2 gap-3 lg:grid-cols-3">
          {QUICK_ACTIONS.map((action) => {
            const Icon = action.icon;
            return (
              <Link key={action.label} href={action.href} className="panel panel-hover group flex items-start gap-3 p-4">
                <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl border border-fuchsia-300/25 bg-fuchsia-500/10 text-fuchsia-200">
                  <Icon size={16} />
                </span>
                <span className="min-w-0">
                  <span className="block truncate text-sm font-semibold text-white">{action.label}</span>
                  <span className="mt-0.5 block text-[0.68rem] text-muted">{action.description}</span>
                </span>
                <Plus size={14} className="ml-auto mt-1 shrink-0 text-faint transition-colors group-hover:text-fuchsia-200" />
              </Link>
            );
          })}
        </div>
      </section>

      <div className="grid gap-4 lg:grid-cols-2">
        {/* Tasks */}
        <section className="panel p-5">
          <SectionHeading
            eyebrow="Mission queue"
            title="Open tasks"
            action={<Link href="/workspace?tab=tasks" className="text-[0.62rem] uppercase tracking-[0.2em] text-fuchsia-200/80 hover:text-white">Manage</Link>}
          />
          {!data ? (
            <div className="flex items-center gap-2 py-6 text-sm text-muted"><Spinner /> Loading tasks…</div>
          ) : tasks.length === 0 ? (
            <EmptyState icon="◎" title="Queue is clear" body="Ask JARVIS to create a task, or add one manually in the workspace." />
          ) : (
            <ul className="space-y-2">
              {tasks.map((task) => (
                <li key={task.id} className="flex items-start gap-3 rounded-xl border border-white/8 bg-white/[0.02] p-3">
                  <button
                    type="button"
                    onClick={() => toggleTask(task)}
                    disabled={updating === task.id}
                    aria-label={`Complete ${task.title}`}
                    className="mt-0.5 grid h-5 w-5 shrink-0 place-items-center rounded-md border border-white/25 text-transparent transition-colors hover:border-emerald-300/70 hover:text-emerald-300"
                  >
                    <Check size={12} />
                  </button>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm text-white">{task.title}</p>
                    <p className="mt-0.5 text-[0.65rem] text-faint">
                      {task.dueAt ? formatWhen(task.dueAt) : "No due date"} · {task.priority}
                    </p>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </section>

        {/* Recent conversations */}
        <section className="panel p-5">
          <SectionHeading
            eyebrow="Transcripts"
            title="Recent conversations"
            action={<Link href="/conversations" className="text-[0.62rem] uppercase tracking-[0.2em] text-fuchsia-200/80 hover:text-white">History</Link>}
          />
          {!data ? (
            <div className="flex items-center gap-2 py-6 text-sm text-muted"><Spinner /> Loading history…</div>
          ) : (data.recentConversations ?? []).length === 0 ? (
            <EmptyState
              icon="⌁"
              title="No conversations yet"
              body="Start with a text or voice session. Streaming replies are saved automatically."
              action={<Link href="/chat" className="btn btn-outline btn-sm">Start talking</Link>}
            />
          ) : (
            <ul className="space-y-2">
              {(data.recentConversations ?? []).map((conversation) => (
                <li key={conversation.id}>
                  <Link href={`/chat?id=${conversation.id}`} className="flex items-start justify-between gap-3 rounded-xl border border-white/8 bg-white/[0.02] p-3 transition-colors hover:border-fuchsia-300/30">
                    <div className="min-w-0">
                      <p className="truncate text-sm text-white">{conversation.title}</p>
                      <p className="mt-0.5 truncate text-[0.68rem] text-muted">{conversation.lastMessagePreview || "No messages yet"}</p>
                    </div>
                    <span className="shrink-0 text-[0.6rem] text-faint">{relativeTime(conversation.updatedAt)}</span>
                  </Link>
                </li>
              ))}
            </ul>
          )}
        </section>
      </div>

      <div className="grid gap-4 lg:grid-cols-[1.1fr_0.9fr]">
        <section className="panel p-5">
          <SectionHeading eyebrow="Memory core" title="What JARVIS remembers" action={<Link href="/memory" className="text-[0.62rem] uppercase tracking-[0.2em] text-fuchsia-200/80 hover:text-white">Inspect</Link>} />
          {(data?.memoryPreview ?? []).length === 0 ? (
            <p className="text-sm text-muted">
              No long-term memories yet. Ask “remember that I prefer concise answers” to create one you can edit or delete at any time.
            </p>
          ) : (
            <ul className="space-y-2">
              {(data?.memoryPreview ?? []).map((memory) => (
                <li key={memory.content} className="rounded-xl border border-white/8 bg-white/[0.02] p-3">
                  <p className="text-sm text-white">{memory.content}</p>
                  <p className="mt-1 text-[0.6rem] uppercase tracking-[0.2em] text-faint">{memory.category}</p>
                </li>
              ))}
            </ul>
          )}
        </section>

        <section className="panel p-5">
          <SectionHeading eyebrow="Reminders" title="Upcoming" action={<BellRing size={15} className="text-fuchsia-200/70" />} />
          {(data?.upcomingReminders ?? []).length === 0 ? (
            <p className="text-sm text-muted">No scheduled reminders. Add one in the workspace and allow notifications for delivery.</p>
          ) : (
            <ul className="space-y-2">
              {(data?.upcomingReminders ?? []).map((reminder) => (
                <li key={reminder.id} className="flex items-center justify-between gap-3 rounded-xl border border-white/8 bg-white/[0.02] p-3">
                  <span className="truncate text-sm text-white">{reminder.title}</span>
                  <span className="shrink-0 text-[0.62rem] text-fuchsia-200/80">{formatWhen(reminder.remindAt)}</span>
                </li>
              ))}
            </ul>
          )}
          <p className="mt-3 text-[0.62rem] leading-relaxed text-faint">
            Delivery depends on browser notification permission and OS power management. JARVIS does not promise exact-time
            delivery when the app is closed.
          </p>
        </section>
      </div>
    </div>
  );
}
