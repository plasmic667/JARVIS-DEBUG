"use client";

import Link from "next/link";
import { useEffect, useRef, useState } from "react";
import { AlertTriangle, Mic, MicOff, Send, Volume2, VolumeX } from "lucide-react";
import { Orb, type OrbState } from "@/components/Orb";
import { Alert, MarkdownView, Spinner, Toggle } from "@/components/ui";
import { api, streamChat, type AssistantSettings } from "@/lib/client";
import { speakableText } from "@/lib/personality";
import { speechAvailable, useDictation, useSpeaker } from "@/lib/speech";

const LANGUAGES = [
  { code: "en-US", label: "English (US)" },
  { code: "en-GB", label: "English (UK)" },
  { code: "es-ES", label: "Español" },
  { code: "fr-FR", label: "Français" },
  { code: "de-DE", label: "Deutsch" },
  { code: "hi-IN", label: "हिन्दी" },
  { code: "ar-SA", label: "العربية" },
  { code: "ja-JP", label: "日本語" },
];

export default function VoicePage() {
  const [settings, setSettings] = useState<AssistantSettings | null>(null);
  const [language, setLanguage] = useState("en-US");
  const [muted, setMuted] = useState(false);
  const [turns, setTurns] = useState<Array<{ role: "user" | "assistant"; content: string }>>([]);
  const [thinking, setThinking] = useState(false);
  const [error, setError] = useState<{ message: string; hint?: string; code?: string } | null>(null);
  const [fallback, setFallback] = useState("");
  const [conversationId, setConversationId] = useState<string | null>(null);
  const [capabilities, setCapabilities] = useState({ recognition: false, synthesis: false });
  const conversationRef = useRef<string | null>(null);
  const speaker = useSpeaker();

  useEffect(() => {
    setCapabilities(speechAvailable());
    api<{ settings: AssistantSettings }>("/api/settings")
      .then((data) => setSettings(data.settings))
      .catch(() => undefined);
  }, []);

  const ask = async (text: string) => {
    if (!text.trim() || thinking) return;
    setError(null);
    setTurns((current) => [...current, { role: "user", content: text }, { role: "assistant", content: "" }]);
    setThinking(true);
    let full = "";
    await streamChat(
      { conversationId: conversationRef.current ?? undefined, message: text },
      {
        onEvent: (event) => {
          if (event.type === "meta") {
            conversationRef.current = event.conversationId;
            setConversationId(event.conversationId);
          } else if (event.type === "token") {
            full += event.value;
            setTurns((current) => {
              const next = [...current];
              next[next.length - 1] = { role: "assistant", content: full };
              return next;
            });
          } else if (event.type === "done") {
            full = event.content;
            setThinking(false);
            if (!muted && speaker.supported && settings) {
              speaker.speak(speakableText(event.content), {
                rate: settings.voiceRate,
                pitch: settings.voicePitch,
                voiceName: settings.voiceName,
                lang: language,
              });
            }
          } else if (event.type === "error") {
            setThinking(false);
            setError({ message: event.message, hint: event.hint, code: event.code });
          }
        },
      },
    ).catch((caught) => {
      setThinking(false);
      setError({ message: caught instanceof Error ? caught.message : "Voice request failed." });
    });
    setThinking(false);
  };

  const dictation = useDictation({ lang: language, onFinal: (text) => void ask(text) });

  const patchSettings = async (updates: Partial<AssistantSettings>) => {
    if (!settings) return;
    const optimistic = { ...settings, ...updates };
    setSettings(optimistic);
    try {
      await api("/api/settings", { method: "PATCH", body: JSON.stringify(updates) });
    } catch {
      setSettings(settings);
    }
  };

  const state: OrbState = dictation.listening ? "listening" : thinking ? "thinking" : speaker.speaking ? "speaking" : "idle";
  const statusCopy = dictation.listening
    ? "Listening — speak now"
    : thinking
      ? "Thinking with Gemini…"
      : speaker.speaking
        ? "Speaking — tap stop to interrupt"
        : "Push to talk";

  const englishVoices = speaker.voices.filter((voice) => voice.lang.startsWith(language.slice(0, 2)));

  return (
    <div className="grid gap-4 lg:grid-cols-[1.15fr_0.85fr]">
      <section className="panel relative flex flex-col items-center overflow-hidden p-5 text-center sm:p-7">
        <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-fuchsia-400/50 to-transparent" />
        <p className="eyebrow">Voice uplink</p>
        <h1 className="title-gradient mt-2 text-2xl sm:text-3xl">Talk to JARVIS</h1>
        <p className="mt-2 max-w-sm text-xs leading-relaxed text-muted">
          Push-to-talk is the reliable default. Speech recognition and synthesis run through your browser/OS speech services;
          your Gemini key stays server-side.
        </p>

        <div className="relative my-4 h-56 w-56 sm:h-64 sm:w-64">
          {dictation.listening && <span className="ring-pulse" />}
          <Orb state={state} className="h-full w-full" />
        </div>

        <p className="flex items-center gap-2 text-sm font-medium text-white">
          {thinking && <Spinner size={13} />}
          {statusCopy}
        </p>

        <div className="mt-3 flex flex-wrap items-center justify-center gap-2">
          <button
            type="button"
            onClick={() => (dictation.listening ? dictation.stop() : dictation.start())}
            disabled={thinking || !capabilities.recognition}
            className={`btn ${dictation.listening ? "btn-danger" : "btn-primary"} px-6`}
            aria-pressed={dictation.listening}
          >
            {dictation.listening ? <MicOff size={16} /> : <Mic size={16} />}
            {dictation.listening ? "Stop listening" : "Push to talk"}
          </button>
          {speaker.speaking ? (
            <button type="button" onClick={speaker.stop} className="btn btn-outline">
              <VolumeX size={15} /> Stop speaking
            </button>
          ) : (
            <button
              type="button"
              onClick={() => setMuted((value) => !value)}
              className="btn btn-outline"
              aria-pressed={muted}
              aria-label={muted ? "Unmute spoken replies" : "Mute spoken replies"}
            >
              {muted ? <VolumeX size={15} /> : <Volume2 size={15} />} {muted ? "Replies muted" : "Mute replies"}
            </button>
          )}
        </div>

        {!capabilities.recognition && (
          <div className="mt-4 w-full max-w-md">
            <Alert
              kind="warning"
              message="Speech recognition is unavailable in this browser."
              hint="JARVIS never pretends to listen while the microphone is unavailable. Use the text fallback, or open this app in Chrome/Edge with microphone permission."
            />
          </div>
        )}
        {dictation.error && (
          <div className="mt-3 w-full max-w-md">
            <Alert kind="warning" message={dictation.error} />
          </div>
        )}
        {!capabilities.synthesis && (
          <p className="mt-3 max-w-sm text-[0.65rem] text-amber-200/80">
            <AlertTriangle size={11} className="mr-1 inline" /> Speech synthesis is unavailable, so replies stay on screen.
          </p>
        )}
        {error && (
          <div className="mt-3 w-full max-w-md">
            <Alert
              kind="error"
              message={error.message}
              hint={error.hint}
              action={
                error.code === "gemini_invalid" || error.code === "gemini_not_connected" ? (
                  <Link href="/connect" className="btn btn-outline btn-sm">Reconnect Gemini</Link>
                ) : undefined
              }
            />
          </div>
        )}

        <div className="mt-4 w-full max-w-md">
          <label htmlFor="voice-fallback" className="label text-left">
            Text fallback
          </label>
          <div className="flex gap-2">
            <input
              id="voice-fallback"
              value={fallback}
              onChange={(event) => setFallback(event.target.value)}
              onKeyDown={(event) => {
                if (event.key === "Enter") {
                  event.preventDefault();
                  const text = fallback;
                  setFallback("");
                  void ask(text);
                }
              }}
              placeholder="Type if the microphone is unavailable…"
              className="field"
            />
            <button
              type="button"
              onClick={() => {
                const text = fallback;
                setFallback("");
                void ask(text);
              }}
              disabled={!fallback.trim() || thinking}
              className="btn btn-outline px-4"
              aria-label="Send typed message"
            >
              <Send size={14} />
            </button>
          </div>
        </div>
      </section>

      <div className="space-y-4">
        <section className="panel p-5">
          <p className="eyebrow">Voice configuration</p>
          <div className="mt-3 grid gap-3">
            <div>
              <label htmlFor="lang" className="label">Recognition language</label>
              <select id="lang" value={language} onChange={(event) => setLanguage(event.target.value)} className="field">
                {LANGUAGES.map((entry) => (
                  <option key={entry.code} value={entry.code}>{entry.label}</option>
                ))}
              </select>
            </div>
            <div>
              <label htmlFor="voice" className="label">System voice</label>
              <select
                id="voice"
                value={settings?.voiceName ?? ""}
                onChange={(event) => void patchSettings({ voiceName: event.target.value || null })}
                className="field"
              >
                <option value="">Automatic (best available)</option>
                {englishVoices.map((voice) => (
                  <option key={voice.name} value={voice.name}>{voice.name} · {voice.lang}</option>
                ))}
              </select>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label htmlFor="rate" className="label">Rate · {settings?.voiceRate.toFixed(2) ?? "1.00"}</label>
                <input
                  id="rate"
                  type="range"
                  min={0.6}
                  max={1.6}
                  step={0.05}
                  value={settings?.voiceRate ?? 1}
                  onChange={(event) => setSettings((current) => (current ? { ...current, voiceRate: Number(event.target.value) } : current))}
                  onMouseUp={(event) => void patchSettings({ voiceRate: Number((event.target as HTMLInputElement).value) })}
                  onTouchEnd={(event) => void patchSettings({ voiceRate: Number((event.target as HTMLInputElement).value) })}
                  className="mt-1 h-1.5 w-full cursor-pointer appearance-none rounded-full bg-white/10 accent-fuchsia-400"
                />
              </div>
              <div>
                <label htmlFor="pitch" className="label">Pitch · {settings?.voicePitch.toFixed(2) ?? "0.95"}</label>
                <input
                  id="pitch"
                  type="range"
                  min={0.5}
                  max={1.5}
                  step={0.05}
                  value={settings?.voicePitch ?? 0.95}
                  onChange={(event) => setSettings((current) => (current ? { ...current, voicePitch: Number(event.target.value) } : current))}
                  onMouseUp={(event) => void patchSettings({ voicePitch: Number((event.target as HTMLInputElement).value) })}
                  onTouchEnd={(event) => void patchSettings({ voicePitch: Number((event.target as HTMLInputElement).value) })}
                  className="mt-1 h-1.5 w-full cursor-pointer appearance-none rounded-full bg-white/10 accent-fuchsia-400"
                />
              </div>
            </div>
            <div className="border-t border-white/8 pt-1">
              <Toggle
                checked={settings?.autoSpeak ?? true}
                onChange={(next) => void patchSettings({ autoSpeak: next })}
                label="Speak replies automatically"
                description="Applies to text chat too. You can always interrupt playback."
              />
            </div>
          </div>
          <p className="mt-2 text-[0.62rem] leading-relaxed text-faint">
            Wake-word listening is intentionally not enabled: browsers suspend background microphone capture, and always-on audio
            would require explicit OS-level permissions. Push-to-talk is the honest, reliable path.
          </p>
        </section>

        <section className="panel p-5">
          <p className="eyebrow">Live transcript</p>
          <div className="scroll-thin mt-3 max-h-72 space-y-2.5 overflow-y-auto pr-1">
            {turns.length === 0 ? (
              <p className="text-xs text-muted">Press “Push to talk” and speak. Your request and JARVIS&apos;s reply appear here.</p>
            ) : (
              turns.map((turn, index) => (
                <div key={index} className={`rounded-xl border p-2.5 ${turn.role === "user" ? "border-fuchsia-300/25 bg-fuchsia-500/10" : "border-white/10 bg-white/[0.03]"}`}>
                  <p className="mb-1 text-[0.55rem] uppercase tracking-[0.25em] text-faint">{turn.role === "user" ? "You" : "JARVIS"}</p>
                  {turn.role === "assistant" ? <MarkdownView content={turn.content || "…"} /> : <p className="text-sm text-white">{turn.content}</p>}
                </div>
              ))
            )}
          </div>
          {conversationId && (
            <Link href={`/chat?id=${conversationId}`} className="btn btn-outline btn-sm mt-3 w-full">
              Open in text chat
            </Link>
          )}
        </section>
      </div>
    </div>
  );
}
