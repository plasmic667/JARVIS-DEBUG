export default function AppLoading() {
  return (
    <div className="space-y-4" role="status" aria-label="Loading interface">
      <div className="panel h-48 shimmer rounded-[22px]" />
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        {Array.from({ length: 4 }).map((_, index) => (
          <div key={index} className="panel-soft h-20 shimmer" />
        ))}
      </div>
      <div className="grid gap-3 lg:grid-cols-2">
        <div className="panel h-56 shimmer" />
        <div className="panel h-56 shimmer" />
      </div>
    </div>
  );
}
