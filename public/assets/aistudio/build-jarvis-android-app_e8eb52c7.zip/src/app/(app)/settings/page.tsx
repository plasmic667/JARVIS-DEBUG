"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useCallback, useEffect, useState } from "react";
import { Download, ExternalLink, KeyRound, LogOut, RefreshCcw, Settings2, ShieldCheck, Trash2, Unplug } from "lucide-react";
import { Alert, Logo, Modal, Range, Spinner, Toggle } from "@/components/ui";
import { VerifyBanner } from "@/components/VerifyBanner";
import { api, ClientError, type AssistantSettings, type SessionResponse } from "@/lib/client";
import { PERSONALITY_MODES } from "@/lib/personality";
import { useSpeaker } from "@/lib/speech";

type GeminiModel = { id: string; displayName: string; description: string };

export default function SettingsPage() {
  const router = useRouter();
  const speaker = useSpeaker();
  const [session, setSession] = useState<SessionResponse | null>(null);
  const [settings, setSettings] = useState<AssistantSettings | null>(null);
  const [models, setModels] = useState<GeminiModel[]>([]);
  const [selectedModel, setSelectedModel] = useState("");
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState<string | null>(null);
  const [error, setError] = useState<{ message: string; hint?: string } | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [disconnectOpen, setDisconnectOpen] = useState(false);
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [deletePassword, setDeletePassword] = useState("");

  const load = useCallback(async () => {
    try {
      const [sessionData, settingsData] = await Promise.all([
        api<SessionResponse>("/api/session"),
        api<{ settings: AssistantSettings }>("/api/settings"),
      ]);
      setSession(sessionData);
      setSettings(settingsData.settings);
      setSelectedModel(sessionData.gemini.model ?? settingsData.settings.model);
    } catch (caught) {
      setError({ message: caught instanceof Error ? caught.message : "Could not load settings." });
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const save = async (updates: Partial<AssistantSettings>, label = "Preferences saved.") => {
    if (!settings) return;
    const previous = settings;
    setSettings({ ...settings, ...updates });
    setBusy("settings");
    setError(null);
    try {
      const data = await api<{ settings: AssistantSettings }>("/api/settings", { method: "PATCH", body: JSON.stringify(updates) });
      setSettings(data.settings);
      setNotice(label);
    } catch (caught) {
      setSettings(previous);
      setError({ message: caught instanceof Error ? caught.message : "Could not save preferences." });
    } finally {
      setBusy(null);
    }
  };

  const runGemini = async (action: string, extra?: Record<string, unknown>) => {
    setBusy(action);
    setError(null);
    setNotice(null);
    try {
      const data = await api<{ message?: string; models?: GeminiModel[]; model?: string }>("/api/gemini", {
        method: "POST",
        body: JSON.stringify({ action, ...extra }),
      });
      if (action === "models" && data.models) {
        setModels(data.models);
        setNotice(`${data.models.length} models available to your key.`);
      } else {
        setNotice(data.message ?? "Gemini action completed.");
      }
      await load();
    } catch (caught) {
      const clientError = caught instanceof ClientError ? caught : null;
      setError({ message: clientError?.message ?? "Gemini action failed.", hint: clientError?.hint });
    } finally {
      setBusy(null);
    }
  };

  const disconnect = async () => {
    await runGemini("disconnect");
    setDisconnectOpen(false);
    router.replace("/connect");
    router.refresh();
  };

  const deleteAccount = async () => {
    setBusy("delete");
    setError(null);
    try {
      await api("/api/auth/delete", { method: "POST", body: JSON.stringify({ password: deletePassword }) });
      router.replace("/connect");
      router.refresh();
    } catch (caught) {
      const clientError = caught instanceof ClientError ? caught : null;
      setError({ message: clientError?.message ?? "Account deletion failed.", hint: clientError?.hint });
    } finally {
      setBusy(null);
    }
  };

  const signOut = async () => {
    setBusy("logout");
    await api("/api/auth/logout", { method: "POST", body: JSON.stringify({}) }).catch(() => undefined);
    router.replace("/auth");
    router.refresh();
  };

  if (loading || !settings) {
    return (
      <div className="flex items-center gap-2 py-16 text-sm text-muted">
        <Spinner /> Loading settings…
      </div>
    );
  }

  const englishVoices = speaker.voices.filter((voice) => voice.lang.startsWith("en"));

  return (
    <div className="space-y-5">
      <header>
        <p className="eyebrow">Configuration</p>
        <h1 className="mt-1 text-2xl text-white">Settings</h1>
        <p className="mt-1.5 max-w-2xl text-xs leading-relaxed text-muted">
          Personality, voice and privacy are separate from the Gemini credential. Changes apply to the next request — no restart
          needed.
        </p>
      </header>

      {error && <Alert kind="error" message={error.message} hint={error.hint} />}
      {notice && <Alert kind="success" message={notice} />}
      {session?.user && !session.user.emailVerified && (
        <div className="panel p-4"><VerifyBanner /></div>
      )}

      {/* Gemini */}
      <section className="panel p-5">
        <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
          <div>
            <p className="eyebrow">Gemini uplink</p>
            <h2 className="mt-1 text-lg text-white">Your API key</h2>
          </div>
          <span className={`chip ${session?.gemini.connected ? "chip-live" : "chip-danger"}`}>
            <span className="dot" /> {session?.gemini.connected ? "Connected" : "Not connected"}
          </span>
        </div>
        <div className="grid gap-3 sm:grid-cols-3">
          <div className="panel-soft p-3">
            <p className="text-[0.55rem] uppercase tracking-[0.24em] text-faint">Key</p>
            <p className="mono mt-1 text-sm text-white">••••{session?.gemini.last4 ?? "----"}</p>
          </div>
          <div className="panel-soft p-3">
            <p className="text-[0.55rem] uppercase tracking-[0.24em] text-faint">Active model</p>
            <p className="mono mt-1 truncate text-sm text-white">{session?.gemini.model ?? settings.model}</p>
          </div>
          <div className="panel-soft p-3">
            <p className="text-[0.55rem] uppercase tracking-[0.24em] text-faint">Storage</p>
            <p className="mt-1 flex items-center gap-1.5 text-sm text-white"><ShieldCheck size={13} className="text-emerald-300" /> AES-256-GCM</p>
          </div>
        </div>

        <div className="mt-3 flex flex-wrap gap-2">
          <button type="button" onClick={() => void runGemini("test")} disabled={busy !== null} className="btn btn-outline btn-sm">
            {busy === "test" ? <Spinner size={12} /> : <RefreshCcw size={12} />} Test live connection
          </button>
          <button type="button" onClick={() => void runGemini("models")} disabled={busy !== null} className="btn btn-outline btn-sm">
            {busy === "models" ? <Spinner size={12} /> : <Settings2 size={12} />} Load models from my key
          </button>
          <Link href="/connect?change=1" className="btn btn-outline btn-sm">
            <KeyRound size={12} /> Replace key (validated)
          </Link>
          <button type="button" onClick={() => setDisconnectOpen(true)} className="btn btn-danger btn-sm">
            <Unplug size={12} /> Disconnect &amp; delete key
          </button>
        </div>

        {models.length > 0 && (
          <div className="mt-4 rounded-xl border border-white/8 bg-white/[0.02] p-3">
            <label htmlFor="model-select" className="label">Switch model (live-validated)</label>
            <div className="flex flex-col gap-2 sm:flex-row">
              <select id="model-select" value={selectedModel} onChange={(event) => setSelectedModel(event.target.value)} className="field flex-1">
                {models.map((model) => (
                  <option key={model.id} value={model.id}>{model.displayName} · {model.id}</option>
                ))}
              </select>
              <button
                type="button"
                onClick={() => void runGemini("set-model", { model: selectedModel })}
                disabled={busy !== null}
                className="btn btn-primary btn-sm"
              >
                {busy === "set-model" ? <Spinner size={12} /> : null} Switch model
              </button>
            </div>
            <p className="mt-2 text-[0.62rem] leading-relaxed text-faint">
              Model availability and quota are controlled by your Google AI Studio project. Usage is billed by Google against
              your own key.
            </p>
          </div>
        )}
      </section>

      {/* Personality */}
      <section className="panel p-5">
        <p className="eyebrow">Personality engine</p>
        <h2 className="mt-1 text-lg text-white">Tone &amp; behaviour</h2>
        <div className="mt-3 grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
          {PERSONALITY_MODES.map((mode) => (
            <button
              key={mode.id}
              type="button"
              onClick={() => void save({ personality: mode.id }, `Personality set to ${mode.label}.`)}
              className={`rounded-xl border p-3 text-left transition-all ${
                settings.personality === mode.id
                  ? "border-fuchsia-300/50 bg-fuchsia-500/10 shadow-[0_0_30px_-14px_rgba(217,70,239,0.9)]"
                  : "border-white/8 bg-white/[0.02] hover:border-white/20"
              }`}
              aria-pressed={settings.personality === mode.id}
            >
              <p className="text-sm font-semibold text-white">{mode.label}</p>
              <p className="mt-1 text-[0.68rem] leading-relaxed text-muted">{mode.blurb}</p>
              <p className="mt-1.5 text-[0.58rem] uppercase tracking-[0.18em] text-faint">{mode.voiceHint}</p>
            </button>
          ))}
        </div>

        {settings.personality === "custom" && (
          <div className="mt-3">
            <label htmlFor="custom-personality" className="label">Custom directive</label>
            <textarea
              id="custom-personality"
              rows={3}
              value={settings.customPersonality ?? ""}
              onChange={(event) => setSettings({ ...settings, customPersonality: event.target.value })}
              className="field resize-none"
              placeholder="Speak like a laconic mission controller. Never use emoji. Always offer one next step."
            />
            <button
              type="button"
              onClick={() => void save({ customPersonality: settings.customPersonality }, "Custom personality saved.")}
              disabled={(settings.customPersonality ?? "").trim().length < 10 || busy !== null}
              className="btn btn-primary btn-sm mt-2"
            >
              Save directive
            </button>
          </div>
        )}

        <div className="mt-4 grid gap-4 sm:grid-cols-2">
          <div>
            <Range label="Humour" min={0} max={3} step={1} value={settings.humor} display={["None", "Light", "Occasional", "Playful"][settings.humor] ?? "Occasional"} onChange={(value) => void save({ humor: value })} />
            <Range label="Expressiveness" min={0} max={3} step={1} value={settings.expressiveness} display={["Plain", "Minimal", "Expressive", "Theatrical"][settings.expressiveness] ?? "Expressive"} onChange={(value) => void save({ expressiveness: value })} />
            <Range label="Creativity (temperature)" min={0} max={1.4} step={0.1} value={settings.temperature} display={settings.temperature.toFixed(1)} onChange={(value) => setSettings({ ...settings, temperature: value })} />
            <button type="button" onClick={() => void save({ temperature: settings.temperature }, "Creativity saved.")} className="btn btn-outline btn-sm mt-1">
              Apply creativity
            </button>
          </div>
          <div>
            <p className="label">Response length</p>
            <div className="flex gap-1 rounded-full border border-white/10 bg-black/30 p-1">
              {["concise", "balanced", "detailed"].map((option) => (
                <button
                  key={option}
                  type="button"
                  onClick={() => void save({ responseLength: option }, `Response length: ${option}.`)}
                  className={`flex-1 rounded-full px-2 py-1.5 text-[0.6rem] uppercase tracking-[0.14em] ${
                    settings.responseLength === option ? "bg-white/10 text-white" : "text-muted hover:text-white"
                  }`}
                >
                  {option}
                </button>
              ))}
            </div>
            <Toggle checked={settings.autoSpeak} onChange={(next) => void save({ autoSpeak: next })} label="Speak replies automatically" description="Interruptible text-to-speech in chat and voice." />
            <Toggle checked={settings.animations} onChange={(next) => void save({ animations: next })} label="Expressive animations" description="Orb motion, halos and waveform reactions." />
            <Toggle checked={settings.memoryEnabled} onChange={(next) => void save({ memoryEnabled: next }, next ? "Memory enabled." : "Memory opted out.")} label="Use long-term memory" description="Injects approved memories into the system instruction." />
          </div>
        </div>
      </section>

      {/* Voice */}
      <section className="panel p-5">
        <p className="eyebrow">Speech output</p>
        <h2 className="mt-1 text-lg text-white">Voice</h2>
        <div className="mt-3 grid gap-4 sm:grid-cols-2">
          <div>
            <label htmlFor="voice-name" className="label">System voice</label>
            <select
              id="voice-name"
              value={settings.voiceName ?? ""}
              onChange={(event) => void save({ voiceName: event.target.value || null }, "Voice saved.")}
              className="field"
            >
              <option value="">Automatic (best English voice)</option>
              {englishVoices.map((voice) => (
                <option key={voice.name} value={voice.name}>{voice.name}</option>
              ))}
            </select>
            <p className="mt-1.5 text-[0.62rem] text-faint">
              {speaker.supported ? `${speaker.voices.length} system voices detected.` : "Speech synthesis is unavailable in this browser."}
            </p>
          </div>
          <div>
            <Range label="Rate" min={0.6} max={1.6} step={0.05} value={settings.voiceRate} display={settings.voiceRate.toFixed(2)} onChange={(value) => setSettings({ ...settings, voiceRate: value })} />
            <Range label="Pitch" min={0.5} max={1.5} step={0.05} value={settings.voicePitch} display={settings.voicePitch.toFixed(2)} onChange={(value) => setSettings({ ...settings, voicePitch: value })} />
            <button
              type="button"
              onClick={() => {
                void save({ voiceRate: settings.voiceRate, voicePitch: settings.voicePitch }, "Voice profile saved.");
                speaker.speak("Voice calibrated. All systems nominal.", { rate: settings.voiceRate, pitch: settings.voicePitch, voiceName: settings.voiceName });
              }}
              className="btn btn-outline btn-sm mt-1"
            >
              Save &amp; preview
            </button>
          </div>
        </div>
      </section>

      {/* Privacy & account */}
      <section id="privacy" className="grid gap-4 lg:grid-cols-2">
        <div className="panel p-5">
          <p className="eyebrow">Privacy &amp; data</p>
          <h2 className="mt-1 text-lg text-white">Your controls</h2>
          <ul className="mt-3 space-y-2 text-xs leading-relaxed text-muted">
            <li className="flex items-start gap-2"><ShieldCheck size={13} className="mt-0.5 shrink-0 text-emerald-300" /> Gemini keys are encrypted with AES-256-GCM and never written to logs, analytics, exports or crash reports.</li>
            <li className="flex items-start gap-2"><ShieldCheck size={13} className="mt-0.5 shrink-0 text-emerald-300" /> Each account can only read its own rows. Every API route enforces ownership server-side.</li>
            <li className="flex items-start gap-2"><ShieldCheck size={13} className="mt-0.5 shrink-0 text-emerald-300" /> Prompts and completions are sent only to Google&apos;s Gemini API using your key.</li>
            <li className="flex items-start gap-2"><ShieldCheck size={13} className="mt-0.5 shrink-0 text-emerald-300" /> Usage telemetry stores route, model, latency and status — never message content.</li>
          </ul>
          <div className="mt-4 flex flex-wrap gap-2">
            <a href="/api/export" className="btn btn-outline btn-sm">
              <Download size={12} /> Export all data
            </a>
            <Link href="/memory" className="btn btn-outline btn-sm">Memory controls</Link>
            <Link href="/workspace?tab=reminders" className="btn btn-outline btn-sm">Notification permission</Link>
          </div>
          <p className="mt-3 text-[0.62rem] leading-relaxed text-faint">
            Local development delivers verification and reset links through an in-app inbox because no mail provider is
            configured. Replace with Firebase Authentication email actions before release.
          </p>
        </div>

        <div className="panel p-5">
          <p className="eyebrow">Account</p>
          <h2 className="mt-1 text-lg text-white">Operator profile</h2>
          <div className="mt-3 space-y-1 text-sm">
            <p className="text-white">{session?.user?.displayName}</p>
            <p className="text-xs text-muted">{session?.user?.email}</p>
            <p className="text-[0.62rem] text-faint">Member since {session?.user ? new Date(session.user.createdAt).toLocaleDateString() : "—"}</p>
          </div>
          <div className="mt-4 flex flex-wrap gap-2">
            <button type="button" onClick={signOut} disabled={busy !== null} className="btn btn-outline btn-sm">
              <LogOut size={12} /> Sign out
            </button>
            <button type="button" onClick={() => setDeleteOpen(true)} className="btn btn-danger btn-sm">
              <Trash2 size={12} /> Delete account &amp; data
            </button>
          </div>
          <div className="mt-4 rounded-xl border border-white/8 bg-white/[0.02] p-3">
            <p className="flex items-center gap-1.5 text-[0.68rem] font-semibold text-white"><ExternalLink size={12} /> Native Android build notes</p>
            <p className="mt-1 text-[0.62rem] leading-relaxed text-faint">
              This deployment is the web implementation of the JARVIS spec: the same onboarding gate, Gemini validation,
              personality engine, repositories and encrypted vault. The Android/Kotlin + Firebase mapping is documented in
              <span className="mono text-fuchsia-200/80"> README.md</span>.
            </p>
            <div className="mt-2 flex items-center gap-2 text-[0.6rem] text-faint"><Logo compact href="/dashboard" /> JARVIS AI · v1.0</div>
          </div>
        </div>
      </section>

      <Modal open={disconnectOpen} title="Disconnect Gemini" onClose={() => setDisconnectOpen(false)}>
        <p className="text-sm leading-relaxed text-muted">
          The encrypted key will be permanently removed from this device and you will return to the connection screen. Your
          account, conversations and memories are kept.
        </p>
        <div className="mt-4 flex justify-end gap-2">
          <button type="button" onClick={() => setDisconnectOpen(false)} className="btn btn-ghost btn-sm">Keep key</button>
          <button type="button" onClick={disconnect} disabled={busy !== null} className="btn btn-danger btn-sm">
            {busy === "disconnect" ? <Spinner size={12} /> : <Unplug size={12} />} Disconnect
          </button>
        </div>
      </Modal>

      <Modal open={deleteOpen} title="Delete account" onClose={() => setDeleteOpen(false)}>
        <p className="text-sm leading-relaxed text-muted">
          This permanently deletes your account, conversations, messages, memories, notes, tasks, reminders and encrypted Gemini
          key. This cannot be undone. Confirm with your password.
        </p>
        <label htmlFor="delete-password" className="label mt-3">Password</label>
        <input id="delete-password" type="password" value={deletePassword} onChange={(event) => setDeletePassword(event.target.value)} className="field" autoComplete="current-password" />
        <div className="mt-4 flex justify-end gap-2">
          <button type="button" onClick={() => setDeleteOpen(false)} className="btn btn-ghost btn-sm">Cancel</button>
          <button type="button" onClick={deleteAccount} disabled={busy !== null || !deletePassword} className="btn btn-danger btn-sm">
            {busy === "delete" ? <Spinner size={12} /> : <Trash2 size={12} />} Delete everything
          </button>
        </div>
      </Modal>
    </div>
  );
}
