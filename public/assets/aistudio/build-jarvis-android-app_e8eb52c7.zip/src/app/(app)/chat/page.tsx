"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { Copy, Loader2, Mic, MicOff, RefreshCcw, Send, Square, Volume2, VolumeX, Wrench } from "lucide-react";
import { Orb, Waveform } from "@/components/Orb";
import { Alert, EmptyState, MarkdownView, Spinner } from "@/components/ui";
import {
  api,
  relativeTime,
  streamChat,
  type AssistantSettings,
  type ConversationRow,
  type MessageRow,
} from "@/lib/client";
import { speakableText } from "@/lib/personality";
import { useDictation, useSpeaker } from "@/lib/speech";

type ChatMessage = MessageRow & { streaming?: boolean; tools?: Array<{ name: string; summary: string }> };

const QUICK_PROMPTS = [
  "Brief me on my day and prioritise my tasks.",
  "Remember that I prefer concise, factual answers.",
  "Draft a polite follow-up email about a delayed project.",
  "Calculate 18% of 4,250 and explain the result.",
];

export default function ChatPage() {
  const router = useRouter();
  const [conversationId, setConversationId] = useState<string | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [conversations, setConversations] = useState<ConversationRow[]>([]);
  const [input, setInput] = useState("");
  const [streaming, setStreaming] = useState(false);
  const [error, setError] = useState<{ message: string; hint?: string; code?: string } | null>(null);
  const [settings, setSettings] = useState<AssistantSettings | null>(null);
  const [model, setModel] = useState<string>("gemini-2.5-flash");
  const [loading, setLoading] = useState(true);
  const abortRef = useRef<AbortController | null>(null);
  const bottomRef = useRef<HTMLDivElement | null>(null);
  const inputRef = useRef<HTMLTextAreaElement | null>(null);
  const speaker = useSpeaker();

  const sendRef = useRef<(text: string) => void>(() => undefined);

  const dictation = useDictation({
    onFinal: (text) => {
      setInput((current) => (current ? `${current} ${text}` : text));
      inputRef.current?.focus();
    },
  });

  const loadSidebar = useCallback(async () => {
    try {
      const data = await api<{ conversations: ConversationRow[] }>("/api/conversations");
      setConversations(data.conversations);
    } catch {
      /* sidebar is non-critical */
    }
  }, []);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const requestedId = params.get("id");
    const prompt = params.get("prompt");

    api<{ settings: AssistantSettings }>("/api/settings")
      .then((data) => {
        setSettings(data.settings);
        setModel(data.settings.model);
      })
      .catch(() => undefined);

    void loadSidebar();

    if (requestedId) {
      setConversationId(requestedId);
      api<{ conversation: ConversationRow; messages: MessageRow[] }>(`/api/conversations?id=${requestedId}`)
        .then((data) => {
          setMessages(data.messages);
          setModel(data.conversation ? settingsModelFallback(data.conversation) : model);
        })
        .catch((caught) => setError({ message: caught instanceof Error ? caught.message : "Could not load conversation." }))
        .finally(() => setLoading(false));
    } else {
      setLoading(false);
    }

    if (prompt) {
      setInput(prompt);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [loadSidebar]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  }, [messages, streaming]);

  function settingsModelFallback(_conversation: ConversationRow) {
    return model;
  }

  const appendToken = (chunk: string) => {
    setMessages((current) => {
      const next = [...current];
      const last = next[next.length - 1];
      if (last && last.streaming) {
        next[next.length - 1] = { ...last, content: last.content + chunk };
      }
      return next;
    });
  };

  const runGeneration = async (payload: { message?: string; regenerate?: boolean }) => {
    setError(null);
    setStreaming(true);
    const controller = new AbortController();
    abortRef.current = controller;
    let finishedConversation = conversationId;

    await streamChat(
      { conversationId: conversationId ?? undefined, ...payload },
      {
        signal: controller.signal,
        onEvent: (event) => {
          if (event.type === "meta") {
            finishedConversation = event.conversationId;
            setConversationId(event.conversationId);
            setModel(event.model);
          } else if (event.type === "token") {
            appendToken(event.value);
          } else if (event.type === "tool") {
            setMessages((current) => {
              const next = [...current];
              const last = next[next.length - 1];
              if (last && last.streaming) {
                next[next.length - 1] = { ...last, tools: [...(last.tools ?? []), { name: event.name, summary: event.summary }] };
              }
              return next;
            });
          } else if (event.type === "done") {
            setMessages((current) => {
              const next = [...current];
              const last = next[next.length - 1];
              if (last && last.streaming) {
                next[next.length - 1] = {
                  ...last,
                  id: event.messageId,
                  content: event.content,
                  streaming: false,
                  metadata: { model, tools: event.tools, latencyMs: event.latencyMs },
                  tools: event.tools,
                };
              }
              return next;
            });
            setStreaming(false);
            void loadSidebar();
            if (settings?.autoSpeak && speaker.supported) {
              speaker.speak(speakableText(event.content), {
                rate: settings.voiceRate,
                pitch: settings.voicePitch,
                voiceName: settings.voiceName,
              });
            }
            if (finishedConversation) {
              window.history.replaceState(null, "", `/chat?id=${finishedConversation}`);
            }
          } else if (event.type === "error") {
            setStreaming(false);
            setError({ message: event.message, hint: event.hint, code: event.code });
            setMessages((current) => {
              const next = [...current];
              const last = next[next.length - 1];
              if (last && last.streaming) {
                next[next.length - 1] = {
                  ...last,
                  content: event.partial || last.content,
                  streaming: false,
                  status: "error",
                };
              }
              return next;
            });
          }
        },
      },
    ).catch((caught) => {
      if (caught instanceof DOMException && caught.name === "AbortError") return;
      setStreaming(false);
      setError({ message: caught instanceof Error ? caught.message : "Stream failed." });
    });

    setStreaming(false);
    abortRef.current = null;
  };

  const send = async (raw?: string) => {
    const text = (raw ?? input).trim();
    if (!text || streaming) return;
    setInput("");
    setError(null);
    const userMessage: ChatMessage = {
      id: `local-${Date.now()}`,
      conversationId: conversationId ?? "pending",
      role: "user",
      content: text,
      status: "complete",
      createdAt: new Date().toISOString(),
    };
    const assistantPlaceholder: ChatMessage = {
      id: `stream-${Date.now()}`,
      conversationId: conversationId ?? "pending",
      role: "assistant",
      content: "",
      status: "streaming",
      streaming: true,
      createdAt: new Date().toISOString(),
    };
    setMessages((current) => [...current, userMessage, assistantPlaceholder]);
    await runGeneration({ message: text });
  };
  sendRef.current = (text: string) => void send(text);

  const stop = () => {
    abortRef.current?.abort();
    setStreaming(false);
    setMessages((current) =>
      current.map((message) => (message.streaming ? { ...message, streaming: false, status: "cancelled" } : message)),
    );
  };

  const regenerate = async () => {
    if (!conversationId || streaming) return;
    setMessages((current) => {
      const copy = [...current];
      while (copy.length && copy[copy.length - 1].role === "assistant") copy.pop();
      return [
        ...copy,
        {
          id: `stream-${Date.now()}`,
          conversationId,
          role: "assistant",
          content: "",
          status: "streaming",
          streaming: true,
          createdAt: new Date().toISOString(),
        },
      ];
    });
    await runGeneration({ regenerate: true });
  };

  const copy = async (content: string) => {
    try {
      await navigator.clipboard.writeText(content);
    } catch {
      setError({ message: "Clipboard access was blocked by the browser." });
    }
  };

  const startNew = () => {
    abortRef.current?.abort();
    setMessages([]);
    setConversationId(null);
    setError(null);
    setStreaming(false);
    window.history.replaceState(null, "", "/chat");
    router.refresh();
  };

  const lastAssistantIndex = messages.reduce((acc, message, index) => (message.role === "assistant" ? index : acc), -1);

  return (
    <div className="grid gap-4 lg:grid-cols-[16rem_1fr]">
      {/* Conversation rail */}
      <aside className="panel hidden h-[calc(100dvh-8rem)] flex-col p-3.5 lg:flex">
        <div className="mb-3 flex items-center justify-between">
          <p className="eyebrow">Transcripts</p>
          <button type="button" onClick={startNew} className="icon-btn" aria-label="New conversation">
            +
          </button>
        </div>
        <div className="scroll-thin flex-1 space-y-1.5 overflow-y-auto pr-1">
          {conversations.length === 0 && <p className="px-1 text-xs text-faint">No saved conversations yet.</p>}
          {conversations.map((conversation) => (
            <Link
              key={conversation.id}
              href={`/chat?id=${conversation.id}`}
              className={`block rounded-xl border px-2.5 py-2 transition-colors ${
                conversation.id === conversationId
                  ? "border-fuchsia-300/35 bg-fuchsia-500/10"
                  : "border-transparent hover:border-white/10 hover:bg-white/5"
              }`}
            >
              <p className="truncate text-xs font-medium text-white">{conversation.title}</p>
              <p className="mt-0.5 truncate text-[0.6rem] text-faint">{relativeTime(conversation.updatedAt)}</p>
            </Link>
          ))}
        </div>
        <Link href="/conversations" className="btn btn-outline btn-sm mt-3 w-full">
          Full history
        </Link>
      </aside>

      {/* Conversation panel */}
      <section className="panel flex h-[calc(100dvh-8rem)] min-h-[30rem] flex-col overflow-hidden lg:h-[calc(100dvh-8rem)]">
        <header className="flex items-center justify-between gap-3 border-b border-white/8 px-4 py-3">
          <div className="flex min-w-0 items-center gap-2.5">
            <div className="h-10 w-10 shrink-0">
              <Orb state={streaming ? "thinking" : speaker.speaking ? "speaking" : dictation.listening ? "listening" : "idle"} className="h-full w-full" density={520} />
            </div>
            <div className="min-w-0">
              <p className="truncate text-sm font-semibold text-white">JARVIS assistant</p>
              <p className="truncate text-[0.62rem] text-faint">
                {model} · {streaming ? "streaming response" : speaker.speaking ? "speaking" : dictation.listening ? "listening" : "ready"}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-1.5">
            {speaker.speaking ? (
              <button type="button" onClick={speaker.stop} className="icon-btn" aria-label="Stop speaking">
                <VolumeX size={15} />
              </button>
            ) : (
              <button
                type="button"
                onClick={() => {
                  const last = [...messages].reverse().find((message) => message.role === "assistant" && message.content);
                  if (last && settings) speaker.speak(speakableText(last.content), { rate: settings.voiceRate, pitch: settings.voicePitch, voiceName: settings.voiceName });
                }}
                disabled={!speaker.supported || !messages.some((m) => m.role === "assistant")}
                className="icon-btn"
                aria-label="Read the latest answer aloud"
              >
                <Volume2 size={15} />
              </button>
            )}
            <button type="button" onClick={regenerate} disabled={!conversationId || streaming} className="icon-btn" aria-label="Regenerate last response">
              <RefreshCcw size={15} />
            </button>
            <button type="button" onClick={startNew} className="btn btn-outline btn-sm">
              New
            </button>
          </div>
        </header>

        <div className="scroll-thin flex-1 space-y-4 overflow-y-auto px-3.5 py-4 sm:px-5">
          {loading ? (
            <div className="flex items-center gap-2 py-10 text-sm text-muted">
              <Spinner /> Restoring transcript…
            </div>
          ) : messages.length === 0 ? (
            <div className="mx-auto max-w-xl py-6 text-center">
              <div className="mx-auto h-40 w-40">
                <Orb state="idle" className="h-full w-full" density={900} />
              </div>
              <h1 className="title-gradient mt-2 text-2xl">JARVIS is listening</h1>
              <p className="mx-auto mt-2 max-w-sm text-sm text-muted">
                Your key is connected and encrypted. Ask anything, or try one of these:
              </p>
              <div className="mt-4 grid gap-2 sm:grid-cols-2">
                {QUICK_PROMPTS.map((prompt) => (
                  <button
                    key={prompt}
                    type="button"
                    onClick={() => void send(prompt)}
                    className="rounded-xl border border-white/10 bg-white/[0.03] p-2.5 text-left text-xs leading-relaxed text-muted transition-colors hover:border-fuchsia-300/35 hover:text-white"
                  >
                    {prompt}
                  </button>
                ))}
              </div>
            </div>
          ) : (
            messages.map((message, index) => (
              <div key={message.id} className={`flex gap-2.5 ${message.role === "user" ? "justify-end" : "justify-start"}`}>
                {message.role === "assistant" && (
                  <div className="mt-1 h-8 w-8 shrink-0">
                    <Orb state={message.streaming ? "thinking" : "idle"} className="h-full w-full" density={320} />
                  </div>
                )}
                <div className={`max-w-[85%] ${message.role === "user" ? "order-2" : ""}`}>
                  <div
                    className={`rounded-2xl border px-3.5 py-2.5 ${
                      message.role === "user"
                        ? "border-fuchsia-300/25 bg-gradient-to-br from-fuchsia-500/20 to-violet-500/15 text-white"
                        : "border-white/10 bg-white/[0.03]"
                    }`}
                  >
                    {message.role === "assistant" ? (
                      message.content ? (
                        <div className={message.streaming ? "stream-caret" : ""}>
                          <MarkdownView content={message.content} />
                        </div>
                      ) : (
                        <Waveform active bars={16} className="h-6" />
                      )
                    ) : (
                      <p className="whitespace-pre-wrap text-sm leading-relaxed">{message.content}</p>
                    )}
                  </div>

                  {(message.tools ?? []).length > 0 && (
                    <div className="mt-1.5 flex flex-wrap gap-1.5">
                      {(message.tools ?? []).map((tool, toolIndex) => (
                        <span key={`${tool.name}-${toolIndex}`} className="chip chip-live normal-case tracking-normal">
                          <Wrench size={10} /> {tool.summary}
                        </span>
                      ))}
                    </div>
                  )}

                  {message.role === "assistant" && message.content && !message.streaming && (
                    <div className="mt-1 flex items-center gap-2 text-[0.6rem] text-faint">
                      <button type="button" onClick={() => void copy(message.content)} className="inline-flex items-center gap-1 hover:text-white">
                        <Copy size={11} /> Copy
                      </button>
                      {index === lastAssistantIndex && (
                        <button type="button" onClick={regenerate} className="inline-flex items-center gap-1 hover:text-white">
                          <RefreshCcw size={11} /> Regenerate
                        </button>
                      )}
                      <button
                        type="button"
                        onClick={() =>
                          settings &&
                          speaker.speak(speakableText(message.content), { rate: settings.voiceRate, pitch: settings.voicePitch, voiceName: settings.voiceName })
                        }
                        className="inline-flex items-center gap-1 hover:text-white"
                      >
                        <Volume2 size={11} /> Speak
                      </button>
                      {message.status === "error" && <span className="text-rose-300/80">failed</span>}
                      {message.status === "cancelled" && <span className="text-amber-300/80">stopped</span>}
                    </div>
                  )}
                </div>
              </div>
            ))
          )}
          <div ref={bottomRef} />
        </div>

        <div className="border-t border-white/8 px-3.5 py-3 sm:px-5">
          {error && (
            <div className="mb-2.5">
              <Alert
                kind="error"
                message={error.message}
                hint={error.hint}
                action={
                  error.code === "gemini_invalid" || error.code === "gemini_not_connected" ? (
                    <Link href="/connect" className="btn btn-outline btn-sm">Reconnect Gemini</Link>
                  ) : undefined
                }
              />
            </div>
          )}
          {dictation.error && (
            <div className="mb-2.5">
              <Alert kind="warning" message={dictation.error} hint="Text input stays fully functional." />
            </div>
          )}
          {speaker.error && (
            <div className="mb-2.5">
              <Alert kind="info" message={speaker.error} />
            </div>
          )}

          {dictation.interim && <p className="mb-1.5 px-1 text-xs italic text-fuchsia-200/70">{dictation.interim}…</p>}

          <div className="flex items-end gap-2">
            <button
              type="button"
              onClick={() => (dictation.listening ? dictation.stop() : dictation.start())}
              disabled={streaming}
              className={`icon-btn h-11 w-11 shrink-0 rounded-2xl ${dictation.listening ? "border-fuchsia-300/60 bg-fuchsia-500/20 text-fuchsia-100" : ""}`}
              aria-label={dictation.listening ? "Stop dictation" : "Dictate a message"}
              title={dictation.supported ? "Dictate (Web Speech API)" : "Speech recognition unavailable — type instead"}
            >
              {dictation.listening ? <MicOff size={17} /> : <Mic size={17} />}
            </button>
            <textarea
              ref={inputRef}
              value={input}
              onChange={(event) => setInput(event.target.value)}
              onKeyDown={(event) => {
                if (event.key === "Enter" && !event.shiftKey) {
                  event.preventDefault();
                  void send();
                }
              }}
              rows={1}
              placeholder="Ask JARVIS anything…"
              aria-label="Message"
              className="field max-h-32 min-h-11 flex-1 resize-none py-3"
            />
            {streaming ? (
              <button type="button" onClick={stop} className="btn btn-outline h-11 shrink-0 px-4" aria-label="Stop generating">
                <Square size={14} /> Stop
              </button>
            ) : (
              <button type="button" onClick={() => void send()} disabled={!input.trim()} className="btn btn-primary h-11 shrink-0 px-4" aria-label="Send message">
                <Send size={15} />
              </button>
            )}
          </div>
          <p className="mt-1.5 flex items-center justify-between text-[0.58rem] text-faint">
            <span className="flex items-center gap-1">
              {streaming && <Loader2 size={10} className="animate-spin" />} Enter sends · Shift+Enter new line
            </span>
            <span className="hidden sm:inline">Responses come from your Gemini key · quota applies</span>
          </p>
        </div>
      </section>
    </div>
  );
}
