import { redirect } from "next/navigation";
import type { ReactNode } from "react";
import { AppShell } from "@/components/AppShell";
import { getSessionUser } from "@/lib/auth";
import { hasCredential } from "@/lib/vault";

export const dynamic = "force-dynamic";

export default async function AuthenticatedLayout({ children }: { children: ReactNode }) {
  const user = await getSessionUser();
  if (!user) redirect("/auth");

  const gemini = await hasCredential(user.id);
  if (!gemini.connected) redirect("/connect");

  return (
    <AppShell
      user={{ displayName: user.displayName, email: user.email, emailVerified: user.emailVerified }}
      gemini={{ connected: gemini.connected, model: gemini.model, last4: gemini.last4, status: gemini.status }}
    >
      {children}
    </AppShell>
  );
}
