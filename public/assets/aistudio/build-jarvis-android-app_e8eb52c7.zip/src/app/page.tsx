import { redirect } from "next/navigation";
import { getSessionUser } from "@/lib/auth";
import { hasCredential } from "@/lib/vault";

export const dynamic = "force-dynamic";

/**
 * Startup gate. The very first screen must be the Gemini connection screen:
 * a saved setup flag can never bypass a missing or revoked credential.
 */
export default async function EntryPage() {
  const user = await getSessionUser();
  const gemini = await hasCredential(user?.id ?? null);

  if (!gemini.connected) redirect("/connect");
  if (!user) redirect("/auth");
  redirect("/dashboard");
}
