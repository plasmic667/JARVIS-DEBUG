# Android (Kotlin + Compose + Firebase) mapping

The deployed app in this repository is the web implementation of the JARVIS spec. This document is the build-ready mapping for the
requested **native Android** target. It intentionally does not ship a half-configured Gradle tree; every item below is a concrete
instruction, not a placeholder screen.

## 1. Module graph

```
app/
core/common/         Result<T>, AppError, dispatchers, time providers
core/designsystem/   Theme, Orb, GlassCard, GradientButton, StatusChip, Waveform
core/network/        GeminiApi (Retrofit/OkHttp SSE), AuthInterceptor-less key injection
core/database/       Room: conversations/messages/memories/notes/tasks/reminders DAOs (offline queue)
core/security/       KeystoreCrypto (AES/GCM), CredentialVault, SecureLogger
core/permissions/    MicPermissionController, NotificationPermissionController
feature/onboarding/  ConnectGeminiScreen + ViewModel + GeminiKeyValidator
feature/auth/        Login/Register/Verify/Reset + GoogleSignIn launcher
feature/dashboard/   DashboardScreen (reference hero + stats plate)
feature/chat/        ChatScreen, streaming state, markdown (compose-richtext), tool chips
feature/voice/       VoiceScreen, SpeechRecognizer + TextToSpeech wrappers
feature/memory/  feature/notes/  feature/tasks/  feature/settings/
data/repository/     Repositories over Room + Firestore + Functions
data/remote/         FirebaseFunctions callables (chat, tools, export, delete)
data/models/         @Serializable DTOs shared with functions/shared
backend/functions/   TypeScript callables (see §6)
```

DI: Hilt modules for DB, Retrofit, repositories, dispatchers. State: `StateFlow<UiState>` per screen, `collectAsStateWithLifecycle`.
Navigation: `androidx.navigation:navigation-compose` with the same startup graph as `src/app/page.tsx`:

`Splash → (vault empty ? ConnectGemini : (firebaseUser == null ? Auth : Dashboard))`.

## 2. First-launch Gemini screen (mandatory)

- `ConnectGeminiScreen` is the `NavHost` start destination when `CredentialVault.isEmpty()`. It is **not** reachable-after-login; it
  precedes authentication.
- Compose layout mirrors `src/app/connect/page.tsx`: full-bleed dark gradient, animated `Orb` (Canvas particle sphere, ~1800 points,
  `withFrameNanos` loop, reduced-motion aware), eyebrow “STEP 01 · SINCE 2025”, display heading “CONNECT YOUR INTELLIGENCE”,
  secure `OutlinedTextField` (`PasswordVisualTransformation`, trailing visibility toggle, `imePadding()`,
  `windowSoftInputMode=adjustResize`), model dropdown, gradient CTA “Connect via Gemini API Key”, help sheet with the official
  AI Studio link, status chip + error/retry/edit states.
- Validation uses the same live request: `POST models/{model}:generateContent` with a one-word prompt, `x-goog-api-key` header, 25 s
  timeout. Only HTTP 2xx → save. Map 401/400 key errors, 403 permission, 404 model, 429 quota/rate, 5xx outage to typed `AppError`.
- Success: `CredentialVault.store(key)` (Keystore) → mark `onboarding=key_connected` → `AuthScreen`.
- Returning user: read vault on start; if the key fails a health check on foreground, set status `invalid` and route to
  `ReconnectGeminiScreen` (the same composable with a warning banner). Explicit disconnect clears the vault row first.
- **Never** ship a privileged key in source, `BuildConfig`, resources or the APK. Do not log the key: install a Timber tree that
  redacts `AIza[0-9A-Za-z_-]{20,}` and disable Firebase Analytics/Crashlytics auto-collection of custom keys.

### Keystore implementation sketch
```kotlin
class KeystoreCrypto(context: Context) {
    private val alias = "jarvis_gemini_v1"
    private fun key(): SecretKey {
        val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (store.getEntry(alias, null) as? KeyStore.SecretKeyEntry)?.let { return it.secretKey }
        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        gen.init(KeyGenParameterSpec.Builder(alias,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setUserAuthenticationRequired(false)
            .setRandomizedEncryptionRequired(true)
            .build())
        return gen.generateKey()
    }
    fun encrypt(plain: String): Pair<ByteArray, ByteArray> { /* Cipher AES/GCM/NoPadding */ }
    fun decrypt(iv: ByteArray, cipherText: ByteArray): String { /* GCMParameterSpec(128, iv) */ }
}
```
Store ciphertext + IV in `EncryptedSharedPreferences`/DataStore. Set `android:allowBackup="false"` and
`android:fullBackupContent="@xml/backup_rules"` so the key never reaches cloud backup.

## 3. Screen parity table

| Web route | Android destination |
| --- | --- |
| `/connect` | ConnectGeminiScreen / ReconnectGeminiScreen |
| `/auth` | LoginScreen, RegisterScreen, VerifyEmailScreen, ResetPasswordScreen (+ Credential Manager Google Sign-In) |
| `/dashboard` | DashboardScreen |
| `/chat` | ChatScreen (streaming, cancel, regenerate, copy) |
| `/voice` | VoiceScreen (push-to-talk, TTS controls, fallback keyboard) |
| `/conversations` | ConversationHistoryScreen |
| `/memory` | MemoryScreen (opt-out + purge) |
| `/workspace` | NotesScreen / TasksScreen / RemindersScreen / DocumentAnalysisScreen |
| `/settings` | SettingsScreen (personality, voice, key test/replace/disconnect, privacy, deletion) |

## 4. Voice
`SpeechRecognizer` (or `RecognizerIntent`) with `RecognizerIntent.EXTRA_LANGUAGE`, `EXTRA_PARTIAL_RESULTS`; push-to-talk default,
`AudioRecord` amplitude feeding the orb/waveform. `TextToSpeech` with `setSpeechRate/setPitch`, `setOnUtteranceProgressListener` for
speaking state and `stop()` for interruption. Handle `ERROR_NO_MATCH`, `ERROR_NETWORK`, `ERROR_INSUFFICIENT_PERMISSIONS`,
`ERROR_RECOGNIZER_BUSY`. Wake word: only with a foreground service + `RECORD_AUDIO` and a persistent notification; document the
battery/privacy cost and never request always-on audio by default.

## 5. Offline + reminders
Room is the source of truth for lists and recent messages; Firestore snapshot listeners keep other devices in sync. Outgoing chat
requests while offline return an explicit error. Reminders use `WorkManager` one-shot work at `remindAt` (time zone resolved at
schedule time) plus FCM for device-delivered notifications; exact timing is never guaranteed (Doze / battery optimisation), and
`POST_NOTIFICATIONS` is requested only when the user schedules their first reminder.

## 6. Backend (Firebase Cloud Functions, TypeScript)
Callables mirroring this repo's API:
- `connectGeminiHealth` — optional server-side validation of a user key (never persisted).
- `chat` — auth + App Check, rate limits, Gemini streaming (or the user's key supplied per request over TLS), tool execution,
  Firestore persistence. Never logs payloads/keys.
- `summarize`, `exportUserData`, `deleteAccount` — explicit confirmation, cascade delete, audit without content.
- `reminderScheduler` (pub/sub + WorkManager companion) and `sendReminder` (FCM).
Secrets: `firebase functions:secrets:set GEMINI_API_KEY` for the server-owned proxy mode. In user-owned mode, keys stay in Android
Keystore and are forwarded per request; do not attach them to logs, error reports or analytics.

## 7. Tests
JVM: `GeminiKeyValidatorTest` (invalid key / quota / success), `KeystoreCryptoTest` (Robolectric), `PersonalityPromptTest`,
`CalculatorTest`, repository tests over Room in-memory, ViewModel state tests with Turbine.
UI: Compose tests for the connect screen (empty key, error, loading, success navigation), auth flows, chat streaming, memory purge
confirmation. Emulator Suite: `firebase emulators:start` for Firestore/Auth/Functions; rules unit tests with
`@firebase/rules-unit-testing` asserting cross-user reads fail.

## 8. Firebase setup checklist
1. Create project → add Android app `ai.jarvis.assistant` → `google-services.json` in `app/`.
2. Auth: enable Email/Password and Google; add debug + release SHA-1/SHA-256; configure OAuth consent screen.
3. Firestore: create database, deploy `docs/firestore.rules`, add composite indexes from the commented list.
4. Storage: deploy the storage rules; create `users/{uid}` prefixes.
5. App Check: Play Integrity for Android, enforce on callables and Firestore.
6. Crashlytics/Analytics: scrub keys, disable collection of sensitive params; add `firebase-crashlytics-gradle`.
7. FCM: add `google-services` plugin, notification channel, `POST_NOTIFICATIONS` runtime request.
8. Release: `./gradlew bundleRelease` with `keystore.properties` (git-ignored), Play App Signing, verified debug build before upload.
