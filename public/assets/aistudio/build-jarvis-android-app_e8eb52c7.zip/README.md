# JARVIS AI — Personal Intelligence

A working, full-stack JARVIS AI assistant: **first launch opens directly on “Connect Your Intelligence”**, the Gemini API key is
validated with a **real** `generateContent` call, encrypted at rest, and only then does onboarding continue to the account step and
dashboard. Conversations stream from Gemini with tool calling, memory, notes, tasks, reminders, voice I/O and full privacy controls.

> **Environment note (read this first).** This repository runs on the platform's Next.js + PostgreSQL runtime. No Android SDK,
> Gradle daemon, Firebase project or Google OAuth client is available in this sandbox, so the deliverables are shipped as a
> **production web implementation of the same architecture** plus the complete **Firebase / Kotlin mapping** in
> [`docs/ANDROID_MAPPING.md`](docs/ANDROID_MAPPING.md) and the hardened rules in [`docs/firestore.rules`](docs/firestore.rules).
> Everything in the web build is real: no fabricated AI responses, no fake auth success, no fake database writes. Android APK
> generation and Firebase-backed Google Sign-In are the two items that require your credentials/toolchain (see “Remaining manual
> steps”).

---

## 1. What is implemented

### Onboarding gate (strict order)
| State | Screen |
| --- | --- |
| No credential on this installation | `/connect` — **always the first screen**, even if an account exists |
| Credential + no session | `/auth` |
| Credential + session | `/dashboard` |
| Key revoked / rejected by Gemini | Chat shows “Reconnect Gemini”, vault status flips to `invalid` |
| User disconnects | Encrypted row deleted, returns to `/connect` |
| User replaces key | `/connect?change=1` validates the **new** key before switching |
| App data cleared / reinstall | New device id → no credential → `/connect` |

The root server component (`src/app/page.tsx`) and the authenticated layout (`src/app/(app)/layout.tsx`) both re-check the vault;
a “setup complete” flag can never bypass a missing or revoked key.

### Gemini connection screen
Animated particle-sphere orb (canvas halftone recreation of the reference), “Connect Your Intelligence”, secure key field with
show/hide, model selector, live status chip, loading/retry/edit states, an always-available “How to get a Gemini API key” guide
linking to `https://aistudio.google.com/app/apikey`, and a glass “credential vault” plate derived from the reference layout.

### AI + assistant
- Real Gemini `v1beta` REST integration, configurable model (`gemini-2.5-flash` default, live model discovery via your key).
- SSE token streaming from `:streamGenerateContent`, server-relayed to the browser with cancellation (`Stop`).
- Server-side **function calling**: `create_task`, `list_tasks`, `complete_task`, `create_note`, `create_reminder`, `save_memory`,
  `calculate` (exact parser), `current_datetime`, `search_conversations` — executed against the database, with tool chips in the UI.
- Six personality modes (JARVIS / professional / friendly / funny / calm / custom), humour and expressiveness levels, response length,
  temperature, and a system instruction that forbids consciousness claims, secret disclosure and destructive actions.
- Conversation history: search, rename, pin, delete, copy, regenerate, cancel, markdown + code rendering.

### Voice
Web Speech API speech-to-text (push-to-talk, interim transcript, permission/network error recovery) and speech synthesis (voice
selection, rate/pitch, interrupt/stop, mute, auto-speak). When the browser has no recognition engine the UI says so and offers a
text fallback — it never pretends to listen.

### Tools, memory, privacy
Notes, tasks, reminders, document summarisation, exports, account deletion, memory inspection/edit/purge, complete memory opt-out,
Gemini disconnect/replace/test. Destructive actions require confirmation modals. Reminders fire through browser notifications while
the app is open (30 s scheduler), documented honestly as not exact-time when the tab is closed.

---

## 2. Local development

```bash
npm install
# .env already contains DATABASE_URL and JARVIS_VAULT_SECRET
npx drizzle-kit push      # create tables
npm run dev               # http://localhost:3000
```

Production validation (what was actually run):

```bash
npx next typegen
npm exec tsc -- --noEmit
npm run build
node --experimental-strip-types --test tests/core.test.ts
```

### Environment variables
| Name | Required | Purpose |
| --- | --- | --- |
| `DATABASE_URL` | yes | PostgreSQL connection string (Drizzle). |
| `JARVIS_VAULT_SECRET` | yes in production | Master secret for AES-256-GCM credential encryption (`scrypt`-derived). Rotate = re-enter keys. Never commit a real value. |
| `GEMINI_API_KEY` | no | Optional server-owned key for a future proxy mode. **Not used** by the user-owned-key flow; never exposed to the browser. |

The app deliberately ships **without** any Gemini key. Each user connects their own key from Google AI Studio. Usage, quotas and
billing are controlled by that user's Google project.

---

## 3. How the Gemini key is handled

1. Browser sends the pasted key over HTTPS to `POST /api/gemini` (`action:"connect"`).
2. Server performs format sanity checks (non-empty, no whitespace, `AIza` prefix) **and then** a live `generateContent` request to
   the chosen model (`maxOutputTokens: 24`, temperature 0). Format checks are never treated as proof.
3. Responses are mapped to actionable errors: `invalid_key`, `permission_denied`, `model_unavailable`, `quota_exceeded`,
   `rate_limited`, `provider_unavailable`, `network_error`. Nothing is reported as connected unless the API returned 200.
4. The key is encrypted with AES-256-GCM (`JARVIS_VAULT_SECRET`, random 96-bit IV, auth tag) and stored in a device-scoped
   `credentials` row. Only the last four characters are ever returned to the UI.
5. The key is never written to `users`, exports, logs, telemetry or analytics. `redactSecrets()` scrubs any accidental `AIza…`
   appearance in error messages.
6. Disconnect deletes the row; replacing a key validates before overwriting.

Server logs contain route, model, latency, status only (`usage_events`). No prompts, completions or credentials.

---

## 4. Authentication

Implemented locally in `src/app/api/auth/[action]`:

- registration + scrypt password hashing (salted, `timingSafeEqual` verification),
- login, logout, persistent HttpOnly session cookie (30 days, hashed token in DB),
- single-use email verification token + resend, password reset token (30 min) with session revocation,
- account deletion requiring the current password, cascading all owned rows and the encrypted credential.

**Email transport:** this sandbox has no mail provider, so verification/reset links are surfaced in an in-app “local inbox” panel
(clearly labelled). The tokens are real and single-use. Swap `deliverLocal()` for Firebase Authentication email actions or a
transactional provider before release.

**Google Sign-In** requires a Google OAuth client / Firebase project (client IDs + SHA-1 fingerprints). It is intentionally **not**
rendered as a fake button; the exact Firebase setup is in the mapping doc.

---

## 5. Database model (PostgreSQL / Drizzle, mirrors Firestore)

`users`, `sessions`, `credentials` (encrypted vault, device-scoped), `user_settings`, `conversations`, `messages`, `memories`,
`notes`, `tasks`, `reminders`, `usage_events` — see `src/db/schema.ts`. Every mutating route scopes by `userId`; there is no
cross-account read path. Indexes cover conversation ordering, task state and reminder time.

Firestore equivalents, indexes and hardened security rules (including the rule that no client may read another user's subcollection
and that API keys never live in Firestore) are provided in [`docs/firestore.rules`](docs/firestore.rules).

---

## 6. API surface

| Route | Methods | Notes |
| --- | --- | --- |
| `/api/health` | GET | DB liveness. |
| `/api/session` | GET | Boot gate: auth + vault state + `nextStep`. |
| `/api/auth/[action]` | POST | `register`, `login`, `logout`, `verify`, `resend-verification`, `request-reset`, `reset`, `delete`. |
| `/api/gemini` | GET/POST | `connect`, `test`, `models`, `set-model`, `disconnect` — all live-validated. |
| `/api/chat` | POST | SSE stream, tool loop, persistence, regenerate, cancel. |
| `/api/conversations` | GET/POST/PATCH/DELETE | Search, create, rename/pin, delete (cascade). |
| `/api/data` | GET/POST/PATCH/DELETE | `memories`, `notes`, `tasks`, `reminders`; `id=all` purges own collection. |
| `/api/settings` | GET/PATCH | Personality, voice, length, temperature, memory, animations. |
| `/api/overview` | GET | Dashboard stats, recent conversations, tasks, reminders, memory preview. |
| `/api/summarize` | POST | Real Gemini document summary; optional save-as-note. |
| `/api/export` | GET | Full JSON export (credential intentionally excluded). |

Rate limits: auth per email, Gemini connect per user/device, chat 25/min, summarise 6/min. All inputs validated with length caps.

---

## 7. Tests

`tests/core.test.ts` (8 tests, run with Node's test runner and `--experimental-strip-types`) covers:

- credential vault encrypt/decrypt round-trip and tamper rejection (GCM auth),
- salted password hashing + verification, redaction of leaked key formats,
- personality prompt composition (memory on/off, humour, custom mode, length),
- title derivation, speakable-text sanitisation,
- calculator correctness and injection/divide-by-zero rejection.

Run:

```bash
node --experimental-strip-types --test tests/core.test.ts
```

Manual flows worth re-running after changes: first launch → connect (invalid key, quota, valid key) → account → dashboard → chat
streaming + stop/regenerate → memory add/purge → notes/tasks/reminders → reminders notification → export → disconnect key → reinstall
(fresh cookie) → account deletion.

---

## 8. Known limitations (stated honestly)

- **No Android APK was built here**: the sandbox provides Node/PostgreSQL only. Kotlin/Compose sources are not shipped as an
  unbuildable tree; the mapping doc specifies the exact module structure, libraries, Gradle settings and Keystore code path.
- **Google Sign-In and Firebase services are not wired** without your Firebase project + OAuth fingerprints. Auth here is the
  functional local implementation described above.
- **Email delivery** is the in-app local inbox (real tokens, no SMTP provider configured).
- **Speech** depends on browser/OS Web Speech support (best in Chromium desktop/Android). Unsupported browsers get an explicit
  notice and text fallback. Wake-word listening is intentionally omitted.
- **Reminders** fire via foreground polling + Notification API. The Android build should use WorkManager + FCM for OS-delivered
  notifications; exact-time delivery is never guaranteed under Doze/battery optimisation.
- **Multimodal input** (camera/image) is not exposed in the web UI; the server module accepts Gemini content parts, so adding
  `inlineData` images is a contained change.

---

## 9. Remaining manual steps for the native build

1. Create a Firebase project, add Android app id `ai.jarvis.assistant`, download `google-services.json`.
2. Enable Email/Password + Google providers, add SHA-1/SHA-256 fingerprints, download the OAuth client config.
3. `firebase deploy --only firestore:rules,firestore:indexes,storage` using the rules in `docs/`.
4. Deploy the Gemini proxy Cloud Functions (Node 20/22, TypeScript, secrets via `firebase functions:secrets:set GEMINI_API_KEY` for
   the server-owned mode; user-owned keys stay in Android Keystore and are sent per-request over TLS).
5. Add FCM for reminder push, Crashlytics + Analytics with key-scrubbing before logging, App Check (Play Integrity) on callables.
6. Build a signed AAB: `./gradlew bundleRelease` with an upload key in `keystore.properties` (never commit it) and Play Console
   signing. Commit nothing from `google-services.json` secrets that you do not intend to distribute.
